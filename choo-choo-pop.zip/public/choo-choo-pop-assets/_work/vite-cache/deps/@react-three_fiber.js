import { r as __toESM, t as __commonJSMin } from "./rolldown-runtime-SbdDWaPq.js";
import { t as require_react } from "./react-DShITR3P.js";
import { t as require_jsx_runtime } from "./jsx-runtime-A-nMxgh2.js";
import { Ao as Scene, Hr as LinearSRGBColorSpace, Oo as SRGBColorSpace, Us as Vector2, Ws as Vector3, c as three_module_exports, ct as Color, ea as OrthographicCamera, fo as Raycaster, ia as PerspectiveCamera, jo as ShaderMaterial, o as WebGLRenderer, st as Clock, ut as ColorManagement, vr as Layers } from "./three.module-aCHopcSl.js";
import { t as require_scheduler } from "./scheduler-DpnzCpb8.js";
// ../../Web Game/choo-choo-pop/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
/**
* @license React
* use-sync-external-store-shim.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
			var value = getSnapshot();
			if (!didWarnUncachedGetSnapshot) {
				var cachedValue = getSnapshot();
				objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
			}
			cachedValue = useState({ inst: {
				value,
				getSnapshot
			} });
			var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
// ../../Web Game/choo-choo-pop/node_modules/use-sync-external-store/shim/index.js
var require_shim = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_use_sync_external_store_shim_development();
}));
// ../../Web Game/choo-choo-pop/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js
/**
* @license React
* use-sync-external-store-shim/with-selector.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_with_selector_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), shim = require_shim(), objectIs = "function" === typeof Object.is ? Object.is : is, useSyncExternalStore = shim.useSyncExternalStore, useRef = React.useRef, useEffect = React.useEffect, useMemo = React.useMemo, useDebugValue = React.useDebugValue;
		exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
			var instRef = useRef(null);
			if (null === instRef.current) {
				var inst = {
					hasValue: !1,
					value: null
				};
				instRef.current = inst;
			} else inst = instRef.current;
			instRef = useMemo(function() {
				function memoizedSelector(nextSnapshot) {
					if (!hasMemo) {
						hasMemo = !0;
						memoizedSnapshot = nextSnapshot;
						nextSnapshot = selector(nextSnapshot);
						if (void 0 !== isEqual && inst.hasValue) {
							var currentSelection = inst.value;
							if (isEqual(currentSelection, nextSnapshot)) return memoizedSelection = currentSelection;
						}
						return memoizedSelection = nextSnapshot;
					}
					currentSelection = memoizedSelection;
					if (objectIs(memoizedSnapshot, nextSnapshot)) return currentSelection;
					var nextSelection = selector(nextSnapshot);
					if (void 0 !== isEqual && isEqual(currentSelection, nextSelection)) return memoizedSnapshot = nextSnapshot, currentSelection;
					memoizedSnapshot = nextSnapshot;
					return memoizedSelection = nextSelection;
				}
				var hasMemo = !1, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
				return [function() {
					return memoizedSelector(getSnapshot());
				}, null === maybeGetServerSnapshot ? void 0 : function() {
					return memoizedSelector(maybeGetServerSnapshot());
				}];
			}, [
				getSnapshot,
				getServerSnapshot,
				selector,
				isEqual
			]);
			var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
			useEffect(function() {
				inst.hasValue = !0;
				inst.value = value;
			}, [value]);
			useDebugValue(value);
			return value;
		};
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
// ../../Web Game/choo-choo-pop/node_modules/use-sync-external-store/shim/with-selector.js
var require_with_selector = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_with_selector_development();
}));
// ../../Web Game/choo-choo-pop/node_modules/zustand/esm/vanilla.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var import_with_selector = /* @__PURE__ */ __toESM(require_with_selector(), 1);
var createStoreImpl = (createState) => {
	let state;
	const listeners = /* @__PURE__ */ new Set();
	const setState = (partial, replace) => {
		const nextState = typeof partial === "function" ? partial(state) : partial;
		if (!Object.is(nextState, state)) {
			const previousState = state;
			state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
			listeners.forEach((listener) => listener(state, previousState));
		}
	};
	const getState = () => state;
	const getInitialState = () => initialState;
	const subscribe = (listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	};
	const api = {
		setState,
		getState,
		getInitialState,
		subscribe
	};
	const initialState = state = createState(setState, getState, api);
	return api;
};
var createStore$1 = ((createState) => createState ? createStoreImpl(createState) : createStoreImpl);
// ../../Web Game/choo-choo-pop/node_modules/zustand/esm/traditional.mjs
var { useSyncExternalStoreWithSelector } = import_with_selector.default;
var identity = (arg) => arg;
function useStoreWithEqualityFn(api, selector = identity, equalityFn) {
	const slice = useSyncExternalStoreWithSelector(api.subscribe, api.getState, api.getInitialState, selector, equalityFn);
	import_react.useDebugValue(slice);
	return slice;
}
var createWithEqualityFnImpl = (createState, defaultEqualityFn) => {
	const api = createStore$1(createState);
	const useBoundStoreWithEqualityFn = (selector, equalityFn = defaultEqualityFn) => useStoreWithEqualityFn(api, selector, equalityFn);
	Object.assign(useBoundStoreWithEqualityFn, api);
	return useBoundStoreWithEqualityFn;
};
var createWithEqualityFn = ((createState, defaultEqualityFn) => createState ? createWithEqualityFnImpl(createState, defaultEqualityFn) : createWithEqualityFnImpl);
// ../../Web Game/choo-choo-pop/node_modules/suspend-react/index.js
var isPromise = (promise) => typeof promise === "object" && typeof promise.then === "function";
var globalCache = [];
function shallowEqualArrays(arrA, arrB, equal = (a, b) => a === b) {
	if (arrA === arrB) return true;
	if (!arrA || !arrB) return false;
	const len = arrA.length;
	if (arrB.length !== len) return false;
	for (let i = 0; i < len; i++) if (!equal(arrA[i], arrB[i])) return false;
	return true;
}
function query(fn, keys = null, preload = false, config = {}) {
	if (keys === null) keys = [fn];
	for (const entry of globalCache) if (shallowEqualArrays(keys, entry.keys, entry.equal)) {
		if (preload) return void 0;
		if (Object.prototype.hasOwnProperty.call(entry, "error")) throw entry.error;
		if (Object.prototype.hasOwnProperty.call(entry, "response")) {
			if (config.lifespan && config.lifespan > 0) {
				if (entry.timeout) clearTimeout(entry.timeout);
				entry.timeout = setTimeout(entry.remove, config.lifespan);
			}
			return entry.response;
		}
		if (!preload) throw entry.promise;
	}
	const entry = {
		keys,
		equal: config.equal,
		remove: () => {
			const index = globalCache.indexOf(entry);
			if (index !== -1) globalCache.splice(index, 1);
		},
		promise: (isPromise(fn) ? fn : fn(...keys)).then((response) => {
			entry.response = response;
			if (config.lifespan && config.lifespan > 0) entry.timeout = setTimeout(entry.remove, config.lifespan);
		}).catch((error) => entry.error = error)
	};
	globalCache.push(entry);
	if (!preload) throw entry.promise;
}
var suspend = (fn, keys, config) => query(fn, keys, false, config);
var preload = (fn, keys, config) => void query(fn, keys, true, config);
var clear = (keys) => {
	if (keys === void 0 || keys.length === 0) globalCache.splice(0, globalCache.length);
	else {
		const entry = globalCache.find((entry) => shallowEqualArrays(keys, entry.keys, entry.equal));
		if (entry) entry.remove();
	}
};
/* @__PURE__ */ (() => {
	var e, t;
	return typeof window != "undefined" && (((e = window.document) == null ? void 0 : e.createElement) || ((t = window.navigator) == null ? void 0 : t.product) === "ReactNative");
})() ? import_react.useLayoutEffect : import_react.useEffect;
function l(e, t, i) {
	if (!e) return;
	if (i(e) === !0) return e;
	let n = t ? e.return : e.child;
	for (; n;) {
		const o = l(n, t, i);
		if (o) return o;
		n = t ? null : n.sibling;
	}
}
function b(e) {
	try {
		return Object.defineProperties(e, {
			_currentRenderer: {
				get() {
					return null;
				},
				set() {}
			},
			_currentRenderer2: {
				get() {
					return null;
				},
				set() {}
			}
		});
	} catch (t) {
		return e;
	}
}
var p$1 = /* @__PURE__ */ b(/* @__PURE__ */ import_react.createContext(null));
var h = class extends import_react.Component {
	render() {
		return /* @__PURE__ */ import_react.createElement(p$1.Provider, { value: this._reactInternals }, this.props.children);
	}
};
function m() {
	const e = import_react.useContext(p$1);
	if (e === null) throw new Error("its-fine: useFiber must be called within a <FiberProvider />!");
	const t = import_react.useId();
	return import_react.useMemo(() => {
		for (const n of [e, e == null ? void 0 : e.alternate]) {
			if (!n) continue;
			const o = l(n, !1, (d) => {
				let s = d.memoizedState;
				for (; s;) {
					if (s.memoizedState === t) return !0;
					s = s.next;
				}
			});
			if (o) return o;
		}
	}, [e, t]);
}
var w = Symbol.for("react.context");
var E$1 = (e) => e !== null && typeof e == "object" && "$$typeof" in e && e.$$typeof === w;
function g$1() {
	const e = m(), [t] = import_react.useState(() => /* @__PURE__ */ new Map());
	t.clear();
	let i = e;
	for (; i;) {
		const n = i.type;
		E$1(n) && n !== p$1 && !t.has(n) && t.set(n, import_react.use(b(n))), i = i.return;
	}
	return t;
}
function M$1() {
	const e = g$1();
	return import_react.useMemo(() => Array.from(e.keys()).reduce((t, i) => (n) => /* @__PURE__ */ import_react.createElement(t, null, /* @__PURE__ */ import_react.createElement(i.Provider, {
		...n,
		value: e.get(i)
	})), (t) => /* @__PURE__ */ import_react.createElement(h, { ...t })), [e]);
}
function x(e) {
	if (typeof requestAnimationFrame == "function") {
		const i = requestAnimationFrame(e);
		return () => cancelAnimationFrame(i);
	}
	const t = setTimeout(e, 16);
	return () => clearTimeout(t);
}
function N() {
	if (!import_react.Activity) throw new Error("its-fine: useActivityBridge requires React 19.2 or later!");
	const e = m(), [t] = import_react.useState(() => {
		const i = [];
		let n = !1;
		l(e, !0, (u) => {
			var c, a;
			if (u.elementType === import_react.Activity) {
				const y = ((c = u.child) == null ? void 0 : c.tag) === 22 ? u.child.stateNode : null;
				if (typeof (y == null ? void 0 : y._visibility) != "number") throw new Error("its-fine: unsupported React Activity internals!");
				i.push(y);
			} else u.tag === 22 && ((a = u.return) == null ? void 0 : a.elementType) !== import_react.Activity && (n = !0);
		});
		let o = "hidden";
		const d = /* @__PURE__ */ new Set();
		let s;
		const f = {
			mounted: !1,
			connected: !1,
			subscribe(u) {
				return d.add(u), () => {
					d.delete(u);
				};
			},
			sync(u) {
				f.mounted && !f.connected && n && i.length > 0 ? s || (s = x(() => {
					s = void 0, f.sync(!0);
				})) : (s?.(), s = void 0);
				let c = o;
				if (f.mounted ? f.connected ? c = "visible" : u && (c = i.every((a) => (a._visibility & 1) !== 0) ? "visible" : "hidden") : c = "hidden", o !== c) {
					o = c;
					for (const a of d) a();
				}
			},
			Bridge({ children: u }) {
				return /* @__PURE__ */ import_react.createElement(import_react.Activity, { mode: import_react.useSyncExternalStore(f.subscribe, () => o, () => "hidden") }, u);
			}
		};
		return f;
	});
	return import_react.useInsertionEffect(() => (t.mounted = !0, queueMicrotask(() => t.sync(!1)), () => {
		t.mounted = !1, queueMicrotask(() => t.sync(!1));
	}), [t]), import_react.useLayoutEffect(() => (t.connected = !0, t.sync(!1), () => {
		t.connected = !1, t.sync(!0);
	}), [t]), t.Bridge;
}
// ../../Web Game/choo-choo-pop/node_modules/@react-three/fiber/dist/events-e51d7528.esm.js
var import_scheduler = /* @__PURE__ */ __toESM(require_scheduler());
var threeTypes = /*#__PURE__*/ Object.freeze({ __proto__: null });
/**
* Safely flush async effects when testing, simulating a legacy root.
* @deprecated Import from React instead. import { act } from 'react'
*/
var act = import_react.act;
/**
* An SSR-friendly useLayoutEffect.
*
* React currently throws a warning when using useLayoutEffect on the server.
* To get around it, we can conditionally useEffect on the server (no-op) and
* useLayoutEffect elsewhere.
*
* @see https://github.com/facebook/react/issues/14927
*/
var useIsomorphicLayoutEffect = /* @__PURE__ */ ((_window$document, _window$navigator) => typeof window !== "undefined" && (((_window$document = window.document) == null ? void 0 : _window$document.createElement) || ((_window$navigator = window.navigator) == null ? void 0 : _window$navigator.product) === "ReactNative"))() ? import_react.useLayoutEffect : import_react.useEffect;
function useMutableCallback(fn) {
	const ref = import_react.useRef(fn);
	useIsomorphicLayoutEffect(() => void (ref.current = fn), [fn]);
	return ref;
}
function Gate({ promise, onSettled }) {
	import_react.use(promise);
	useIsomorphicLayoutEffect(onSettled, [onSettled]);
	return null;
}
/** Waits for a promise in a null subtree, re-rendering the caller once it settles either way. */
function useGate() {
	const [promise, setPromise] = import_react.useState(null);
	const onSettled = import_react.useCallback(() => setPromise(null), []);
	const waitFor = import_react.useCallback((next) => setPromise((current) => current != null ? current : Promise.resolve(next).then(() => {}, () => {})), []);
	return [promise ? /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: null,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Gate, {
			promise,
			onSettled
		})
	}) : null, waitFor];
}
var useActivityBridge = import_react.Activity ? N : () => import_react.Fragment;
/**
* Bridges Context, StrictMode, and Activity visibility from a primary renderer.
*/
function useBridge() {
	const fiber = m();
	const ContextBridge = M$1();
	const ActivityBridge = useActivityBridge();
	return import_react.useMemo(() => ({ children }) => {
		const Root = !!l(fiber, true, (node) => node.type === import_react.StrictMode) ? import_react.StrictMode : import_react.Fragment;
		return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Root, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ActivityBridge, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ContextBridge, { children }) }) });
	}, [
		fiber,
		ContextBridge,
		ActivityBridge
	]);
}
function Block({ set }) {
	useIsomorphicLayoutEffect(() => {
		set(new Promise(() => null));
		return () => set(false);
	}, [set]);
	return null;
}
var ErrorBoundary = /* @__PURE__ */ ((_ErrorBoundary) => (_ErrorBoundary = class ErrorBoundary extends import_react.Component {
	constructor(...args) {
		super(...args);
		this.state = { error: false };
	}
	componentDidCatch(err) {
		this.props.set(err);
	}
	render() {
		return this.state.error ? null : this.props.children;
	}
}, _ErrorBoundary.getDerivedStateFromError = () => ({ error: true }), _ErrorBoundary))();
/**
* Returns the instance's initial (outmost) root.
*/
function findInitialRoot(instance) {
	let root = instance.root;
	while (root.getState().previousRoot) root = root.getState().previousRoot;
	return root;
}
var isOrthographicCamera = (def) => def && def.isOrthographicCamera;
var isRef = (obj) => obj && obj.hasOwnProperty("current");
var isColorRepresentation = (value) => value != null && (typeof value === "string" || typeof value === "number" || value.isColor);
var noop = () => {};
function calculateDpr(dpr) {
	var _window$devicePixelRa;
	const target = typeof window !== "undefined" ? (_window$devicePixelRa = window.devicePixelRatio) != null ? _window$devicePixelRa : 2 : 1;
	return Array.isArray(dpr) ? Math.min(Math.max(dpr[0], target), dpr[1]) : dpr;
}
/**
* Calls `onChange` whenever window.devicePixelRatio changes: moving to another display or zooming.
* Neither resizes the canvas, so resize observers won't see it. A resolution query only matches the
* current ratio, so it is re-created after every change. Returns the unsubscribe function.
*/
function watchDpr(onChange) {
	if (typeof window === "undefined" || typeof window.matchMedia !== "function" || !window.devicePixelRatio) return () => {};
	let query;
	const listen = () => {
		try {
			var _query, _query2;
			query = window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`);
			if (typeof ((_query = query) == null ? void 0 : _query.addEventListener) === "function") query.addEventListener("change", handleChange);
			else (_query2 = query) == null || _query2.addListener == null || _query2.addListener(handleChange);
		} catch {
			query = void 0;
		}
	};
	const unlisten = () => {
		var _query3, _query4;
		if (typeof ((_query3 = query) == null ? void 0 : _query3.removeEventListener) === "function") query.removeEventListener("change", handleChange);
		else (_query4 = query) == null || _query4.removeListener == null || _query4.removeListener(handleChange);
		query = void 0;
	};
	const handleChange = () => {
		unlisten();
		listen();
		onChange();
	};
	listen();
	return unlisten;
}
/**
* Returns instance root state
*/
function getRootState(obj) {
	var _r3f;
	return (_r3f = obj.__r3f) == null ? void 0 : _r3f.root.getState();
}
var is = {
	obj: (a) => a === Object(a) && !is.arr(a) && typeof a !== "function",
	fun: (a) => typeof a === "function",
	str: (a) => typeof a === "string",
	num: (a) => typeof a === "number",
	boo: (a) => typeof a === "boolean",
	und: (a) => a === void 0,
	nul: (a) => a === null,
	arr: (a) => Array.isArray(a),
	equ(a, b, { arrays = "shallow", objects = "reference", strict = true } = {}) {
		if (typeof a !== typeof b || !!a !== !!b) return false;
		if (is.str(a) || is.num(a) || is.boo(a)) return a === b;
		const isObj = is.obj(a);
		if (isObj && objects === "reference") return a === b;
		const isArr = is.arr(a);
		if (isArr && arrays === "reference") return a === b;
		if ((isArr || isObj) && a === b) return true;
		let i;
		for (i in a) if (!(i in b)) return false;
		if (isObj && arrays === "shallow" && objects === "shallow") {
			for (i in strict ? b : a) if (!is.equ(a[i], b[i], {
				strict,
				objects: "reference"
			})) return false;
		} else for (i in strict ? b : a) if (a[i] !== b[i]) return false;
		if (is.und(i)) {
			if (isArr && a.length === 0 && b.length === 0) return true;
			if (isObj && Object.keys(a).length === 0 && Object.keys(b).length === 0) return true;
			if (a !== b) return false;
		}
		return true;
	}
};
function buildGraph(object) {
	const data = {
		nodes: {},
		materials: {},
		meshes: {}
	};
	if (object) object.traverse((obj) => {
		if (obj.name) data.nodes[obj.name] = obj;
		if (obj.material && !data.materials[obj.material.name]) data.materials[obj.material.name] = obj.material;
		if (obj.isMesh && !data.meshes[obj.name]) data.meshes[obj.name] = obj;
	});
	return data;
}
function dispose(obj) {
	if (obj.type !== "Scene") obj.dispose == null || obj.dispose();
	for (const p in obj) {
		const prop = obj[p];
		if ((prop == null ? void 0 : prop.type) !== "Scene") prop == null || prop.dispose == null || prop.dispose();
	}
}
var REACT_INTERNAL_PROPS = [
	"children",
	"key",
	"ref"
];
function getInstanceProps(pendingProps) {
	const props = {};
	for (const key in pendingProps) if (!REACT_INTERNAL_PROPS.includes(key)) props[key] = pendingProps[key];
	return props;
}
function prepare(target, root, type, props) {
	const object = target;
	let instance = object == null ? void 0 : object.__r3f;
	if (!instance) {
		instance = {
			root,
			type,
			parent: null,
			children: [],
			props: getInstanceProps(props),
			object,
			eventCount: 0,
			handlers: {},
			previousVisible: void 0,
			isHidden: false
		};
		if (object) object.__r3f = instance;
	}
	return instance;
}
function resolve(root, key) {
	if (!key.includes("-")) return {
		root,
		key,
		target: root[key]
	};
	if (key in root) return {
		root,
		key,
		target: root[key]
	};
	let target = root;
	const parts = key.split("-");
	for (const part of parts) {
		if (typeof target !== "object" || target === null) {
			if (target !== void 0) {
				const remaining = parts.slice(parts.indexOf(part)).join("-");
				return {
					root: target,
					key: remaining,
					target: void 0
				};
			}
			return {
				root,
				key,
				target: void 0
			};
		}
		key = part;
		root = target;
		target = target[key];
	}
	return {
		root,
		key,
		target
	};
}
var INDEX_REGEX = /-\d+$/;
function attach(parent, child) {
	if (is.str(child.props.attach)) {
		if (INDEX_REGEX.test(child.props.attach)) {
			const index = child.props.attach.replace(INDEX_REGEX, "");
			const { root, key } = resolve(parent.object, index);
			if (!Array.isArray(root[key])) root[key] = [];
		}
		const { root, key } = resolve(parent.object, child.props.attach);
		child.previousAttach = root[key];
		root[key] = child.object;
	} else if (is.fun(child.props.attach)) child.previousAttach = child.props.attach(parent.object, child.object);
}
function detach(parent, child) {
	if (is.str(child.props.attach)) {
		const { root, key } = resolve(parent.object, child.props.attach);
		const previous = child.previousAttach;
		if (previous === void 0) delete root[key];
		else root[key] = previous;
	} else child.previousAttach == null || child.previousAttach(parent.object, child.object);
	delete child.previousAttach;
}
var RESERVED_PROPS = [
	...REACT_INTERNAL_PROPS,
	"args",
	"dispose",
	"attach",
	"object",
	"onUpdate",
	"dispose"
];
var MEMOIZED_PROTOTYPES = /* @__PURE__ */ new Map();
function getMemoizedPrototype(root) {
	let ctor = MEMOIZED_PROTOTYPES.get(root.constructor);
	try {
		if (!ctor) {
			ctor = new root.constructor();
			MEMOIZED_PROTOTYPES.set(root.constructor, ctor);
		}
	} catch (e) {}
	return ctor;
}
function diffProps(instance, newProps) {
	const changedProps = {};
	for (const prop in newProps) {
		if (RESERVED_PROPS.includes(prop)) continue;
		if (is.equ(newProps[prop], instance.props[prop])) continue;
		changedProps[prop] = newProps[prop];
		for (const other in newProps) if (other.startsWith(`${prop}-`)) changedProps[other] = newProps[other];
	}
	for (const prop in instance.props) {
		if (RESERVED_PROPS.includes(prop) || newProps.hasOwnProperty(prop)) continue;
		const { root, key } = resolve(instance.object, prop);
		if (root.constructor && root.constructor.length === 0) {
			const ctor = getMemoizedPrototype(root);
			if (!is.und(ctor)) changedProps[prop] = ctor[key];
		} else changedProps[prop] = 0;
	}
	return changedProps;
}
var colorMaps = [
	"map",
	"emissiveMap",
	"sheenColorMap",
	"specularColorMap",
	"envMap"
];
var EVENT_REGEX = /^on(Pointer|Click|DoubleClick|ContextMenu|Wheel)/;
function applyProps(object, props) {
	var _instance$object;
	const instance = object.__r3f;
	const rootState = instance && findInitialRoot(instance).getState();
	const prevHandlers = instance == null ? void 0 : instance.eventCount;
	for (const prop in props) {
		let value = props[prop];
		if (RESERVED_PROPS.includes(prop)) continue;
		if (instance && EVENT_REGEX.test(prop)) {
			if (typeof value === "function") instance.handlers[prop] = value;
			else delete instance.handlers[prop];
			instance.eventCount = Object.keys(instance.handlers).length;
			continue;
		}
		if (value === void 0) continue;
		if (prop === "visible" && instance != null && instance.isHidden && instance.previousVisible !== void 0) {
			instance.previousVisible = value;
			continue;
		}
		let { root, key, target } = resolve(object, prop);
		if (target === void 0 && (typeof root !== "object" || root === null)) throw Error(`R3F: Cannot set "${prop}". Ensure it is an object before setting "${key}".`);
		if (target instanceof Layers && value instanceof Layers) target.mask = value.mask;
		else if (target instanceof Color && isColorRepresentation(value)) target.set(value);
		else if (target !== null && typeof target === "object" && typeof target.set === "function" && typeof target.copy === "function" && value != null && value.constructor && target.constructor === value.constructor) target.copy(value);
		else if (target !== null && typeof target === "object" && typeof target.set === "function" && Array.isArray(value)) {
			if (typeof target.fromArray === "function") target.fromArray(value);
			else target.set(...value);
		} else if (target !== null && typeof target === "object" && typeof target.set === "function" && typeof value === "number") {
			if (typeof target.setScalar === "function") target.setScalar(value);
			else target.set(value);
		} else if (root instanceof ShaderMaterial && key === "uniforms" && is.obj(value)) {
			if (!is.obj(root.uniforms)) root.uniforms = {};
			const uniforms = root.uniforms;
			const nextUniforms = value;
			for (const name in nextUniforms) {
				const uniform = nextUniforms[name];
				const targetUniform = uniforms[name];
				if (targetUniform) Object.assign(targetUniform, uniform);
				else uniforms[name] = { ...uniform };
			}
		} else {
			var _root$key;
			root[key] = value;
			if (rootState && !rootState.linear && colorMaps.includes(key) && (_root$key = root[key]) != null && _root$key.isTexture && root[key].format === 1023 && root[key].type === 1009) root[key].colorSpace = SRGBColorSpace;
		}
	}
	if (instance != null && instance.parent && rootState != null && rootState.internal && (_instance$object = instance.object) != null && _instance$object.isObject3D && prevHandlers !== instance.eventCount) {
		const object = instance.object;
		const index = rootState.internal.interaction.indexOf(object);
		if (index > -1) rootState.internal.interaction.splice(index, 1);
		if (instance.eventCount && object.raycast !== null) rootState.internal.interaction.push(object);
	}
	if (instance && instance.props.attach === void 0) {
		if (instance.object.isBufferGeometry) instance.props.attach = "geometry";
		else if (instance.object.isMaterial) instance.props.attach = "material";
	}
	if (instance) invalidateInstance(instance);
	return object;
}
function invalidateInstance(instance) {
	var _instance$root;
	if (!instance.parent) return;
	instance.props.onUpdate == null || instance.props.onUpdate(instance.object);
	const state = (_instance$root = instance.root) == null ? void 0 : _instance$root.getState == null ? void 0 : _instance$root.getState();
	if (state && state.internal.frames === 0) state.invalidate();
}
function updateCamera(camera, size) {
	if (camera.manual) return;
	if (isOrthographicCamera(camera)) {
		camera.left = size.width / -2;
		camera.right = size.width / 2;
		camera.top = size.height / 2;
		camera.bottom = size.height / -2;
	} else camera.aspect = size.width / size.height;
	camera.updateProjectionMatrix();
}
var isObject3D = (object) => object == null ? void 0 : object.isObject3D;
function makeId(event) {
	return (event.eventObject || event.object).uuid + "/" + event.index + event.instanceId;
}
/**
* Release pointer captures.
* This is called by releasePointerCapture in the API, and when an object is removed.
*/
function releaseInternalPointerCapture(capturedMap, obj, captures, pointerId) {
	const captureData = captures.get(obj);
	if (captureData) {
		captures.delete(obj);
		if (captures.size === 0) {
			capturedMap.delete(pointerId);
			captureData.target.releasePointerCapture(pointerId);
		}
	}
}
/** This function transfers all interactivity state from one object instance to another. Used when swapping instances due to reconstruction. */
function swapInteractivity(store, object, newObject) {
	const { internal } = store.getState();
	for (let i = 0; i < internal.interaction.length; i++) if (internal.interaction[i] === object) internal.interaction[i] = newObject;
	for (let i = 0; i < internal.initialHits.length; i++) if (internal.initialHits[i] === object) internal.initialHits[i] = newObject;
	internal.hovered.forEach((value, key) => {
		if (value.eventObject === object || value.object === object) {
			internal.hovered.delete(key);
			const next = {
				...value,
				eventObject: value.eventObject === object ? newObject : value.eventObject,
				object: value.object === object ? newObject : value.object
			};
			internal.hovered.set(makeId(next), next);
		}
	});
	internal.capturedMap.forEach((captures) => {
		for (const [key, captureData] of Array.from(captures)) {
			const { intersection } = captureData;
			if (key !== object && intersection.object !== object && intersection.eventObject !== object) continue;
			if (key === object) captures.delete(key);
			captures.set(key === object ? newObject : key, {
				...captureData,
				intersection: {
					...intersection,
					object: intersection.object === object ? newObject : intersection.object,
					eventObject: intersection.eventObject === object ? newObject : intersection.eventObject
				}
			});
		}
	});
}
function removeInteractivity(store, object) {
	const { internal } = store.getState();
	internal.interaction = internal.interaction.filter((o) => o !== object);
	internal.initialHits = internal.initialHits.filter((o) => o !== object);
	internal.hovered.forEach((value, key) => {
		if (value.eventObject === object || value.object === object) internal.hovered.delete(key);
	});
	internal.capturedMap.forEach((captures, pointerId) => {
		releaseInternalPointerCapture(internal.capturedMap, object, captures, pointerId);
	});
}
function createEvents(store) {
	/** Calculates delta */
	function calculateDistance(event) {
		const { internal } = store.getState();
		const dx = event.offsetX - internal.initialClick[0];
		const dy = event.offsetY - internal.initialClick[1];
		return Math.round(Math.sqrt(dx * dx + dy * dy));
	}
	/** Returns true if an instance has a valid pointer-event registered, this excludes scroll, clicks etc */
	function filterPointerEvents(objects) {
		return objects.filter((obj) => [
			"Move",
			"Over",
			"Enter",
			"Out",
			"Leave"
		].some((name) => {
			var _r3f;
			return (_r3f = obj.__r3f) == null ? void 0 : _r3f.handlers["onPointer" + name];
		}));
	}
	function intersect(event, filter) {
		const state = store.getState();
		const duplicates = /* @__PURE__ */ new Set();
		const intersections = [];
		const eventsObjects = filter ? filter(state.internal.interaction) : state.internal.interaction;
		for (let i = 0; i < eventsObjects.length; i++) {
			const state = getRootState(eventsObjects[i]);
			if (state) state.raycaster.camera = void 0;
		}
		if (!state.previousRoot) state.events.compute == null || state.events.compute(event, state);
		function handleRaycast(obj) {
			const state = getRootState(obj);
			if (!state || !state.events.enabled || state.raycaster.camera === null) return [];
			if (state.raycaster.camera === void 0) {
				var _state$previousRoot;
				state.events.compute == null || state.events.compute(event, state, (_state$previousRoot = state.previousRoot) == null ? void 0 : _state$previousRoot.getState());
				if (state.raycaster.camera === void 0) state.raycaster.camera = null;
			}
			return state.raycaster.camera ? state.raycaster.intersectObject(obj, true) : [];
		}
		let hits = eventsObjects.flatMap(handleRaycast).sort((a, b) => {
			const aState = getRootState(a.object);
			const bState = getRootState(b.object);
			if (!aState || !bState) return a.distance - b.distance;
			return bState.events.priority - aState.events.priority || a.distance - b.distance;
		}).filter((item) => {
			const id = makeId(item);
			if (duplicates.has(id)) return false;
			duplicates.add(id);
			return true;
		});
		if (state.events.filter) hits = state.events.filter(hits, state);
		for (const hit of hits) {
			let eventObject = hit.object;
			while (eventObject) {
				var _r3f2;
				if ((_r3f2 = eventObject.__r3f) != null && _r3f2.eventCount) intersections.push({
					...hit,
					eventObject
				});
				eventObject = eventObject.parent;
			}
		}
		if ("pointerId" in event && state.internal.capturedMap.has(event.pointerId)) {
			for (let captureData of state.internal.capturedMap.get(event.pointerId).values()) if (!duplicates.has(makeId(captureData.intersection))) intersections.push(captureData.intersection);
		}
		return intersections;
	}
	/**  Handles intersections by forwarding them to handlers */
	function handleIntersects(intersections, event, delta, callback) {
		if (intersections.length) {
			const localState = { stopped: false };
			for (const hit of intersections) {
				let state = getRootState(hit.object);
				if (!state) hit.object.traverseAncestors((obj) => {
					const parentState = getRootState(obj);
					if (parentState) {
						state = parentState;
						return false;
					}
				});
				if (state) {
					const { raycaster, pointer, camera, internal } = state;
					const unprojectedPoint = new Vector3(pointer.x, pointer.y, 0).unproject(camera);
					const hasPointerCapture = (id) => {
						var _internal$capturedMap, _internal$capturedMap2;
						return (_internal$capturedMap = (_internal$capturedMap2 = internal.capturedMap.get(id)) == null ? void 0 : _internal$capturedMap2.has(hit.eventObject)) != null ? _internal$capturedMap : false;
					};
					const setPointerCapture = (id) => {
						const captureData = {
							intersection: hit,
							target: event.target
						};
						if (internal.capturedMap.has(id)) internal.capturedMap.get(id).set(hit.eventObject, captureData);
						else internal.capturedMap.set(id, /* @__PURE__ */ new Map([[hit.eventObject, captureData]]));
						event.target.setPointerCapture(id);
					};
					const releasePointerCapture = (id) => {
						const captures = internal.capturedMap.get(id);
						if (captures) releaseInternalPointerCapture(internal.capturedMap, hit.eventObject, captures, id);
					};
					let extractEventProps = {};
					for (let prop in event) {
						let property = event[prop];
						if (typeof property !== "function") extractEventProps[prop] = property;
					}
					let raycastEvent = {
						...hit,
						...extractEventProps,
						pointer,
						intersections,
						stopped: localState.stopped,
						delta,
						unprojectedPoint,
						ray: raycaster.ray,
						camera,
						stopPropagation() {
							const capturesForPointer = "pointerId" in event && internal.capturedMap.get(event.pointerId);
							if (!capturesForPointer || capturesForPointer.has(hit.eventObject)) {
								raycastEvent.stopped = localState.stopped = true;
								if (internal.hovered.size && Array.from(internal.hovered.values()).find((i) => i.eventObject === hit.eventObject)) cancelPointer([...intersections.slice(0, intersections.indexOf(hit)), hit]);
							}
						},
						target: {
							hasPointerCapture,
							setPointerCapture,
							releasePointerCapture
						},
						currentTarget: {
							hasPointerCapture,
							setPointerCapture,
							releasePointerCapture
						},
						nativeEvent: event
					};
					callback(raycastEvent);
					if (localState.stopped === true) break;
				}
			}
		}
		return intersections;
	}
	function cancelPointer(intersections) {
		const { internal } = store.getState();
		for (const hoveredObj of internal.hovered.values()) if (!intersections.length || !intersections.find((hit) => hit.object === hoveredObj.object && hit.index === hoveredObj.index && hit.instanceId === hoveredObj.instanceId)) {
			const instance = hoveredObj.eventObject.__r3f;
			internal.hovered.delete(makeId(hoveredObj));
			if (instance != null && instance.eventCount) {
				const handlers = instance.handlers;
				const data = {
					...hoveredObj,
					intersections
				};
				handlers.onPointerOut == null || handlers.onPointerOut(data);
				handlers.onPointerLeave == null || handlers.onPointerLeave(data);
			}
		}
	}
	function pointerMissed(event, objects) {
		for (let i = 0; i < objects.length; i++) {
			const instance = objects[i].__r3f;
			instance == null || instance.handlers.onPointerMissed == null || instance.handlers.onPointerMissed(event);
		}
	}
	function handlePointer(name) {
		switch (name) {
			case "onPointerLeave":
			case "onPointerCancel": return () => cancelPointer([]);
			case "onLostPointerCapture": return (event) => {
				const { internal } = store.getState();
				if ("pointerId" in event && internal.capturedMap.has(event.pointerId)) requestAnimationFrame(() => {
					if (internal.capturedMap.has(event.pointerId)) {
						internal.capturedMap.delete(event.pointerId);
						cancelPointer([]);
					}
				});
			};
		}
		return function handleEvent(event) {
			const { onPointerMissed, internal } = store.getState();
			internal.lastEvent.current = event;
			const isPointerMove = name === "onPointerMove";
			const isClickEvent = name === "onClick" || name === "onContextMenu" || name === "onDoubleClick";
			const hits = intersect(event, isPointerMove ? filterPointerEvents : void 0);
			const delta = isClickEvent ? calculateDistance(event) : 0;
			if (name === "onPointerDown") {
				internal.initialClick = [event.offsetX, event.offsetY];
				internal.initialHits = hits.map((hit) => hit.eventObject);
			}
			if (isClickEvent && !hits.length) {
				if (delta <= 2) {
					pointerMissed(event, internal.interaction);
					if (onPointerMissed) onPointerMissed(event);
				}
			}
			if (isPointerMove) cancelPointer(hits);
			function onIntersect(data) {
				const eventObject = data.eventObject;
				const instance = eventObject.__r3f;
				if (!(instance != null && instance.eventCount)) return;
				const handlers = instance.handlers;
				if (isPointerMove) {
					if (handlers.onPointerOver || handlers.onPointerEnter || handlers.onPointerOut || handlers.onPointerLeave) {
						const id = makeId(data);
						const hoveredItem = internal.hovered.get(id);
						if (!hoveredItem) {
							internal.hovered.set(id, data);
							handlers.onPointerOver == null || handlers.onPointerOver(data);
							handlers.onPointerEnter == null || handlers.onPointerEnter(data);
						} else if (hoveredItem.stopped) data.stopPropagation();
					}
					handlers.onPointerMove == null || handlers.onPointerMove(data);
				} else {
					const handler = handlers[name];
					if (handler) {
						if (!isClickEvent || internal.initialHits.includes(eventObject)) {
							pointerMissed(event, internal.interaction.filter((object) => !internal.initialHits.includes(object)));
							handler(data);
						}
					} else if (isClickEvent && internal.initialHits.includes(eventObject)) pointerMissed(event, internal.interaction.filter((object) => !internal.initialHits.includes(object)));
				}
			}
			handleIntersects(hits, event, delta, onIntersect);
		};
	}
	return { handlePointer };
}
var isPromiseLike = (value) => typeof (value == null ? void 0 : value.then) === "function";
/** A promise tagged with its state, the protocol React's `use` reads */
var fulfilled = (value) => Object.assign(Promise.resolve(value), {
	status: "fulfilled",
	value
});
var rejected = (reason) => {
	const promise = Promise.reject(reason);
	promise.catch(() => {});
	return Object.assign(promise, {
		status: "rejected",
		reason
	});
};
/** A pending promise, settled once from outside. Its `status` updates the moment it settles */
var deferred = () => {
	let resolve;
	let reject;
	const promise = new Promise((yes, no) => {
		resolve = (value) => {
			Object.assign(promise, {
				status: "fulfilled",
				value
			});
			yes(value);
		};
		reject = (reason) => {
			Object.assign(promise, {
				status: "rejected",
				reason
			});
			no(reason);
		};
	});
	promise.status = "pending";
	promise.catch(() => {});
	return {
		promise,
		resolve,
		reject
	};
};
/** Renderer creation and resource release. Root lifetime decides when release is safe. */
var isRenderer = (def) => !!(def != null && def.render);
/** The renderer to configure, or a promise for one from an async factory */
function createRenderer(canvas, gl) {
	const defaults = {
		canvas,
		powerPreference: "high-performance",
		antialias: true,
		alpha: true
	};
	if (typeof gl === "function") return gl(defaults);
	if (isRenderer(gl)) return gl;
	return new WebGLRenderer({
		...defaults,
		...gl
	});
}
/**
* Frees a renderer R3F built. WebGLRenderer.dispose() releases programs and caches but keeps its
* context until garbage collection, and browsers cap live WebGL contexts, so the context is lost
* after it. A WebGPURenderer (from a factory) releases its device and context inside dispose().
*/
function disposeRenderer(gl) {
	if ((gl.hasInitialized == null ? void 0 : gl.hasInitialized()) === false) return;
	const disposed = attempt$1(() => {
		var _gl$renderLists;
		return gl.dispose ? gl.dispose() : (_gl$renderLists = gl.renderLists) == null ? void 0 : _gl$renderLists.dispose == null ? void 0 : _gl$renderLists.dispose();
	});
	if (isPromiseLike(disposed)) return Promise.resolve(disposed).catch((error) => console.warn("[R3F] Error disposing renderer", error)).then(() => attempt$1(() => gl.forceContextLoss == null ? void 0 : gl.forceContextLoss()));
	attempt$1(() => gl.forceContextLoss == null ? void 0 : gl.forceContextLoss());
}
/** Owned renderers are disposed. Caller-provided renderers release caches and their context. */
function releaseRenderer(gl, owned) {
	if (!gl) return;
	if (owned) return disposeRenderer(gl);
	attempt$1(() => {
		var _gl$renderLists2;
		return (_gl$renderLists2 = gl.renderLists) == null ? void 0 : _gl$renderLists2.dispose == null ? void 0 : _gl$renderLists2.dispose();
	});
	attempt$1(() => gl.forceContextLoss == null ? void 0 : gl.forceContextLoss());
}
function attempt$1(step) {
	try {
		return step();
	} catch (error) {
		console.warn("[R3F] Error while unmounting root; teardown may be incomplete:", error);
	}
}
var context = /* @__PURE__ */ import_react.createContext(null);
var createStore = (invalidate, advance) => {
	const rootStore = createWithEqualityFn((set, get) => {
		const position = new Vector3();
		const defaultTarget = new Vector3();
		const tempTarget = new Vector3();
		function getCurrentViewport(camera = get().camera, target = defaultTarget, size = get().size) {
			const { width, height, top, left } = size;
			const aspect = width / height;
			if (target.isVector3) tempTarget.copy(target);
			else tempTarget.set(...target);
			const distance = camera.getWorldPosition(position).distanceTo(tempTarget);
			if (isOrthographicCamera(camera)) return {
				width: width / camera.zoom,
				height: height / camera.zoom,
				top,
				left,
				factor: 1,
				distance,
				aspect
			};
			else {
				const fov = camera.fov * Math.PI / 180;
				const h = 2 * Math.tan(fov / 2) * distance;
				const w = h * (width / height);
				return {
					width: w,
					height: h,
					top,
					left,
					factor: width / w,
					distance,
					aspect
				};
			}
		}
		let performanceTimeout = void 0;
		const setPerformanceCurrent = (current) => set((state) => ({ performance: {
			...state.performance,
			current
		} }));
		const pointer = new Vector2();
		return {
			set,
			get,
			gl: null,
			camera: null,
			raycaster: null,
			events: {
				priority: 1,
				enabled: true,
				connected: false
			},
			scene: null,
			xr: null,
			invalidate: (frames = 1) => invalidate(get(), frames),
			advance: (timestamp, runGlobalEffects) => advance(timestamp, runGlobalEffects, get()),
			legacy: false,
			linear: false,
			flat: false,
			controls: null,
			clock: new Clock(),
			pointer,
			mouse: pointer,
			frameloop: "always",
			onPointerMissed: void 0,
			performance: {
				current: 1,
				min: .5,
				max: 1,
				debounce: 200,
				regress: () => {
					const state = get();
					if (performanceTimeout) clearTimeout(performanceTimeout);
					if (state.performance.current !== state.performance.min) setPerformanceCurrent(state.performance.min);
					performanceTimeout = setTimeout(() => setPerformanceCurrent(get().performance.max), state.performance.debounce);
				}
			},
			size: {
				width: 0,
				height: 0,
				top: 0,
				left: 0
			},
			viewport: {
				initialDpr: 0,
				dpr: 0,
				width: 0,
				height: 0,
				top: 0,
				left: 0,
				aspect: 0,
				distance: 0,
				factor: 0,
				getCurrentViewport
			},
			setEvents: (events) => set((state) => ({
				...state,
				events: {
					...state.events,
					...events
				}
			})),
			setSize: (width, height, top = 0, left = 0) => {
				const camera = get().camera;
				const size = {
					width,
					height,
					top,
					left
				};
				set((state) => ({
					size,
					viewport: {
						...state.viewport,
						...getCurrentViewport(camera, defaultTarget, size)
					}
				}));
			},
			setDpr: (dpr) => set((state) => {
				const resolved = calculateDpr(dpr);
				return { viewport: {
					...state.viewport,
					dpr: resolved,
					initialDpr: state.viewport.initialDpr || resolved
				} };
			}),
			setFrameloop: (frameloop = "always") => {
				const clock = get().clock;
				clock.stop();
				clock.elapsedTime = 0;
				if (frameloop !== "never") {
					clock.start();
					clock.elapsedTime = 0;
				}
				set(() => ({ frameloop }));
			},
			previousRoot: void 0,
			internal: {
				interaction: [],
				hovered: /* @__PURE__ */ new Map(),
				subscribers: [],
				initialClick: [0, 0],
				initialHits: [],
				capturedMap: /* @__PURE__ */ new Map(),
				lastEvent: /*#__PURE__*/ import_react.createRef(),
				active: false,
				frames: 0,
				priority: 0,
				subscribe: (ref, priority, store) => {
					const internal = get().internal;
					internal.priority = internal.priority + (priority > 0 ? 1 : 0);
					internal.subscribers.push({
						ref,
						priority,
						store
					});
					internal.subscribers = internal.subscribers.sort((a, b) => a.priority - b.priority);
					return () => {
						const internal = get().internal;
						if (internal != null && internal.subscribers) {
							internal.priority = internal.priority - (priority > 0 ? 1 : 0);
							internal.subscribers = internal.subscribers.filter((s) => s.ref !== ref);
						}
					};
				}
			}
		};
	});
	const state = rootStore.getState();
	let oldSize = state.size;
	let oldDpr = state.viewport.dpr;
	let oldCamera = state.camera;
	rootStore.subscribe(() => {
		const { camera, size, viewport, gl, set } = rootStore.getState();
		if (size.width !== oldSize.width || size.height !== oldSize.height || viewport.dpr !== oldDpr) {
			oldSize = size;
			oldDpr = viewport.dpr;
			updateCamera(camera, size);
			if (viewport.dpr > 0) gl.setPixelRatio(viewport.dpr);
			const updateStyle = typeof HTMLCanvasElement !== "undefined" && gl.domElement instanceof HTMLCanvasElement;
			gl.setSize(size.width, size.height, updateStyle);
		}
		if (camera !== oldCamera) {
			oldCamera = camera;
			set((state) => ({ viewport: {
				...state.viewport,
				...state.viewport.getCurrentViewport(camera)
			} }));
		}
	});
	rootStore.subscribe((state) => invalidate(state));
	return rootStore;
};
/**
* Exposes an object's {@link Instance}.
* @see https://docs.pmnd.rs/react-three-fiber/api/additional-exports#useInstanceHandle
*
* **Note**: this is an escape hatch to react-internal fields. Expect this to change significantly between versions.
*/
function useInstanceHandle(ref) {
	const instance = import_react.useRef(null);
	import_react.useImperativeHandle(instance, () => ref.current.__r3f, [ref]);
	return instance;
}
/**
* Returns the R3F Canvas' Zustand store. Useful for [transient updates](https://github.com/pmndrs/zustand#transient-updates-for-often-occurring-state-changes).
* @see https://docs.pmnd.rs/react-three-fiber/api/hooks#usestore
*/
function useStore() {
	const store = import_react.useContext(context);
	if (!store) throw new Error("R3F: Hooks can only be used within the Canvas component!");
	return store;
}
/**
* Accesses R3F's internal state, containing renderer, canvas, scene, etc.
* @see https://docs.pmnd.rs/react-three-fiber/api/hooks#usethree
*/
function useThree(selector = (state) => state, equalityFn) {
	return useStore()(selector, equalityFn);
}
/**
* Executes a callback before render in a shared frame loop.
* Can order effects with render priority or manually render with a positive priority.
* @see https://docs.pmnd.rs/react-three-fiber/api/hooks#useframe
*/
function useFrame(callback, renderPriority = 0) {
	const store = useStore();
	const subscribe = store.getState().internal.subscribe;
	const ref = useMutableCallback(callback);
	useIsomorphicLayoutEffect(() => subscribe(ref, renderPriority, store), [
		renderPriority,
		subscribe,
		store
	]);
	return null;
}
/**
* Returns a node graph of an object with named nodes & materials.
* @see https://docs.pmnd.rs/react-three-fiber/api/hooks#usegraph
*/
function useGraph(object) {
	return import_react.useMemo(() => buildGraph(object), [object]);
}
var memoizedLoaders = /* @__PURE__ */ new WeakMap();
var isConstructor = (value) => {
	var _value$prototype;
	return typeof value === "function" && (value == null ? void 0 : (_value$prototype = value.prototype) == null ? void 0 : _value$prototype.constructor) === value;
};
function loadingFn(extensions, onProgress) {
	return function(Proto, ...input) {
		let loader;
		if (isConstructor(Proto)) {
			loader = memoizedLoaders.get(Proto);
			if (!loader) {
				loader = new Proto();
				memoizedLoaders.set(Proto, loader);
			}
		} else loader = Proto;
		if (extensions) extensions(loader);
		return Promise.all(input.map((input) => new Promise((res, reject) => loader.load(input, (data) => {
			if (isObject3D(data == null ? void 0 : data.scene)) Object.assign(data, buildGraph(data.scene));
			res(data);
		}, onProgress, (error) => reject(/* @__PURE__ */ new Error(`Could not load ${input}: ${error == null ? void 0 : error.message}`))))));
	};
}
/**
* Synchronously loads and caches assets with a three loader.
*
* Note: this hook's caller must be wrapped with `React.Suspense`
* @see https://docs.pmnd.rs/react-three-fiber/api/hooks#useloader
*/
function useLoader(loader, input, extensions, onProgress) {
	const keys = Array.isArray(input) ? input : [input];
	const results = suspend(loadingFn(extensions, onProgress), [loader, ...keys], { equal: is.equ });
	return Array.isArray(input) ? results : results[0];
}
/**
* Preloads an asset into cache as a side-effect.
*/
useLoader.preload = function(loader, input, extensions) {
	const keys = Array.isArray(input) ? input : [input];
	return preload(loadingFn(extensions), [loader, ...keys]);
};
/**
* Removes a loaded asset from cache.
*/
useLoader.clear = function(loader, input) {
	return clear([loader, ...Array.isArray(input) ? input : [input]]);
};
/**
* @license React
* react-reconciler-constants.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/ var t = 1;
var o = 8;
var r = 32;
var e = 2;
var i$1 = 268435456;
/** What a root has applied, so its next configuration applies only what changed */
var shallow = { objects: "shallow" };
function computeInitialSize(canvas, size) {
	if (!size && typeof HTMLCanvasElement !== "undefined" && canvas instanceof HTMLCanvasElement && canvas.parentElement) {
		const { width, height, top, left } = canvas.parentElement.getBoundingClientRect();
		return {
			width,
			height,
			top,
			left
		};
	} else if (!size && typeof OffscreenCanvas !== "undefined" && canvas instanceof OffscreenCanvas) return {
		width: canvas.width,
		height: canvas.height,
		top: 0,
		left: 0
	};
	return {
		width: 0,
		height: 0,
		top: 0,
		left: 0,
		...size
	};
}
/**
* Applies the inputs that changed since the last configuration applied in full, to a root whose
* renderer is installed. A runtime change, such as setFrameloop or an edit to gl.shadowMap, lasts
* until its input changes. The pixel ratio instead follows the device on every call. Objects and
* arrays compare shallowly, so an equal inline value is unchanged.
*/
function applyRootConfiguration({ store, configuration }, canvas, props) {
	const { gl: glConfig, scene: sceneOptions, camera: cameraOptions, shadows = false, linear = false, flat = false, legacy = false, frameloop = "always", dpr = [1, 2], performance, onPointerMissed } = props;
	const size = computeInitialSize(canvas, props.size);
	const next = {
		...props,
		shadows,
		linear,
		flat,
		legacy,
		frameloop,
		size
	};
	const state = store.getState();
	const gl = state.gl;
	const last = configuration.previous;
	const changed = (key) => !last || !is.equ(next[key], last[key], shallow);
	configuration.previous = void 0;
	let raycaster = state.raycaster;
	if (!raycaster) state.set({ raycaster: raycaster = new Raycaster() });
	if (changed("raycaster")) {
		var _props$raycaster;
		const { params, ...options } = (_props$raycaster = props.raycaster) != null ? _props$raycaster : {};
		applyProps(raycaster, {
			...options,
			params: {
				...raycaster.params,
				...params
			}
		});
	}
	if (!state.camera || state.camera === configuration.camera && changed("camera")) {
		configuration.camera = cameraOptions;
		const isCamera = cameraOptions == null ? void 0 : cameraOptions.isCamera;
		const camera = isCamera ? cameraOptions : props.orthographic ? new OrthographicCamera(0, 0, 0, 0, .1, 1e3) : new PerspectiveCamera(75, 0, .1, 1e3);
		if (!isCamera) {
			camera.position.z = 5;
			if (cameraOptions) {
				applyProps(camera, cameraOptions);
				if (!camera.manual) {
					if ("aspect" in cameraOptions || "left" in cameraOptions || "right" in cameraOptions || "bottom" in cameraOptions || "top" in cameraOptions) {
						camera.manual = true;
						camera.updateProjectionMatrix();
					}
				}
			}
			if (!state.camera && !(cameraOptions != null && cameraOptions.rotation)) camera.lookAt(0, 0, 0);
		}
		state.set({ camera });
		raycaster.camera = camera;
	}
	if (!state.scene) {
		let scene;
		if (sceneOptions != null && sceneOptions.isScene) {
			scene = sceneOptions;
			prepare(scene, store, "", {});
		} else {
			scene = new Scene();
			prepare(scene, store, "", {});
			if (sceneOptions) applyProps(scene, sceneOptions);
		}
		state.set({ scene });
	}
	if (props.events && !state.events.handlers) state.set({ events: props.events(store) });
	if (changed("size")) state.setSize(size.width, size.height, size.top, size.left);
	if (state.viewport.dpr !== calculateDpr(dpr)) state.setDpr(dpr);
	if (changed("frameloop")) state.setFrameloop(frameloop);
	if (changed("onPointerMissed")) state.set({ onPointerMissed });
	if (performance && changed("performance")) state.set((state) => ({ performance: {
		...state.performance,
		...performance
	} }));
	if (!state.xr) {
		var _gl$xr;
		const handleXRFrame = (timestamp, frame) => {
			const state = store.getState();
			if (state.frameloop === "never") return;
			advance(timestamp, true, state, frame);
		};
		const handleSessionChange = () => {
			const state = store.getState();
			state.gl.xr.enabled = state.gl.xr.isPresenting;
			state.gl.xr.setAnimationLoop(state.gl.xr.isPresenting ? handleXRFrame : null);
			if (!state.gl.xr.isPresenting) invalidate(state);
		};
		const xr = {
			connect() {
				const gl = store.getState().gl;
				gl.xr.addEventListener("sessionstart", handleSessionChange);
				gl.xr.addEventListener("sessionend", handleSessionChange);
			},
			disconnect() {
				const gl = store.getState().gl;
				gl.xr.removeEventListener("sessionstart", handleSessionChange);
				gl.xr.removeEventListener("sessionend", handleSessionChange);
			}
		};
		if (typeof ((_gl$xr = gl.xr) == null ? void 0 : _gl$xr.addEventListener) === "function") xr.connect();
		state.set({ xr });
	}
	if (gl.shadowMap && changed("shadows")) {
		const oldEnabled = gl.shadowMap.enabled;
		const oldType = gl.shadowMap.type;
		gl.shadowMap.enabled = !!shadows;
		if (is.boo(shadows)) gl.shadowMap.type = 2;
		else if (is.str(shadows)) {
			var _types$shadows;
			const types = {
				basic: 0,
				percentage: 1,
				soft: 2,
				variance: 3
			};
			gl.shadowMap.type = (_types$shadows = types[shadows]) != null ? _types$shadows : 2;
		} else if (is.obj(shadows)) Object.assign(gl.shadowMap, shadows);
		if (oldEnabled !== gl.shadowMap.enabled || oldType !== gl.shadowMap.type) gl.shadowMap.needsUpdate = true;
	}
	const glProps = glConfig && !is.fun(glConfig) && !isRenderer(glConfig) ? glConfig : void 0;
	if (changed("legacy")) {
		ColorManagement.enabled = !legacy;
		state.set({ legacy });
	}
	if (changed("linear")) {
		if ((glProps == null ? void 0 : glProps.outputColorSpace) === void 0) gl.outputColorSpace = linear ? LinearSRGBColorSpace : SRGBColorSpace;
		state.set({ linear });
	}
	if (changed("flat")) {
		if ((glProps == null ? void 0 : glProps.toneMapping) === void 0) gl.toneMapping = flat ? 0 : 4;
		state.set({ flat });
	}
	if (glProps && changed("gl")) applyProps(gl, glProps);
	configuration.previous = next;
}
/**
* Moving to another display or zooming changes window.devicePixelRatio without resizing the canvas,
* so nothing configures the root again. Resolves the ratio the way configuration does, from the last
* applied dpr. Returns the function that stops following.
*/
function followDpr(root) {
	const xr = () => {
		var _root$store$getState$;
		return (_root$store$getState$ = root.store.getState().gl) == null ? void 0 : _root$store$getState$.xr;
	};
	const follow = () => {
		var _xr, _xr2, _xr3, _last$dpr;
		const state = root.store.getState();
		if ((_xr = xr()) != null && _xr.isPresenting || (_xr2 = xr()) != null && _xr2.getSession != null && _xr2.getSession()) {
			xr().addEventListener("sessionend", follow);
			return;
		}
		(_xr3 = xr()) == null || _xr3.removeEventListener == null || _xr3.removeEventListener("sessionend", follow);
		const last = root.configuration.previous;
		if (!last) return;
		const dpr = (_last$dpr = last.dpr) != null ? _last$dpr : [1, 2];
		if (state.viewport.dpr !== calculateDpr(dpr)) state.setDpr(dpr);
	};
	const unwatch = watchDpr(follow);
	return () => {
		var _xr4;
		unwatch();
		(_xr4 = xr()) == null || _xr4.removeEventListener == null || _xr4.removeEventListener("sessionend", follow);
	};
}
var packageData = {
	name: "@react-three/fiber",
	version: "9.8.2",
	description: "A React renderer for Threejs",
	keywords: [
		"react",
		"renderer",
		"fiber",
		"three",
		"threejs"
	],
	author: "Paul Henschel (https://github.com/drcmda)",
	license: "MIT",
	maintainers: [
		"Josh Ellis (https://github.com/joshuaellis)",
		"Cody Bennett (https://github.com/codyjasonbennett)",
		"Kris Baumgarter (https://github.com/krispya)"
	],
	bugs: { url: "https://github.com/pmndrs/react-three-fiber/issues" },
	homepage: "https://github.com/pmndrs/react-three-fiber#readme",
	repository: {
		type: "git",
		url: "git+https://github.com/pmndrs/react-three-fiber.git"
	},
	collective: {
		type: "opencollective",
		url: "https://opencollective.com/react-three-fiber"
	},
	main: "dist/react-three-fiber.cjs.js",
	module: "dist/react-three-fiber.esm.js",
	types: "dist/react-three-fiber.cjs.d.ts",
	"react-native": "native/dist/react-three-fiber-native.cjs.js",
	files: [
		"dist",
		"native",
		"react-reconciler",
		"CHANGELOG.md"
	],
	sideEffects: false,
	preconstruct: { entrypoints: ["index.tsx", "native.tsx"] },
	scripts: { prebuild: "cp ../../readme.md readme.md" },
	devDependencies: {
		"@types/react-reconciler": "^0.33.0",
		"react-reconciler": "^0.34.0"
	},
	dependencies: {
		"@babel/runtime": "^7.17.8",
		"@types/webxr": "*",
		"base64-js": "^1.5.1",
		buffer: "^6.0.3",
		"its-fine": "^2.1.1",
		"react-use-measure": "^2.1.7",
		scheduler: "^0.28.0",
		"suspend-react": "^0.1.3",
		"use-sync-external-store": "^1.4.0",
		zustand: "^5.0.3"
	},
	peerDependencies: {
		expo: ">=43.0",
		"expo-asset": ">=8.4",
		"expo-file-system": ">=11.0",
		"expo-gl": ">=11.0",
		react: ">=19 <19.4",
		"react-dom": ">=19 <19.4",
		"react-native": ">=0.78",
		three: ">=0.156"
	},
	peerDependenciesMeta: {
		"react-dom": { optional: true },
		"react-native": { optional: true },
		expo: { optional: true },
		"expo-asset": { optional: true },
		"expo-file-system": { optional: true },
		"expo-gl": { optional: true }
	}
};
function $1(Ut) {
	return Ut && Ut.__esModule && Object.prototype.hasOwnProperty.call(Ut, "default") ? Ut.default : Ut;
}
var S0 = { exports: {} };
/**
* @license React
* react-reconciler.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
({ exports: {} }).exports;
var Bb = { exports: {} };
/**
* @license React
* react-reconciler.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
Bb.exports;
var x1;
function q1() {
	return x1 || (x1 = 1, function(Ut) {
		Ut.exports = function(m) {
			function et(e, n) {
				for (e = e.memoizedState; e !== null && 0 < n;) e = e.next, n--;
				return e;
			}
			function zf(e, n, o, i) {
				if (o >= n.length) return i;
				var s = n[o], u = Gn(e) ? e.slice() : Un({}, e);
				return u[s] = zf(e[s], n, o + 1, i), u;
			}
			function F(e, n, o) {
				if (n.length !== o.length) console.warn("copyWithRename() expects paths of the same length");
				else {
					for (var i = 0; i < o.length - 1; i++) if (n[i] !== o[i]) {
						console.warn("copyWithRename() expects paths to be the same except for the deepest key");
						return;
					}
					return Ef(e, n, o, 0);
				}
			}
			function Ef(e, n, o, i) {
				var s = n[i], u = Gn(e) ? e.slice() : Un({}, e);
				return i + 1 === n.length ? (u[o[i]] = u[s], Gn(u) ? u.splice(s, 1) : delete u[s]) : u[s] = Ef(e[s], n, o, i + 1), u;
			}
			function pc(e, n, o) {
				var i = n[o], s = Gn(e) ? e.slice() : Un({}, e);
				return o + 1 === n.length ? (Gn(s) ? s.splice(i, 1) : delete s[i], s) : (s[i] = pc(e[i], n, o + 1), s);
			}
			function hc() {
				return !1;
			}
			function mc() {
				return null;
			}
			function ht(e, n, o, i) {
				return new R0(e, n, o, i);
			}
			function Ss(e, n) {
				e.context === c && (Rd(n, e, null, null), Cd());
			}
			function gc(e, n) {
				if (Zi !== null) {
					var o = n.staleFamilies;
					n = n.updatedFamilies, Ol(), gg(e.current, n, o), Cd();
				}
			}
			function oo(e) {
				Zi = e;
			}
			function W() {
				console.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://react.dev/link/rules-of-hooks");
			}
			function Te() {
				console.error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
			}
			function k0() {}
			function ma() {}
			function ao(e) {
				var n = [];
				return e.forEach(function(o) {
					n.push(o);
				}), n.sort().join(", ");
			}
			function Yi(e) {
				for (var n = e, o = n; o && !o.alternate;) n = o, n.flags & 4098 && (e = n.return), o = n.return;
				for (; n.return;) n = n.return;
				return n.tag === 3 ? e : null;
			}
			function _f(e) {
				if (Yi(e) !== e) throw Error("Unable to find node on an unmounted component.");
			}
			function am(e) {
				var n = e.alternate;
				if (!n) {
					if (n = Yi(e), n === null) throw Error("Unable to find node on an unmounted component.");
					return n !== e ? null : e;
				}
				for (var o = e, i = n;;) {
					var s = o.return;
					if (s === null) break;
					var u = s.alternate;
					if (u === null) {
						if (i = s.return, i !== null) {
							o = i;
							continue;
						}
						break;
					}
					if (s.child === u.child) {
						for (u = s.child; u;) {
							if (u === o) return _f(s), e;
							if (u === i) return _f(s), n;
							u = u.sibling;
						}
						throw Error("Unable to find node on an unmounted component.");
					}
					if (o.return !== i.return) o = s, i = u;
					else {
						for (var f = !1, p = s.child; p;) {
							if (p === o) {
								f = !0, o = s, i = u;
								break;
							}
							if (p === i) {
								f = !0, i = s, o = u;
								break;
							}
							p = p.sibling;
						}
						if (!f) {
							for (p = u.child; p;) {
								if (p === o) {
									f = !0, o = u, i = s;
									break;
								}
								if (p === i) {
									f = !0, i = u, o = s;
									break;
								}
								p = p.sibling;
							}
							if (!f) throw Error("Child was not found in either parent set. This indicates a bug in React related to the return pointer. Please file an issue.");
						}
					}
					if (o.alternate !== i) throw Error("Return fibers should always be each others' alternates. This error is likely caused by a bug in React. Please file an issue.");
				}
				if (o.tag !== 3) throw Error("Unable to find node on an unmounted component.");
				return o.stateNode.current === o ? e : n;
			}
			function Nf(e) {
				return e = am(e), e !== null ? bc(e) : null;
			}
			function bc(e) {
				var n = e.tag;
				if (n === 5 || n === 26 || n === 27 || n === 6) return e;
				for (e = e.child; e !== null;) {
					if (n = bc(e), n !== null) return n;
					e = e.sibling;
				}
				return null;
			}
			function Ki(e) {
				var n = e.tag;
				if (n === 5 || n === 26 || n === 27 || n === 6) return e;
				for (e = e.child; e !== null;) {
					if (e.tag !== 4 && (n = Ki(e), n !== null)) return n;
					e = e.sibling;
				}
				return null;
			}
			function ti(e) {
				return e === null || typeof e != "object" ? null : (e = ch && e[ch] || e["@@iterator"], typeof e == "function" ? e : null);
			}
			function en(e) {
				if (e == null) return null;
				if (typeof e == "function") return e.$$typeof === dh ? null : e.displayName || e.name || null;
				if (typeof e == "string") return e;
				switch (e) {
					case Qr: return "Fragment";
					case Wa: return "Profiler";
					case Ml: return "StrictMode";
					case lh: return "Suspense";
					case Vl: return "SuspenseList";
					case $l: return "Activity";
					case uh: return "ViewTransition";
				}
				if (typeof e == "object") switch (typeof e.tag == "number" && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), e.$$typeof) {
					case Ua: return "Portal";
					case sn: return e.displayName || "Context";
					case Aa: return (e._context.displayName || "Context") + ".Consumer";
					case Fd:
						var n = e.render;
						return e = e.displayName, e || (e = n.displayName || n.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
					case Ei: return n = e.displayName || null, n !== null ? n : en(e.type) || "Memo";
					case qn:
						n = e._payload, e = e._init;
						try {
							return en(e(n));
						} catch {}
				}
				return null;
			}
			function G(e) {
				var n = e.type;
				switch (e.tag) {
					case 31: return "Activity";
					case 24: return "Cache";
					case 9: return (n._context.displayName || "Context") + ".Consumer";
					case 10: return n.displayName || "Context";
					case 18: return "DehydratedFragment";
					case 11: return e = n.render, e = e.displayName || e.name || "", n.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
					case 7: return "Fragment";
					case 26:
					case 27:
					case 5: return n;
					case 4: return "Portal";
					case 3: return "Root";
					case 6: return "Text";
					case 16: return en(n);
					case 8: return n === Ml ? "StrictMode" : "Mode";
					case 22:
						if (e.return !== null) return G(e.return);
						break;
					case 12: return "Profiler";
					case 21: return "Scope";
					case 13: return "Suspense";
					case 19: return "SuspenseList";
					case 25: return "TracingMarker";
					case 30: return "ViewTransition";
					case 1:
					case 0:
					case 14:
					case 15:
						if (typeof n == "function") return n.displayName || n.name || null;
						if (typeof n == "string") return n;
						break;
					case 29:
						if (n = e._debugInfo, n != null) {
							for (var o = n.length - 1; 0 <= o; o--) if (typeof n[o].name == "string") return n[o].name;
						}
						if (e.return !== null) return G(e.return);
				}
				return null;
			}
			function Wt(e) {
				return { current: e };
			}
			function mn(e, n) {
				0 > l ? console.error("Unexpected pop.") : (n !== a[l] && console.error("Unexpected Fiber popped."), e.current = r[l], r[l] = null, a[l] = null, l--);
			}
			function ze(e, n, o) {
				l++, r[l] = e.current, a[l] = o, e.current = n;
			}
			function ga(e) {
				return e >>>= 0, e === 0 ? 32 : 31 - (h(e) / y | 0) | 0;
			}
			function mt(e) {
				var n = e & 42;
				if (n !== 0) return n;
				switch (e & -e) {
					case 1: return 1;
					case 2: return 2;
					case 4: return 4;
					case 8: return 8;
					case 16: return 16;
					case 32: return 32;
					case 64: return 64;
					case 128: return 128;
					case 256:
					case 512:
					case 1024:
					case 2048:
					case 4096:
					case 8192:
					case 16384:
					case 32768:
					case 65536:
					case 131072: return e & -e;
					case 262144:
					case 524288:
					case 1048576:
					case 2097152: return e & 3932160;
					case 4194304:
					case 8388608:
					case 16777216:
					case 33554432: return e & 62914560;
					case 67108864: return 67108864;
					case 134217728: return 134217728;
					case 268435456: return 268435456;
					case 536870912: return 536870912;
					case 1073741824: return 0;
					default: return console.error("Should have found matching lanes. This is a bug in React."), e;
				}
			}
			function ks(e, n, o) {
				var i = e.pendingLanes;
				if (i === 0) return 0;
				var s = 0, u = e.suspendedLanes, f = e.pingedLanes;
				e = e.warmLanes;
				var p = i & 134217727;
				return p !== 0 ? (i = p & ~u, i !== 0 ? s = mt(i) : (f &= p, f !== 0 ? s = mt(f) : o || (o = p & ~e, o !== 0 && (s = mt(o))))) : (p = i & ~u, p !== 0 ? s = mt(p) : f !== 0 ? s = mt(f) : o || (o = i & ~e, o !== 0 && (s = mt(o)))), s === 0 ? 0 : n !== 0 && n !== s && (n & u) === 0 && (u = s & -s, o = n & -n, u >= o || u === 32 && (o & 4194048) !== 0) ? n : s;
			}
			function At(e, n) {
				return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & n) === 0;
			}
			function im(e, n) {
				n & 8 && (n |= n & 32);
				var o = e.entangledLanes;
				if (o !== 0) for (e = e.entanglements, o &= n; 0 < o;) {
					var i = 31 - d(o), s = 1 << i;
					n |= e[i], o &= ~s;
				}
				return n;
			}
			function ba(e, n) {
				switch (e) {
					case 1:
					case 2:
					case 4:
					case 8:
					case 64: return n + 250;
					case 16:
					case 32:
					case 128:
					case 256:
					case 512:
					case 1024:
					case 2048:
					case 4096:
					case 8192:
					case 16384:
					case 32768:
					case 65536:
					case 131072:
					case 262144:
					case 524288:
					case 1048576:
					case 2097152: return n + 5e3;
					case 4194304:
					case 8388608:
					case 16777216:
					case 33554432: return -1;
					case 67108864:
					case 134217728:
					case 268435456:
					case 536870912:
					case 1073741824: return -1;
					default: return console.error("Should have found matching lanes. This is a bug in React."), -1;
				}
			}
			function ws() {
				var e = D;
				return D <<= 1, !(D & 62914560) && (D = 4194304), e;
			}
			function Tf(e) {
				for (var n = [], o = 0; 31 > o; o++) n.push(e);
				return n;
			}
			function el(e, n) {
				e.pendingLanes |= n, n !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0);
			}
			function Kt(e, n, o, i, s, u) {
				var f = e.pendingLanes;
				e.pendingLanes = o, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= o, e.entangledLanes &= o, e.errorRecoveryDisabledLanes &= o, e.shellSuspendCounter = 0;
				var p = e.entanglements, g = e.expirationTimes, b = e.hiddenUpdates;
				for (o = f & ~o; 0 < o;) {
					var k = 31 - d(o), z = 1 << k;
					p[k] = 0, g[k] = -1;
					var T = b[k];
					if (T !== null) for (b[k] = null, k = 0; k < T.length; k++) {
						var H = T[k];
						H !== null && (H.lane &= -536870913);
					}
					o &= ~z;
				}
				i !== 0 && io(e, i, 0), u !== 0 && s === 0 && e.tag !== 0 && (e.suspendedLanes |= u & ~(f & ~n));
			}
			function io(e, n, o) {
				e.pendingLanes |= n, e.suspendedLanes &= ~n;
				var i = 31 - d(n);
				e.entangledLanes |= n, e.entanglements[i] = e.entanglements[i] | 1073741824 | o & 261930;
			}
			function If(e, n) {
				var o = e.entangledLanes |= n;
				for (e = e.entanglements; o;) {
					var i = 31 - d(o), s = 1 << i;
					s & n | e[i] & n && (e[i] |= n), o &= ~s;
				}
			}
			function Ps(e, n) {
				var o = n & -n;
				return o = (o & 42) !== 0 ? 1 : xs(o), (o & (e.suspendedLanes | n)) !== 0 ? 0 : o;
			}
			function xs(e) {
				switch (e) {
					case 2:
						e = 1;
						break;
					case 8:
						e = 4;
						break;
					case 32:
						e = 16;
						break;
					case 256:
					case 512:
					case 1024:
					case 2048:
					case 4096:
					case 8192:
					case 16384:
					case 32768:
					case 65536:
					case 131072:
					case 262144:
					case 524288:
					case 1048576:
					case 2097152:
					case 4194304:
					case 8388608:
					case 16777216:
					case 33554432:
						e = 128;
						break;
					case 268435456:
						e = 134217728;
						break;
					default: e = 0;
				}
				return e;
			}
			function Rf(e, n, o) {
				if (Le) for (e = e.pendingUpdatersLaneMap; 0 < o;) {
					var i = 31 - d(o), s = 1 << i;
					e[i].add(n), o &= ~s;
				}
			}
			function Cs(e, n) {
				if (Le) for (var o = e.pendingUpdatersLaneMap, i = e.memoizedUpdaters; 0 < n;) {
					var s = 31 - d(n);
					e = 1 << s, s = o[s], 0 < s.size && (s.forEach(function(u) {
						var f = u.alternate;
						f !== null && i.has(f) || i.add(u);
					}), s.clear()), n &= ~e;
				}
			}
			function ya(e) {
				return e &= -e, 2 < e ? 8 < e ? (e & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
			}
			function Lf(e) {
				if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u") return !1;
				var n = __REACT_DEVTOOLS_GLOBAL_HOOK__;
				if (n.isDisabled) return !0;
				if (!n.supportsFiber) return console.error("The installed version of React DevTools is too old and will not work with the current version of React. Please update React DevTools. https://react.dev/link/react-devtools"), !0;
				try {
					Ue = n.inject(e), M = n;
				} catch (o) {
					console.error("React instrumentation encountered an error: %o.", o);
				}
				return !!n.checkDCE;
			}
			function Oe(e) {
				if (typeof j == "function" && q(e), M && typeof M.setStrictMode == "function") try {
					M.setStrictMode(Ue, e);
				} catch (n) {
					ie || (ie = !0, console.error("React instrumentation encountered an error: %o", n));
				}
			}
			function Mn(e, n) {
				if (e.name != null && e.name !== "auto") return e.name;
				if (n.autoName !== null) return n.autoName;
				e = pa.identifierPrefix;
				var o = Se++;
				return e = "_" + e + "t_" + o.toString(32) + "_", n.autoName = e;
			}
			function Ff(e) {
				var _n2;
				if (e == null || typeof e == "string") return e;
				var n = null, o = Pf;
				if (o !== null) for (var i = 0; i < o.length; i++) {
					var s = e[o[i]];
					if (s != null) {
						if (s === "none") return "none";
						n = n == null ? s : n + (" " + s);
					}
				}
				return (_n2 = n) != null ? _n2 : e.default;
			}
			function er(e, n) {
				return e = Ff(e), n = Ff(n), n == null ? e === "auto" ? null : e : n === "auto" ? null : n;
			}
			function nl(e, n) {
				return e === n && (e !== 0 || 1 / e === 1 / n) || e !== e && n !== n;
			}
			function ri(e) {
				for (var n = 0, o = 0; o < e.length && 100 > o; o++) {
					var i = e[o];
					if (typeof i == "object" && i !== null) {
						if (Gn(i) && i.length === 2 && typeof i[0] == "string") {
							if (n !== 0 && n !== 3) return 1;
							n = 3;
						} else return 1;
					} else {
						if (typeof i == "function" || typeof i == "string" && 50 < i.length || n !== 0 && n !== 2 || typeof i == "bigint") return 1;
						n = 2;
					}
				}
				return n;
			}
			function zs(e, n, o, i) {
				if (!ArrayBuffer.isView(e)) {
					var s = 0, u;
					for (u in e) if (Ig.call(e, u) && u[0] !== "_" && (s++, Rn(u, e[u], n, o, i), 100 <= s)) {
						n.push([i + "\xA0\xA0".repeat(o) + "Only 100 properties are shown. React will not log more properties of this object.", ""]);
						break;
					}
				}
			}
			function va(e) {
				return "$$typeof" in e && Ig.call(e, "$$typeof") ? e.$$typeof : void 0;
			}
			function Rn(e, n, o, i, s) {
				switch (typeof n) {
					case "object": if (n === null) {
						n = "null";
						break;
					} else {
						if (va(n) === xo) {
							var u = en(n.type) || "…", f = n.key;
							n = n.props;
							var p = Object.keys(n), g = p.length;
							if (f == null && g === 0) {
								n = "<" + u + " />";
								break;
							}
							if (3 > i || g === 1 && p[0] === "children" && f == null) {
								n = "<" + u + " … />";
								break;
							}
							o.push([s + "\xA0\xA0".repeat(i) + e, "<" + u]), f !== null && Rn("key", f, o, i + 1, s), e = !1, f = 0;
							for (var b in n) if (f++, b === "children" ? n.children != null && (!Gn(n.children) || 0 < n.children.length) && (e = !0) : Ig.call(n, b) && b[0] !== "_" && Rn(b, n[b], o, i + 1, s), 100 <= f) break;
							o.push(["", e ? ">…</" + u + ">" : "/>"]);
							return;
						}
						if (u = Object.prototype.toString.call(n), u = u.slice(8, u.length - 1), ArrayBuffer.isView(n)) {
							n = n.length, n = typeof n == "number" ? u + "(" + n + ")" : u;
							break;
						}
						if (u === "Array") {
							if (b = 100 < n.length, f = ri(n), f === 2 || f === 0) {
								n = JSON.stringify(b ? n.slice(0, 100).concat("…") : n);
								break;
							} else if (f === 3) {
								for (o.push([s + "\xA0\xA0".repeat(i) + e, ""]), e = 0; e < n.length && 100 > e; e++) u = n[e], Rn(u[0], u[1], o, i + 1, s);
								b && Rn("100", "…", o, i + 1, s);
								return;
							}
						}
						if (u === "Promise") {
							if (n.status === "fulfilled") {
								if (u = o.length, Rn(e, n.value, o, i, s), o.length > u) {
									o = o[u], o[1] = "Promise<" + (o[1] || "Object") + ">";
									return;
								}
							} else if (n.status === "rejected" && (u = o.length, Rn(e, n.reason, o, i, s), o.length > u)) {
								o = o[u], o[1] = "Rejected Promise<" + o[1] + ">";
								return;
							}
							o.push(["\xA0\xA0".repeat(i) + e, "Promise"]);
							return;
						}
						u === "Object" && (b = Object.getPrototypeOf(n)) && typeof b.constructor == "function" && (u = b.constructor.name), o.push([s + "\xA0\xA0".repeat(i) + e, u === "Object" ? 3 > i ? "" : "…" : u]), 3 > i && zs(n, o, i + 1, s);
						return;
					}
					case "function":
						n = n.name, n = n === "" || typeof n != "string" ? "() => {}" : n + "() {}";
						break;
					case "string":
						n = n === "This object has been omitted by React in the console log to avoid sending too much data from the server. Try logging smaller or more specific objects." ? "…" : JSON.stringify(1024 <= n.length ? n.slice(0, 1023) + "…" : n);
						break;
					case "undefined":
						n = "undefined";
						break;
					case "boolean":
						n = n ? "true" : "false";
						break;
					default: n = String(n);
				}
				o.push([s + "\xA0\xA0".repeat(i) + e, n]);
			}
			function lo(e, n, o, i) {
				var s = !0, u = 0;
				for (p in e) {
					if (100 < u) {
						o.push(["Previous object has more than 100 properties. React will not attempt to diff objects with too many properties.", ""]), s = !1;
						break;
					}
					p in n || (o.push(["-\xA0" + "\xA0\xA0".repeat(i) + p, "…"]), s = !1), u++;
				}
				u = 0;
				for (var f in n) {
					if (100 < u) {
						o.push(["Next object has more than 100 properties. React will not attempt to diff objects with too many properties.", ""]), s = !1;
						break;
					}
					if (f in e) {
						var p = e[f], g = n[f];
						if (p !== g) {
							if (i === 0 && f === "children") {
								s = "\xA0\xA0".repeat(i) + f, o.push(["-\xA0" + s, "…"], ["+\xA0" + s, "…"]), s = !1;
								continue;
							}
							if (!(3 <= i)) {
								if (typeof p == "object" && typeof g == "object" && p !== null && g !== null && va(p) === va(g)) {
									if (va(g) === xo) {
										if (p.type === g.type && p.key === g.key) {
											p = en(g.type) || "…", s = "\xA0\xA0".repeat(i) + f, p = "<" + p + " … />", o.push(["-\xA0" + s, p], ["+\xA0" + s, p]), s = !1;
											continue;
										}
									} else {
										var b = Object.prototype.toString.call(p), k = Object.prototype.toString.call(g);
										if (b === k && (k === "[object Object]" || k === "[object Array]")) {
											b = [" \xA0" + "\xA0\xA0".repeat(i) + f, k === "[object Array]" ? "Array" : ""], o.push(b), k = o.length, lo(p, g, o, i + 1) ? k === o.length && (b[1] = "Referentially unequal but deeply equal objects. Consider memoization.") : s = !1;
											continue;
										}
									}
								} else if (typeof p == "function" && typeof g == "function" && p.name === g.name && p.length === g.length && (b = Function.prototype.toString.call(p), k = Function.prototype.toString.call(g), b === k)) {
									p = g.name === "" ? "() => {}" : g.name + "() {}", o.push([" \xA0" + "\xA0\xA0".repeat(i) + f, p + " Referentially unequal function closure. Consider memoization."]);
									continue;
								}
							}
							Rn(f, p, o, i, "-\xA0"), Rn(f, g, o, i, "+\xA0"), s = !1;
						}
					} else o.push(["+\xA0" + "\xA0\xA0".repeat(i) + f, "…"]), s = !1;
					u++;
				}
				return s;
			}
			function zn(e) {
				me = e & 63 ? "Blocking" : e & 64 ? "Gesture" : e & 4194176 ? "Transition" : e & 62914560 ? "Suspense" : e & 2080374784 ? "Idle" : "Other";
			}
			function nr(e, n, o, i) {
				Ke && (as.start = n, as.end = o, Wi.color = "warning", Wi.tooltipText = i, Wi.properties = null, (e = e._debugTask) ? e.run(performance.measure.bind(performance, i, as)) : performance.measure(i, as), performance.clearMeasures(i));
			}
			function so(e, n, o) {
				nr(e, n, o, "Reconnect");
			}
			function oi(e, n, o, i, s) {
				var u = G(e);
				if (u !== null && Ke) {
					var f = e.alternate, p = e.actualDuration;
					if (f === null || f.child !== e.child) for (var g = e.child; g !== null; g = g.sibling) p -= g.actualDuration;
					p = .5 > p ? i ? "tertiary-light" : "primary-light" : 10 > p ? i ? "tertiary" : "primary" : 100 > p ? i ? "tertiary-dark" : "primary-dark" : "error";
					var b = e.memoizedProps;
					i = e._debugTask, b !== null && f !== null && f.memoizedProps !== b ? (g = [E1], b = lo(f.memoizedProps, b, g, 0), 1 < g.length ? (b && !os && (f.lanes & s) === 0 && 100 < e.actualDuration ? (os = !0, g[0] = _1, Wi.color = "warning", Wi.tooltipText = "This component received deeply equal props. It might benefit from useMemo or the React Compiler in its owner.") : (Wi.color = p, Wi.tooltipText = u), Wi.properties = g, as.start = n, as.end = o, e = "​" + u, i != null ? i.run(performance.measure.bind(performance, e, as)) : performance.measure(e, as), performance.clearMeasures(e)) : i != null ? i.run(console.timeStamp.bind(console, u, n, o, "Components ⚛", void 0, p)) : console.timeStamp(u, n, o, "Components ⚛", void 0, p)) : i != null ? i.run(console.timeStamp.bind(console, u, n, o, "Components ⚛", void 0, p)) : console.timeStamp(u, n, o, "Components ⚛", void 0, p);
				}
			}
			function Do(e, n, o, i) {
				if (Ke) {
					var s = G(e);
					if (s !== null) {
						for (var u = null, f = [], p = 0; p < i.length; p++) {
							var g = i[p];
							u == null && g.source !== null && (u = g.source._debugTask), g = g.value, f.push(["Error", typeof g == "object" && g !== null && typeof g.message == "string" ? String(g.message) : String(g)]);
						}
						e.key !== null && Rn("key", e.key, f, 0, ""), e.memoizedProps !== null && zs(e.memoizedProps, f, 0, ""), u ??= e._debugTask, e = {
							start: n,
							end: o,
							detail: { devtools: {
								color: "error",
								track: "Components ⚛",
								tooltipText: e.tag === 13 ? "Hydration failed" : "Error boundary caught an error",
								properties: f
							} }
						}, s = "​" + s, u ? u.run(performance.measure.bind(performance, s, e)) : performance.measure(s, e), performance.clearMeasures(s);
					}
				}
			}
			function Me(e, n, o, i, s) {
				if (s !== null) {
					if (Ke) {
						var u = G(e);
						if (u !== null) {
							i = [];
							for (var f = 0; f < s.length; f++) {
								var p = s[f].value;
								i.push(["Error", typeof p == "object" && p !== null && typeof p.message == "string" ? String(p.message) : String(p)]);
							}
							e.key !== null && Rn("key", e.key, i, 0, ""), e.memoizedProps !== null && zs(e.memoizedProps, i, 0, ""), n = {
								start: n,
								end: o,
								detail: { devtools: {
									color: "error",
									track: "Components ⚛",
									tooltipText: "A lifecycle or effect errored",
									properties: i
								} }
							}, e = e._debugTask, o = "​" + u, e ? e.run(performance.measure.bind(performance, o, n)) : performance.measure(o, n), performance.clearMeasures(o);
						}
					}
				} else u = G(e), u !== null && Ke && (s = 1 > i ? "secondary-light" : 100 > i ? "secondary" : 500 > i ? "secondary-dark" : "error", (e = e._debugTask) ? e.run(console.timeStamp.bind(console, u, n, o, "Components ⚛", void 0, s)) : console.timeStamp(u, n, o, "Components ⚛", void 0, s));
			}
			function Es(e, n, o, i) {
				!Ke || n <= e || (o = (o & 738197653) === o ? "tertiary-dark" : "primary-dark", i ? i.run(console.timeStamp.bind(console, "Prewarm", e, n, me, "Scheduler ⚛", o)) : console.timeStamp("Prewarm", e, n, me, "Scheduler ⚛", o));
			}
			function Df(e, n, o, i) {
				!Ke || n <= e || (o = (o & 738197653) === o ? "tertiary-dark" : "primary-dark", i ? i.run(console.timeStamp.bind(console, "Suspended", e, n, me, "Scheduler ⚛", o)) : console.timeStamp("Suspended", e, n, me, "Scheduler ⚛", o));
			}
			function _s(e, n, o, i) {
				!Ke || n <= e || (i ? i.run(console.timeStamp.bind(console, "Errored", e, n, me, "Scheduler ⚛", "error")) : console.timeStamp("Errored", e, n, me, "Scheduler ⚛", "error"));
			}
			function Ns(e, n, o, i) {
				!Ke || n <= e || (i ? i.run(console.timeStamp.bind(console, o, e, n, me, "Scheduler ⚛", "secondary-light")) : console.timeStamp(o, e, n, me, "Scheduler ⚛", "secondary-light"));
			}
			function jf(e, n, o, i, s) {
				if (Ke && !(n <= e)) {
					for (var u = [], f = 0; f < o.length; f++) {
						var p = o[f].value;
						u.push(["Error", typeof p == "object" && p !== null && typeof p.message == "string" ? String(p.message) : String(p)]);
					}
					e = {
						start: e,
						end: n,
						detail: { devtools: {
							color: "error",
							track: me,
							trackGroup: "Scheduler ⚛",
							tooltipText: i ? "Remaining Effects Errored" : "Commit Errored",
							properties: u
						} }
					}, s ? s.run(performance.measure.bind(performance, "Errored", e)) : performance.measure("Errored", e), performance.clearMeasures("Errored");
				}
			}
			function lm(e, n, o, i, s) {
				o !== null ? jf(e, n, o, !1, s) : !Ke || n <= e || (s ? s.run(console.timeStamp.bind(console, i ? "Commit Interrupted View Transition" : "Commit", e, n, me, "Scheduler ⚛", i ? "error" : "secondary-dark")) : console.timeStamp(i ? "Commit Interrupted View Transition" : "Commit", e, n, me, "Scheduler ⚛", i ? "error" : "secondary-dark"));
			}
			function Pr(e, n, o) {
				!Ke || n <= e || (o ? o.run(console.timeStamp.bind(console, "Animating", e, n, me, "Scheduler ⚛", "secondary-dark")) : console.timeStamp("Animating", e, n, me, "Scheduler ⚛", "secondary-dark"));
			}
			function xr() {}
			function tl() {
				if (Ch === 0) {
					Vb = console.log, $b = console.info, Qb = console.warn, qb = console.error, Gb = console.group, Jb = console.groupCollapsed, Zb = console.groupEnd;
					var e = {
						configurable: !0,
						enumerable: !0,
						value: xr,
						writable: !0
					};
					Object.defineProperties(console, {
						info: e,
						log: e,
						warn: e,
						error: e,
						group: e,
						groupCollapsed: e,
						groupEnd: e
					});
				}
				Ch++;
			}
			function sm() {
				if (Ch--, Ch === 0) {
					var e = {
						configurable: !0,
						enumerable: !0,
						writable: !0
					};
					Object.defineProperties(console, {
						log: Un({}, e, { value: Vb }),
						info: Un({}, e, { value: $b }),
						warn: Un({}, e, { value: Qb }),
						error: Un({}, e, { value: qb }),
						group: Un({}, e, { value: Gb }),
						groupCollapsed: Un({}, e, { value: Jb }),
						groupEnd: Un({}, e, { value: Zb })
					});
				}
				0 > Ch && console.error("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
			}
			function yc(e) {
				var n = Error.prepareStackTrace;
				if (Error.prepareStackTrace = void 0, e = e.stack, Error.prepareStackTrace = n, e.startsWith(`Error: react-stack-top-frame
`) && (e = e.slice(29)), n = e.indexOf(`
`), n !== -1 && (e = e.slice(n + 1)), n = e.indexOf("react_stack_bottom_frame"), n !== -1 && (n = e.lastIndexOf(`
`, n)), n !== -1) e = e.slice(0, n);
				else return "";
				return e;
			}
			function nt(e) {
				if ($0 === void 0) try {
					throw Error();
				} catch (o) {
					var n = o.stack.trim().match(/\n( *(at )?)/);
					$0 = n && n[1] || "", Xb = -1 < o.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < o.stack.indexOf("@") ? "@unknown:0:0" : "";
				}
				return `
` + $0 + e + Xb;
			}
			function vc(e, n) {
				if (!e || Q0) return "";
				var o = q0.get(e);
				if (o !== void 0) return o;
				Q0 = !0, o = Error.prepareStackTrace, Error.prepareStackTrace = void 0;
				var i = null;
				i = N.H, N.H = null, tl();
				try {
					var s = { DetermineComponentFrameRoot: function() {
						try {
							if (n) {
								var T = function() {
									throw Error();
								};
								if (Object.defineProperty(T.prototype, "props", { set: function() {
									throw Error();
								} }), typeof Reflect == "object" && Reflect.construct) {
									try {
										Reflect.construct(T, []);
									} catch (an) {
										var H = an;
									}
									Reflect.construct(e, [], T);
								} else {
									try {
										T.call();
									} catch (an) {
										H = an;
									}
									T = !1;
									try {
										var $ = Object.getOwnPropertyDescriptor(e.prototype, "props");
										Object.defineProperty(e.prototype, "props", {
											configurable: !0,
											set: function() {
												throw Error();
											}
										}), T = !0, new e();
									} finally {
										T && ($ !== void 0 ? Object.defineProperty(e.prototype, "props", $) : delete e.prototype.props);
									}
								}
							} else {
								try {
									throw Error();
								} catch (an) {
									H = an;
								}
								(T = e()) && typeof T.catch == "function" && T.catch(function() {});
							}
						} catch (an) {
							if (an && H && typeof an.stack == "string") return [an.stack, H.stack];
						}
						return [null, null];
					} };
					s.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
					var u = Object.getOwnPropertyDescriptor(s.DetermineComponentFrameRoot, "name");
					u && u.configurable && Object.defineProperty(s.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
					var f = s.DetermineComponentFrameRoot(), p = f[0], g = f[1];
					if (p && g) {
						var b = p.split(`
`), k = g.split(`
`);
						for (f = u = 0; u < b.length && !b[u].includes("DetermineComponentFrameRoot");) u++;
						for (; f < k.length && !k[f].includes("DetermineComponentFrameRoot");) f++;
						if (u === b.length || f === k.length) for (u = b.length - 1, f = k.length - 1; 1 <= u && 0 <= f && b[u] !== k[f];) f--;
						for (; 1 <= u && 0 <= f; u--, f--) if (b[u] !== k[f]) {
							if (u !== 1 || f !== 1) do
								if (u--, f--, 0 > f || b[u] !== k[f]) {
									var z = `
` + b[u].replace(" at new ", " at ");
									return e.displayName && z.includes("<anonymous>") && (z = z.replace("<anonymous>", e.displayName)), typeof e == "function" && q0.set(e, z), z;
								}
							while (1 <= u && 0 <= f);
							break;
						}
					}
				} finally {
					Q0 = !1, N.H = i, sm(), Error.prepareStackTrace = o;
				}
				return b = (b = e ? e.displayName || e.name : "") ? nt(b) : "", typeof e == "function" && q0.set(e, b), b;
			}
			function um(e, n) {
				switch (e.tag) {
					case 26:
					case 27:
					case 5: return nt(e.type);
					case 16: return nt("Lazy");
					case 13: return e.child !== n && n !== null ? nt("Suspense Fallback") : nt("Suspense");
					case 19: return nt("SuspenseList");
					case 0:
					case 15: return vc(e.type, !1);
					case 11: return vc(e.type.render, !1);
					case 1: return vc(e.type, !0);
					case 31: return nt("Activity");
					case 30: return nt("ViewTransition");
					default: return "";
				}
			}
			function cm(e) {
				try {
					var n = "", o = null;
					do {
						n += um(e, o);
						var i = e._debugInfo;
						if (i) for (var s = i.length - 1; 0 <= s; s--) {
							var u = i[s];
							if (typeof u.name == "string") {
								var f = n;
								e: {
									var p = u.name, g = u.env, b = u.debugLocation;
									if (b != null) {
										var k = yc(b), z = k.lastIndexOf(`
`), T = z === -1 ? k : k.slice(z + 1);
										if (T.indexOf(p) !== -1) {
											var H = `
` + T;
											break e;
										}
									}
									H = nt(p + (g ? " [" + g + "]" : ""));
								}
								n = f + H;
							}
						}
						o = e, e = e.return;
					} while (e);
					return n;
				} catch ($) {
					return `
Error generating stack: ` + $.message + `
` + $.stack;
				}
			}
			function Sc(e) {
				return (e = e ? e.displayName || e.name : "") ? nt(e) : "";
			}
			function Ot(e, n) {
				if (typeof e == "object" && e !== null) {
					var o = G0.get(e);
					return o !== void 0 ? o : (n = {
						value: e,
						source: n,
						stack: cm(n)
					}, G0.set(e, n), n);
				}
				return {
					value: e,
					source: n,
					stack: cm(n)
				};
			}
			function uo(e, n) {
				jo(), nf[tf++] = zh, nf[tf++] = Rg, Rg = e, zh = n;
			}
			function dm(e, n, o) {
				jo(), Eo[_o++] = Ai, Eo[_o++] = Oi, Eo[_o++] = qu, qu = e;
				var i = Ai;
				e = Oi;
				var s = 32 - d(i) - 1;
				i &= ~(1 << s), o += 1;
				var u = 32 - d(n) + s;
				if (30 < u) {
					var f = s - s % 5;
					u = (i & (1 << f) - 1).toString(32), i >>= f, s -= f, Ai = 1 << 32 - d(n) + s | o << s | i, Oi = u + e;
				} else Ai = 1 << u | o << s | i, Oi = e;
			}
			function rl(e) {
				jo(), e.return !== null && (uo(e, 1), dm(e, 1, 0));
			}
			function ol(e) {
				for (; e === Rg;) Rg = nf[--tf], nf[tf] = null, zh = nf[--tf], nf[tf] = null;
				for (; e === qu;) qu = Eo[--_o], Eo[_o] = null, Oi = Eo[--_o], Eo[_o] = null, Ai = Eo[--_o], Eo[_o] = null;
			}
			function Uf() {
				return jo(), qu !== null ? {
					id: Ai,
					overflow: Oi
				} : null;
			}
			function Ts(e, n) {
				jo(), Eo[_o++] = Ai, Eo[_o++] = Oi, Eo[_o++] = qu, Ai = n.id, Oi = n.overflow, qu = e;
			}
			function jo() {
				le || console.error("Expected to be hydrating. This is a bug in React. Please file an issue.");
			}
			function Uo(e) {
				return e === null && console.error("Expected host context to exist. This error is likely caused by a bug in React. Please file an issue."), e;
			}
			function co(e, n) {
				ze(ls, n, e), ze(Eh, e, e), ze(is, null, e), n = $t(n), mn(is, e), ze(is, n, e);
			}
			function ai(e) {
				mn(is, e), mn(Eh, e), mn(ls, e);
			}
			function Cr() {
				return Uo(is.current);
			}
			function al(e) {
				var n = e.memoizedState;
				n !== null && (n = n.memoizedState, yn ? Jr._currentValue = n : Jr._currentValue2 = n, ze(Lg, e, e)), n = Uo(is.current);
				var o = kg(n, e.type);
				n !== o && (ze(Eh, e, e), ze(is, o, e));
			}
			function zr(e) {
				Eh.current === e && (mn(is, e), mn(Eh, e)), Lg.current === e && (mn(Lg, e), yn ? Jr._currentValue = Gr : Jr._currentValue2 = Gr);
			}
			function Is(e, n) {
				return e.serverProps === void 0 && e.serverTail.length === 0 && e.children.length === 1 && 3 < e.distanceFromLeaf && e.distanceFromLeaf > 15 - n ? Is(e.children[0], n) : e;
			}
			function wt(e) {
				return "  " + "  ".repeat(e);
			}
			function Wo(e) {
				return "+ " + "  ".repeat(e);
			}
			function fo(e) {
				return "- " + "  ".repeat(e);
			}
			function kc(e) {
				switch (e.tag) {
					case 26:
					case 27:
					case 5: return e.type;
					case 16: return "Lazy";
					case 31: return "Activity";
					case 13: return "Suspense";
					case 19: return "SuspenseList";
					case 0:
					case 15: return e = e.type, e.displayName || e.name || null;
					case 11: return e = e.type.render, e.displayName || e.name || null;
					case 1: return e = e.type, e.displayName || e.name || null;
					default: return null;
				}
			}
			function Er(e, n) {
				return Yb.test(e) ? (e = JSON.stringify(e), e.length > n - 2 ? 8 > n ? "{\"...\"}" : "{" + e.slice(0, n - 7) + "...\"}" : "{" + e + "}") : e.length > n ? 5 > n ? "{\"...\"}" : e.slice(0, n - 3) + "..." : e;
			}
			function Rs(e, n, o) {
				var i = 120 - 2 * o;
				if (n === null) return Wo(o) + Er(e, i) + `
`;
				if (typeof n == "string") {
					for (var s = 0; s < n.length && s < e.length && n.charCodeAt(s) === e.charCodeAt(s); s++);
					return s > i - 8 && 10 < s && (e = "..." + e.slice(s - 8), n = "..." + n.slice(s - 8)), Wo(o) + Er(e, i) + `
` + fo(o) + Er(n, i) + `
`;
				}
				return wt(o) + Er(e, i) + `
`;
			}
			function il(e) {
				return Object.prototype.toString.call(e).replace(/^\[object (.*)\]$/, function(n, o) {
					return o;
				});
			}
			function ii(e, n) {
				switch (typeof e) {
					case "string": return e = JSON.stringify(e), e.length > n ? 5 > n ? "\"...\"" : e.slice(0, n - 4) + "...\"" : e;
					case "object":
						if (e === null) return "null";
						if (Gn(e)) return "[...]";
						if (e.$$typeof === xo) return (n = en(e.type)) ? "<" + n + ">" : "<...>";
						var o = il(e);
						if (o === "Object") {
							o = "", n -= 2;
							for (var i in e) if (e.hasOwnProperty(i)) {
								var s = JSON.stringify(i);
								if (s !== "\"" + i + "\"" && (i = s), n -= i.length - 2, s = ii(e[i], 15 > n ? n : 15), n -= s.length, 0 > n) {
									o += o === "" ? "..." : ", ...";
									break;
								}
								o += (o === "" ? "" : ",") + i + ":" + s;
							}
							return "{" + o + "}";
						}
						return o;
					case "function": return (n = e.displayName || e.name) ? "function " + n : "function";
					default: return String(e);
				}
			}
			function Sa(e, n) {
				return typeof e != "string" || Yb.test(e) ? "{" + ii(e, n - 2) + "}" : e.length > n - 2 ? 5 > n ? "\"...\"" : "\"" + e.slice(0, n - 5) + "...\"" : "\"" + e + "\"";
			}
			function po(e, n, o) {
				var i = 120 - o.length - e.length, s = [], u;
				for (u in n) if (n.hasOwnProperty(u) && u !== "children") {
					var f = Sa(n[u], 120 - o.length - u.length - 1);
					i -= u.length + f.length + 2, s.push(u + "=" + f);
				}
				return s.length === 0 ? o + "<" + e + `>
` : 0 < i ? o + "<" + e + " " + s.join(" ") + `>
` : o + "<" + e + `
` + o + "  " + s.join(`
` + o + "  ") + `
` + o + `>
`;
			}
			function ka(e, n, o) {
				var i = "", s = Un({}, n), u;
				for (u in e) if (e.hasOwnProperty(u)) {
					delete s[u];
					var f = 120 - 2 * o - u.length - 2, p = ii(e[u], f);
					n.hasOwnProperty(u) ? (f = ii(n[u], f), i += Wo(o) + u + ": " + p + `
`, i += fo(o) + u + ": " + f + `
`) : i += Wo(o) + u + ": " + p + `
`;
				}
				for (var g in s) s.hasOwnProperty(g) && (e = ii(s[g], 120 - 2 * o - g.length - 2), i += fo(o) + g + ": " + e + `
`);
				return i;
			}
			function Ls(e, n, o, i) {
				var s = "", u = /* @__PURE__ */ new Map();
				for (b in o) o.hasOwnProperty(b) && u.set(b.toLowerCase(), b);
				if (u.size === 1 && u.has("children")) s += po(e, n, wt(i));
				else {
					for (var f in n) if (n.hasOwnProperty(f) && f !== "children") {
						var p = 120 - 2 * (i + 1) - f.length - 1, g = u.get(f.toLowerCase());
						if (g !== void 0) {
							u.delete(f.toLowerCase());
							var b = n[f];
							g = o[g];
							var k = Sa(b, p);
							p = Sa(g, p), typeof b == "object" && b !== null && typeof g == "object" && g !== null && il(b) === "Object" && il(g) === "Object" && (2 < Object.keys(b).length || 2 < Object.keys(g).length || -1 < k.indexOf("...") || -1 < p.indexOf("...")) ? s += wt(i + 1) + f + `={{
` + ka(b, g, i + 2) + wt(i + 1) + `}}
` : (s += Wo(i + 1) + f + "=" + k + `
`, s += fo(i + 1) + f + "=" + p + `
`);
						} else s += wt(i + 1) + f + "=" + Sa(n[f], p) + `
`;
					}
					u.forEach(function(z) {
						if (z !== "children") {
							var T = 120 - 2 * (i + 1) - z.length - 1;
							s += fo(i + 1) + z + "=" + Sa(o[z], T) + `
`;
						}
					}), s = s === "" ? wt(i) + "<" + e + `>
` : wt(i) + "<" + e + `
` + s + wt(i) + `>
`;
				}
				return e = o.children, n = n.children, typeof e == "string" || typeof e == "number" || typeof e == "bigint" ? (u = "", (typeof n == "string" || typeof n == "number" || typeof n == "bigint") && (u = "" + n), s += Rs(u, "" + e, i + 1)) : (typeof n == "string" || typeof n == "number" || typeof n == "bigint") && (s = e == null ? s + Rs("" + n, null, i + 1) : s + Rs("" + n, void 0, i + 1)), s;
			}
			function wc(e, n) {
				var o = kc(e);
				if (o === null) {
					for (o = "", e = e.child; e;) o += wc(e, n), e = e.sibling;
					return o;
				}
				return wt(n) + "<" + o + `>
`;
			}
			function li(e, n) {
				var o = Is(e, n);
				if (o !== e && (e.children.length !== 1 || e.children[0] !== o)) return wt(n) + `...
` + li(o, n + 1);
				o = "";
				var i = e.fiber._debugInfo;
				if (i) for (var s = 0; s < i.length; s++) {
					var u = i[s].name;
					typeof u == "string" && (o += wt(n) + "<" + u + `>
`, n++);
				}
				if (i = "", s = e.fiber.pendingProps, e.fiber.tag === 6) i = Rs(s, e.serverProps, n), n++;
				else if (u = kc(e.fiber), u !== null) if (e.serverProps === void 0) {
					i = n;
					var f = 120 - 2 * i - u.length - 2, p = "";
					for (b in s) if (s.hasOwnProperty(b) && b !== "children") {
						var g = Sa(s[b], 15);
						if (f -= b.length + g.length + 2, 0 > f) {
							p += " ...";
							break;
						}
						p += " " + b + "=" + g;
					}
					i = wt(i) + "<" + u + p + `>
`, n++;
				} else e.serverProps === null ? (i = po(u, s, Wo(n)), n++) : typeof e.serverProps == "string" ? console.error("Should not have matched a non HostText fiber to a Text node. This is a bug in React.") : (i = Ls(u, s, e.serverProps, n), n++);
				var b = "";
				for (s = e.fiber.child, u = 0; s && u < e.children.length;) f = e.children[u], f.fiber === s ? (b += li(f, n), u++) : b += wc(s, n), s = s.sibling;
				for (s && 0 < e.children.length && (b += wt(n) + `...
`), s = e.serverTail, e.serverProps === null && n--, e = 0; e < s.length; e++) u = s[e], b = typeof u == "string" ? b + (fo(n) + Er(u, 120 - 2 * n) + `
`) : b + po(u.type, u.props, fo(n));
				return o + i + b;
			}
			function ll(e) {
				try {
					return `

` + li(e, 0);
				} catch {
					return "";
				}
			}
			function fm() {
				if (Bi === null) return "";
				var e = Bi;
				try {
					var n = "";
					switch (e.tag === 6 && (e = e.return), e.tag) {
						case 26:
						case 27:
						case 5:
							n += nt(e.type);
							break;
						case 13:
							n += nt("Suspense");
							break;
						case 19:
							n += nt("SuspenseList");
							break;
						case 31:
							n += nt("Activity");
							break;
						case 30:
							n += nt("ViewTransition");
							break;
						case 0:
						case 15:
						case 1:
							e._debugOwner || n !== "" || (n += Sc(e.type));
							break;
						case 11: e._debugOwner || n !== "" || (n += Sc(e.type.render));
					}
					for (; e;) if (typeof e.tag == "number") {
						var o = e;
						e = o._debugOwner;
						var i = o._debugStack;
						if (e && i) {
							var s = yc(i);
							s !== "" && (n += `
` + s);
						}
					} else if (e.debugStack != null) {
						var u = e.debugStack;
						(e = e.owner) && u && (n += `
` + yc(u));
					} else break;
					var f = n;
				} catch (p) {
					f = `
Error generating stack: ` + p.message + `
` + p.stack;
				}
				return f;
			}
			function B(e, n, o, i, s, u, f) {
				var p = Bi;
				Pc(e);
				try {
					return e !== null && e._debugTask ? e._debugTask.run(n.bind(null, o, i, s, u, f)) : n(o, i, s, u, f);
				} finally {
					Pc(p);
				}
				throw Error("runWithFiberInDEV should never be called in production. This is a bug in React.");
			}
			function Pc(e) {
				N.getCurrentStack = e === null ? null : fm, Qa = !1, Bi = e;
			}
			function Ao(e, n) {
				if (e.return === null) {
					if (Kr === null) Kr = {
						fiber: e,
						children: [],
						serverProps: void 0,
						serverTail: [],
						distanceFromLeaf: n
					};
					else {
						if (Kr.fiber !== e) throw Error("Saw multiple hydration diff roots in a pass. This is a bug in React.");
						Kr.distanceFromLeaf > n && (Kr.distanceFromLeaf = n);
					}
					return Kr;
				}
				var o = Ao(e.return, n + 1).children;
				return 0 < o.length && o[o.length - 1].fiber === e ? (o = o[o.length - 1], o.distanceFromLeaf > n && (o.distanceFromLeaf = n), o) : (n = {
					fiber: e,
					children: [],
					serverProps: void 0,
					serverTail: [],
					distanceFromLeaf: n
				}, o.push(n), n);
			}
			function xc() {
				le && console.error("We should not be hydrating here. This is a bug in React. Please file a bug.");
			}
			function _r(e, n) {
				qa || (e = Ao(e, 0), e.serverProps = null, n !== null && (n = Ft(n), e.serverTail.push(n)));
			}
			function Nr(e) {
				var n = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : !1, o = "", i = Kr;
				throw i !== null && (Kr = null, o = ll(i)), Ve(Ot(Error("Hydration failed because the server rendered " + (n ? "text" : "HTML") + ` didn't match the client. As a result this tree will be regenerated on the client. This can happen if a SSR-ed Client Component used:

- A server/client branch \`if (typeof window !== 'undefined')\`.
- Variable input such as \`Date.now()\` or \`Math.random()\` which changes each time it's called.
- Date formatting in a user's locale which doesn't match the server.
- External changing data without sending a snapshot of it along with the HTML.
- Invalid HTML tag nesting.

It can also happen if the client has a browser extension installed which messes with the HTML before React loaded.

https://react.dev/link/hydration-mismatch` + o), e)), J0;
			}
			function Wf(e, n) {
				if (!$e) throw Error("Expected prepareToHydrateHostInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
				Jd(e.stateNode, e.type, e.memoizedProps, n, e) || Nr(e, !0);
			}
			function Tr(e) {
				for (st = e.return; st;) switch (st.tag) {
					case 5:
					case 31:
					case 13:
						No = !1;
						return;
					case 27:
					case 3:
						No = !0;
						return;
					default: st = st.return;
				}
			}
			function Ln(e) {
				if (!$e || e !== st) return !1;
				if (!le) return Tr(e), le = !0, !1;
				var n = e.tag;
				if (je ? n !== 3 && n !== 27 && (n !== 5 || aa(e.type) && !ea(e.type, e.memoizedProps)) && rn && (sl(e), Nr(e)) : n !== 3 && (n !== 5 || aa(e.type) && !ea(e.type, e.memoizedProps)) && rn && (sl(e), Nr(e)), Tr(e), n === 13) {
					if (!$e) throw Error("Expected skipPastDehydratedSuspenseInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
					if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error("Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
					rn = de(e);
				} else if (n === 31) {
					if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error("Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
					rn = M0(e);
				} else rn = je && n === 27 ? Hu(e.type, rn) : st ? gr(e.stateNode) : null;
				return !0;
			}
			function sl(e) {
				for (var n = rn; n;) {
					var o = Ao(e, 0), i = Ft(n);
					o.serverTail.push(i), n = i.type === "Suspense" ? de(n) : gr(n);
				}
			}
			function Oo() {
				$e && (rn = st = null, qa = le = !1);
			}
			function ul() {
				var e = ss;
				return e !== null && (Yt === null ? Yt = e : Yt.push.apply(Yt, e), ss = null), e;
			}
			function Ve(e) {
				ss === null ? ss = [e] : ss.push(e);
			}
			function Fs() {
				var e = Kr;
				if (e !== null) {
					Kr = null;
					for (var n = ll(e); 0 < e.children.length;) e = e.children[0];
					B(e.fiber, function() {
						console.error(`A tree hydrated but some attributes of the server rendered HTML didn't match the client properties. This won't be patched up. This can happen if a SSR-ed Client Component used:

- A server/client branch \`if (typeof window !== 'undefined')\`.
- Variable input such as \`Date.now()\` or \`Math.random()\` which changes each time it's called.
- Date formatting in a user's locale which doesn't match the server.
- External changing data without sending a snapshot of it along with the HTML.
- Invalid HTML tag nesting.

It can also happen if the client has a browser extension installed which messes with the HTML before React loaded.

%s%s`, "https://react.dev/link/hydration-mismatch", n);
					});
				}
			}
			function cl() {
				rf = jg = null, of = !1;
			}
			function Bo(e, n, o) {
				yn ? (ze(Fg, n._currentValue, e), n._currentValue = o, ze(Z0, n._currentRenderer, e), n._currentRenderer !== void 0 && n._currentRenderer !== null && n._currentRenderer !== Dg && console.error("Detected multiple renderers concurrently rendering the same context provider. This is currently unsupported."), n._currentRenderer = Dg) : (ze(Fg, n._currentValue2, e), n._currentValue2 = o, ze(X0, n._currentRenderer2, e), n._currentRenderer2 !== void 0 && n._currentRenderer2 !== null && n._currentRenderer2 !== Dg && console.error("Detected multiple renderers concurrently rendering the same context provider. This is currently unsupported."), n._currentRenderer2 = Dg);
			}
			function ho(e, n) {
				var o = Fg.current;
				yn ? (e._currentValue = o, o = Z0.current, mn(Z0, n), e._currentRenderer = o) : (e._currentValue2 = o, o = X0.current, mn(X0, n), e._currentRenderer2 = o), mn(Fg, n);
			}
			function Cc(e, n, o) {
				for (; e !== null;) {
					var i = e.alternate;
					if ((e.childLanes & n) !== n ? (e.childLanes |= n, i !== null && (i.childLanes |= n)) : i !== null && (i.childLanes & n) !== n && (i.childLanes |= n), e === o) break;
					e = e.return;
				}
				e !== o && console.error("Expected to find the propagation root when scheduling context work. This error is likely caused by a bug in React. Please file an issue.");
			}
			function Ds(e, n, o, i) {
				var s = e.child;
				for (s !== null && (s.return = e); s !== null;) {
					var u = s.dependencies;
					if (u !== null) {
						var f = s.child;
						u = u.firstContext;
						e: for (; u !== null;) {
							var p = u;
							u = s;
							for (var g = 0; g < n.length; g++) if (p.context === n[g]) {
								u.lanes |= o, p = u.alternate, p !== null && (p.lanes |= o), Cc(u.return, o, e), i || (f = null);
								break e;
							}
							u = p.next;
						}
					} else if (s.tag === 18) {
						if (f = s.return, f === null) throw Error("We just came from a parent so we must have had a parent. This is a bug in React.");
						f.lanes |= o, u = f.alternate, u !== null && (u.lanes |= o), Cc(f, o, e), f = null;
					} else s.tag === 13 && s.memoizedState !== null && s.memoizedState.dehydrated === null ? (s.lanes |= o, f = s.alternate, f !== null && (f.lanes |= o), Cc(s.return, o, e), f = s.child, f = f !== null ? f.sibling : null) : f = s.child;
					if (f !== null) f.return = s;
					else for (f = s; f !== null;) {
						if (f === e) {
							f = null;
							break;
						}
						if (s = f.sibling, s !== null) {
							s.return = f.return, f = s;
							break;
						}
						f = f.return;
					}
					s = f;
				}
			}
			function Ho(e, n, o, i) {
				e = null;
				for (var s = n, u = !1; s !== null;) {
					if (!u) {
						if ((s.flags & 524288) !== 0) u = !0;
						else if ((s.flags & 262144) !== 0) break;
					}
					if (s.tag === 10) {
						var f = s.alternate;
						if (f === null) throw Error("Should have a current fiber. This is a bug in React.");
						if (f = f.memoizedProps, f !== null) {
							var p = s.type;
							Gt(s.pendingProps.value, f.value) || (e !== null ? e.push(p) : e = [p]);
						}
					} else if (s === Lg.current) {
						if (f = s.alternate, f === null) throw Error("Should have a current fiber. This is a bug in React.");
						f.memoizedState.memoizedState !== s.memoizedState.memoizedState && (e !== null ? e.push(Jr) : e = [Jr]);
					}
					s = s.return;
				}
				return e !== null && Ds(n, e, o, i), n.flags |= 262144, e !== null;
			}
			function dl(e) {
				for (e = e.firstContext; e !== null;) {
					var n = e.context;
					if (!Gt(yn ? n._currentValue : n._currentValue2, e.memoizedValue)) return !0;
					e = e.next;
				}
				return !1;
			}
			function gn(e) {
				jg = e, rf = null, e = e.dependencies, e !== null && (e.firstContext = null);
			}
			function K(e) {
				return of && console.error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo()."), fl(jg, e);
			}
			function si(e, n) {
				return jg === null && gn(e), fl(e, n);
			}
			function fl(e, n) {
				var o = yn ? n._currentValue : n._currentValue2;
				if (n = {
					context: n,
					memoizedValue: o,
					next: null
				}, rf === null) {
					if (e === null) throw Error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
					rf = n, e.dependencies = {
						lanes: 0,
						firstContext: n,
						_debugThenableState: null
					}, e.flags |= 524288;
				} else rf = rf.next = n;
				return o;
			}
			function pl() {
				return {
					controller: new N1(),
					data: /* @__PURE__ */ new Map(),
					refCount: 0
				};
			}
			function Mo(e) {
				e.controller.signal.aborted && console.warn("A cache instance was retained after it was already freed. This likely indicates a bug in React."), e.refCount++;
			}
			function Bt(e) {
				e.refCount--, 0 > e.refCount && console.warn("A cache instance was released after it was already freed. This likely indicates a bug in React."), e.refCount === 0 && T1(I1, function() {
					e.controller.abort();
				});
			}
			function js(e, n) {
				if ((e.pendingLanes & 4194048) !== 0) {
					var o = e.transitionTypes;
					for (o === null && (o = e.transitionTypes = []), e = 0; e < n.length; e++) {
						var i = n[e];
						o.indexOf(i) === -1 && o.push(i);
					}
				}
			}
			function Af(e) {
				var n = e.transitionTypes;
				return e.transitionTypes = null, n;
			}
			function tr(e, n, o) {
				(e & 127) !== 0 ? 0 > Ga && (Ga = Tn(), Nh = Ug(n), Y0 = n, o != null && (K0 = G(o)), $p() && (Sn = !0, cs = 1), e = pr(), n = ne(), e !== af || n !== Th ? af = -1.1 : n !== null && (cs = 1), Ju = e, Th = n) : e & 4194048 && 0 > To && (To = Tn(), Ih = Ug(n), Kb = n, o != null && (ey = G(o)), 0 > Vi) && (e = pr(), n = ne(), (e !== fs || n !== Zu) && (fs = -1.1), ds = e, Zu = n);
			}
			function pm(e) {
				if (0 > Ga) {
					Ga = Tn(), Nh = e._debugTask != null ? e._debugTask : null, $p() && (cs = 1);
					var n = pr(), o = ne();
					n !== af || o !== Th ? af = -1.1 : o !== null && (cs = 1), Ju = n, Th = o;
				}
				0 > To && (To = Tn(), Ih = e._debugTask != null ? e._debugTask : null, 0 > Vi) && (e = pr(), n = ne(), (e !== fs || n !== Zu) && (fs = -1.1), ds = e, Zu = n);
			}
			function mo() {
				var e = Gu;
				return Gu = 0, e;
			}
			function Us(e) {
				var n = Gu;
				return Gu = e, n;
			}
			function hl(e) {
				var n = Gu;
				return Gu += e, n;
			}
			function Ws() {
				J = V = -1.1;
			}
			function Pt() {
				var e = V;
				return V = -1.1, e;
			}
			function gt(e) {
				0 <= e && (V = e);
			}
			function Ir() {
				var e = dn;
				return dn = -0, e;
			}
			function go(e) {
				0 <= e && (dn = e);
			}
			function Rr() {
				var e = on;
				return on = null, e;
			}
			function Lr() {
				var e = Sn;
				return Sn = !1, e;
			}
			function zc(e) {
				Jt = Tn(), 0 > e.actualStartTime && (e.actualStartTime = Jt);
			}
			function As(e) {
				if (0 <= Jt) {
					var n = Tn() - Jt;
					e.actualDuration += n, e.selfBaseDuration = n, Jt = -1;
				}
			}
			function Of(e) {
				if (0 <= Jt) {
					var n = Tn() - Jt;
					e.actualDuration += n, Jt = -1;
				}
			}
			function Fr() {
				if (0 <= Jt) {
					var e = Tn(), n = e - Jt;
					Jt = -1, Gu += n, dn += n, J = e;
				}
			}
			function Bf(e) {
				on === null && (on = []), on.push(e), Mi === null && (Mi = []), Mi.push(e);
			}
			function Dr() {
				Jt = Tn(), 0 > V && (V = Jt);
			}
			function ml(e) {
				for (var n = e.child; n;) e.actualDuration += n.actualDuration, n = n.sibling;
			}
			function Ec() {}
			function jr(e) {
				e !== sf && e.next === null && (sf === null ? lf = sf = e : sf = sf.next = e), Hg = !0, N.actQueue !== null ? ob || (ob = !0, $f()) : rb || (rb = !0, $f());
			}
			function Ur(e, n) {
				if (!ab && Hg) {
					ab = !0;
					do
						for (var o = !1, i = lf; i !== null;) {
							if (!n) if (e !== 0) {
								var s = i.pendingLanes;
								if (s === 0) var u = 0;
								else {
									var f = i.suspendedLanes, p = i.pingedLanes;
									u = (1 << 31 - d(42 | e) + 1) - 1, u &= s & ~(f & ~p), u = u & 201326741 ? u & 201326741 | 1 : u ? u | 2 : 0;
								}
								u !== 0 && (o = !0, _c(i, u));
							} else u = te, u = ks(i, i === Ge ? u : 0, i.cancelPendingCommit !== null || i.timeoutHandle !== Wn), !(u & 3) || At(i, u) || (o = !0, _c(i, u));
							i = i.next;
						}
					while (o);
					ab = !1;
				}
			}
			function Hf() {
				Qe(), gl();
			}
			function gl() {
				Hg = ob = rb = !1;
				var e = 0;
				Yu !== 0 && hr() && (e = Yu);
				for (var n = Re(), o = null, i = lf; i !== null;) {
					var s = i.next, u = Os(i, n);
					u === 0 ? (i.next = null, o === null ? lf = s : o.next = s, s === null && (sf = o)) : (o = i, (e !== 0 || u & 3) && (Hg = !0)), i = s;
				}
				pn !== ni && pn !== h0 || Ur(e, !1), Yu !== 0 && (Yu = 0);
			}
			function Os(e, n) {
				for (var o = e.suspendedLanes, i = e.pingedLanes, s = e.expirationTimes, u = e.pendingLanes & -62914561; 0 < u;) {
					var f = 31 - d(u), p = 1 << f, g = s[f];
					g === -1 ? ((p & o) === 0 || (p & i) !== 0) && (s[f] = ba(p, n)) : g <= n && (e.expiredLanes |= p), u &= ~p;
				}
				if (n = Ge, o = te, o = ks(e, e === n ? o : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== Wn), i = e.callbackNode, o === 0 || e === n && (Ae === sc || Ae === uc) || e.cancelPendingCommit !== null) return i !== null && Vf(i), e.callbackNode = null, e.callbackPriority = 0;
				if ((o & 3) === 0 || At(e, o)) {
					if (n = o & -o, n !== e.callbackPriority || N.actQueue !== null && i !== ib) Vf(i);
					else return n;
					switch (ya(o)) {
						case 2:
						case 8:
							o = x;
							break;
						case 32:
							o = P;
							break;
						case 268435456:
							o = E;
							break;
						default: o = P;
					}
					return i = Mf.bind(null, e), N.actQueue !== null ? (N.actQueue.push(i), o = ib) : o = U(o, i), e.callbackPriority = n, e.callbackNode = o, n;
				}
				return i !== null && Vf(i), e.callbackPriority = 2, e.callbackNode = null, 2;
			}
			function Mf(e, n) {
				if (Bg = Og = !1, Qe(), pn !== ni && pn !== h0) return e.callbackNode = null, e.callbackPriority = 0, null;
				var o = e.callbackNode;
				if (ro === p0 && (ro = Lb), Ol() && e.callbackNode !== o) return null;
				var i = te;
				return i = ks(e, e === Ge ? i : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== Wn), i === 0 ? null : (Zm(e, i, n), Os(e, Re()), e.callbackNode != null && e.callbackNode === o ? Mf.bind(null, e) : null);
			}
			function _c(e, n) {
				if (Ol()) return null;
				Og = Bg, Bg = !1, Zm(e, n, !0);
			}
			function Vf(e) {
				e !== ib && e !== null && A(e);
			}
			function $f() {
				N.actQueue !== null && N.actQueue.push(function() {
					return gl(), null;
				}), Ti ? Wu(function() {
					(ve & (pt | Fo)) !== ft ? U(ia, Hf) : gl();
				}) : U(ia, Hf);
			}
			function Nc() {
				if (Yu === 0) {
					var e = ps;
					e === 0 && (e = C, C <<= 1, !(C & 261888) && (C = 256)), Yu = e;
				}
				return Yu;
			}
			function hm(e, n) {
				if (Lh === null) {
					var o = Lh = [];
					lb = 0, ps = Nc(), uf = {
						status: "pending",
						value: void 0,
						then: function(i) {
							o.push(i);
						}
					};
				}
				return lb++, n.then(Qf, Qf), n;
			}
			function Qf() {
				if (--lb === 0 && (-1 < To || (Vi = -1.1), _h = null, Lh !== null)) {
					uf !== null && (uf.status = "fulfilled");
					var e = Lh;
					Lh = null, ps = 0, uf = null;
					for (var n = 0; n < e.length; n++) (0, e[n])();
				}
			}
			function mm(e, n) {
				var o = [], i = {
					status: "pending",
					value: null,
					reason: null,
					then: function(s) {
						o.push(s);
					}
				};
				return e.then(function() {
					i.status = "fulfilled", i.value = n;
					for (var s = 0; s < o.length; s++) (0, o[s])(n);
				}, function(s) {
					for (i.status = "rejected", i.reason = s, s = 0; s < o.length; s++) (0, o[s])(void 0);
				}), i;
			}
			function Bs() {
				var e = Ku.current;
				return e !== null ? e : Ge.pooledCache;
			}
			function Hs(e, n) {
				n === null ? ze(Ku, Ku.current, e) : ze(Ku, n.pool, e);
			}
			function qf() {
				var e = Bs();
				return e === null ? null : {
					parent: yn ? vn._currentValue : vn._currentValue2,
					pool: e
				};
			}
			function bl(e, n) {
				if (Gt(e, n)) return !0;
				if (typeof e != "object" || e === null || typeof n != "object" || n === null) return !1;
				var o = Object.keys(e), i = Object.keys(n);
				if (o.length !== i.length) return !1;
				for (i = 0; i < o.length; i++) {
					var s = o[i];
					if (!Ig.call(n, s) || !Gt(e[s], n[s])) return !1;
				}
				return !0;
			}
			function Gf() {
				return {
					didWarnAboutUncachedPromise: !1,
					thenables: []
				};
			}
			function Jf(e) {
				return e = e.status, e === "fulfilled" || e === "rejected";
			}
			function Zf(e, n, o, i) {
				N.actQueue !== null && (N.didUsePromise = !0);
				var s = e.thenables;
				if (o = s[o], o === void 0 ? s.push(n) : o !== n && (e.didWarnAboutUncachedPromise || (e.didWarnAboutUncachedPromise = !0, console.error("A component was suspended by an uncached promise. Creating promises inside a Client Component or hook is not yet supported, except via a Suspense-compatible library or framework.")), n.then(Ec, Ec), n = o), n._debugInfo === void 0) {
					e = performance.now(), s = n.displayName;
					var u = {
						name: typeof s == "string" ? s : "Promise",
						start: e,
						end: e,
						value: n
					};
					n._debugInfo = [{ awaited: u }], n.status !== "fulfilled" && n.status !== "rejected" && (e = function() {
						u.end = performance.now();
					}, n.then(e, e));
				}
				switch (n.status) {
					case "fulfilled": return n.value;
					case "rejected": throw i = n.reason, Yf(i), i === void 0 && !("reason" in n) ? Error("A rejected Promise was passed to React without a `reason` property. React threw a generic error from where the Promise was used to assist in identifying the problematic Promise. Make sure that instrumented Promises correctly set the `reason` property when setting `status` to `'rejected'`.") : i;
					default:
						if (typeof n.status == "string") n.then(Ec, Ec);
						else {
							if (e = Ge, e !== null && 100 < e.shellSuspendCounter) throw Error("An unknown Component is an async Client Component. Only Server Components can be async at the moment. This error is often caused by accidentally adding `'use client'` to a module that was originally written for the server.");
							e = n, e.status = "pending", e.then(function(f) {
								if (n.status === "pending") {
									var p = n;
									p.status = "fulfilled", p.value = f;
								}
							}, function(f) {
								if (n.status === "pending") {
									var p = n;
									p.status = "rejected", p.reason = f;
								}
							});
						}
						switch (n.status) {
							case "fulfilled": return n.value;
							case "rejected": throw i = n.reason, Yf(i), i;
						}
						throw tc = n, Oh = !0, db || i === null || i.alternate !== null || (nc = i, Qg = Error("This library called use() to suspend in a previous render but did not call use() when it finished. This indicates an incorrect use of use(). Learn more: https://react.dev/warnings/conditional-use-of-use")), cf;
				}
			}
			function bo(e) {
				try {
					return j1(e);
				} catch (n) {
					throw n !== null && typeof n == "object" && typeof n.then == "function" ? (tc = n, Oh = !0, cf) : n;
				}
			}
			function Xf() {
				if (tc === null) throw Error("Expected a suspended thenable. This is a bug in React. Please file an issue.");
				var e = tc;
				return tc = null, Oh = !1, e;
			}
			function Yf(e) {
				if (e === cf || e === Vg) throw Error("Hooks are not supported inside an async component. This error is often caused by accidentally adding `'use client'` to a module that was originally written for the server.");
			}
			function gm(e, n) {
				return e === n ? !0 : e.tag !== n.tag || e.type !== n.type || e.key !== n.key || e.index !== n.index || e.tag === 3 && e.stateNode !== n.stateNode || e.return === null || n.return === null ? !1 : gm(e.return, n.return);
			}
			function bt(e) {
				var n = pe;
				return e != null && (pe = n === null ? e : n.concat(e)), n;
			}
			function Tc() {
				var e = pe;
				if (e != null) {
					for (var n = e.length - 1; 0 <= n; n--) if (e[n].name != null) {
						var o = e[n].debugTask;
						if (o != null) return o;
					}
				}
				return null;
			}
			function wa(e, n, o) {
				for (var i = Object.keys(e.props), s = 0; s < i.length; s++) {
					var u = i[s];
					if (u !== "children" && u !== "key" && u !== "ref") {
						n === null && (n = Id(e, o.mode, 0), n._debugInfo = pe, n.return = o), B(n, function(f) {
							console.error("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key`, `ref`, and `children` props.", f);
						}, u);
						break;
					}
				}
			}
			function yl(e) {
				var n = Bh;
				return Bh += 1, df === null && (df = Gf()), Zf(df, e, n, null);
			}
			function Wr(e, n) {
				n = n.props.ref, e.ref = n !== void 0 ? n : null;
			}
			function Kf(e, n) {
				throw n.$$typeof === D0 ? Error(`A React Element from an older version of React was rendered. This is not supported. It can happen if:
- Multiple copies of the "react" package is used.
- A library pre-bundled an old copy of "react" or "react/jsx-runtime".
- A compiler tries to "inline" JSX instead of using the runtime.`) : (e = Object.prototype.toString.call(n), Error("Objects are not valid as a React child (found: " + (e === "[object Object]" ? "object with keys {" + Object.keys(n).join(", ") + "}" : e) + "). If you meant to render a collection of children, use an array instead."));
			}
			function Ms(e, n) {
				var o = Tc();
				o !== null ? o.run(Kf.bind(null, e, n)) : Kf(e, n);
			}
			function Ic(e, n) {
				var o = G(e) || "Component";
				yy[o] || (yy[o] = !0, n = n.displayName || n.name || "Component", e.tag === 3 ? console.error(`Functions are not valid as a React child. This may happen if you return %s instead of <%s /> from render. Or maybe you meant to call this function rather than return it.
  root.render(%s)`, n, n, n) : console.error(`Functions are not valid as a React child. This may happen if you return %s instead of <%s /> from render. Or maybe you meant to call this function rather than return it.
  <%s>{%s}</%s>`, n, n, o, n, o));
			}
			function Vs(e, n) {
				var o = Tc();
				o !== null ? o.run(Ic.bind(null, e, n)) : Ic(e, n);
			}
			function ep(e, n) {
				var o = G(e) || "Component";
				vy[o] || (vy[o] = !0, n = String(n), e.tag === 3 ? console.error(`Symbols are not valid as a React child.
  root.render(%s)`, n) : console.error(`Symbols are not valid as a React child.
  <%s>%s</%s>`, o, n, o));
			}
			function yo(e, n) {
				var o = Tc();
				o !== null ? o.run(ep.bind(null, e, n)) : ep(e, n);
			}
			function $s(e) {
				function n(S, v) {
					if (e) {
						var w = S.deletions;
						w === null ? (S.deletions = [v], S.flags |= 16) : w.push(v);
					}
				}
				function o(S, v) {
					if (!e) return null;
					for (; v !== null;) n(S, v), v = v.sibling;
					return null;
				}
				function i(S) {
					for (var v = /* @__PURE__ */ new Map(); S !== null;) S.key === null ? v.set(S.index, S) : v.set(S.key, S), S = S.sibling;
					return v;
				}
				function s(S, v) {
					return S = Ko(S, v), S.index = 0, S.sibling = null, S;
				}
				function u(S, v, w) {
					return S.index = w, e ? (w = S.alternate, w !== null ? (w = w.index, w < v ? (S.flags |= 2, v) : w) : (S.flags |= 134217730, v)) : (S.flags |= 1048576, v);
				}
				function f(S) {
					return e && S.alternate === null && (S.flags |= 134217730), S;
				}
				function p(S, v, w, I) {
					return v === null || v.tag !== 6 ? (v = Nt(w, S.mode, I), v.return = S, v._debugOwner = S, v._debugTask = S._debugTask, v._debugInfo = pe, v) : (v = s(v, w), v.return = S, v._debugInfo = pe, v);
				}
				function g(S, v, w, I) {
					var O = w.type;
					return O === Qr ? (v = k(S, v, w.props.children, I, w.key), Wr(v, w), wa(w, v, S), v) : v !== null && (v.elementType === O || hg(v, w) || typeof O == "object" && O !== null && O.$$typeof === qn && bo(O) === v.type) ? (v = s(v, w.props), Wr(v, w), v.return = S, v._debugOwner = w._owner, v._debugInfo = pe, v) : (v = Id(w, S.mode, I), Wr(v, w), v.return = S, v._debugInfo = pe, v);
				}
				function b(S, v, w, I) {
					return v === null || v.tag !== 4 || v.stateNode.containerInfo !== w.containerInfo || v.stateNode.implementation !== w.implementation ? (v = Hl(w, S.mode, I), v.return = S, v._debugInfo = pe, v) : (v = s(v, w.children || []), v.return = S, v._debugInfo = pe, v);
				}
				function k(S, v, w, I, O) {
					return v === null || v.tag !== 7 ? (v = zi(w, S.mode, I, O), v.return = S, v._debugOwner = S, v._debugTask = S._debugTask, v._debugInfo = pe, v) : (v = s(v, w), v.return = S, v._debugInfo = pe, v);
				}
				function z(S, v, w) {
					if (typeof v == "string" && v !== "" || typeof v == "number" || typeof v == "bigint") return v = Nt("" + v, S.mode, w), v.return = S, v._debugOwner = S, v._debugTask = S._debugTask, v._debugInfo = pe, v;
					if (typeof v == "object" && v !== null) {
						switch (v.$$typeof) {
							case xo: return w = Id(v, S.mode, w), Wr(w, v), w.return = S, S = bt(v._debugInfo), w._debugInfo = pe, pe = S, w;
							case Ua: return v = Hl(v, S.mode, w), v.return = S, v._debugInfo = pe, v;
							case qn:
								var I = bt(v._debugInfo);
								return v = bo(v), S = z(S, v, w), pe = I, S;
						}
						if (Gn(v) || ti(v)) return w = zi(v, S.mode, w, null), w.return = S, w._debugOwner = S, w._debugTask = S._debugTask, S = bt(v._debugInfo), w._debugInfo = pe, pe = S, w;
						if (typeof v.then == "function") return I = bt(v._debugInfo), S = z(S, yl(v), w), pe = I, S;
						if (v.$$typeof === sn) return z(S, si(S, v), w);
						Ms(S, v);
					}
					return typeof v == "function" && Vs(S, v), typeof v == "symbol" && yo(S, v), null;
				}
				function T(S, v, w, I) {
					var O = v !== null ? v.key : null;
					if (typeof w == "string" && w !== "" || typeof w == "number" || typeof w == "bigint") return O !== null ? null : p(S, v, "" + w, I);
					if (typeof w == "object" && w !== null) {
						switch (w.$$typeof) {
							case xo: return w.key === O ? (O = bt(w._debugInfo), S = g(S, v, w, I), pe = O, S) : null;
							case Ua: return w.key === O ? b(S, v, w, I) : null;
							case qn: return O = bt(w._debugInfo), w = bo(w), S = T(S, v, w, I), pe = O, S;
						}
						if (Gn(w) || ti(w)) return O !== null ? null : (O = bt(w._debugInfo), S = k(S, v, w, I, null), pe = O, S);
						if (typeof w.then == "function") return O = bt(w._debugInfo), S = T(S, v, yl(w), I), pe = O, S;
						if (w.$$typeof === sn) return T(S, v, si(S, w), I);
						Ms(S, w);
					}
					return typeof w == "function" && Vs(S, w), typeof w == "symbol" && yo(S, w), null;
				}
				function H(S, v, w, I, O) {
					if (typeof I == "string" && I !== "" || typeof I == "number" || typeof I == "bigint") return S = S.get(w) || null, p(v, S, "" + I, O);
					if (typeof I == "object" && I !== null) {
						switch (I.$$typeof) {
							case xo: return w = S.get(I.key === null ? w : I.key) || null, S = bt(I._debugInfo), v = g(v, w, I, O), pe = S, v;
							case Ua: return S = S.get(I.key === null ? w : I.key) || null, b(v, S, I, O);
							case qn:
								var Pe = bt(I._debugInfo);
								return I = bo(I), v = H(S, v, w, I, O), pe = Pe, v;
						}
						if (Gn(I) || ti(I)) return w = S.get(w) || null, S = bt(I._debugInfo), v = k(v, w, I, O, null), pe = S, v;
						if (typeof I.then == "function") return Pe = bt(I._debugInfo), v = H(S, v, w, yl(I), O), pe = Pe, v;
						if (I.$$typeof === sn) return H(S, v, w, si(v, I), O);
						Ms(v, I);
					}
					return typeof I == "function" && Vs(v, I), typeof I == "symbol" && yo(v, I), null;
				}
				function $(S, v, w, I) {
					if (typeof w != "object" || w === null) return I;
					switch (w.$$typeof) {
						case xo:
						case Ua:
							ma(S, v, w);
							var O = w.key;
							if (typeof O != "string") break;
							if (I === null) {
								I = /* @__PURE__ */ new Set(), I.add(O);
								break;
							}
							if (!I.has(O)) {
								I.add(O);
								break;
							}
							B(v, function() {
								console.error("Encountered two children with the same key, `%s`. Keys should be unique so that components maintain their identity across updates. Non-unique keys may cause children to be duplicated and/or omitted — the behavior is unsupported and could change in a future version.", O);
							});
							break;
						case qn: w = bo(w), $(S, v, w, I);
					}
					return I;
				}
				function an(S, v, w, I) {
					for (var O = null, Pe = null, oe = null, ae = v, ue = v = 0, hn = null; ae !== null && ue < w.length; ue++) {
						ae.index > ue ? (hn = ae, ae = null) : hn = ae.sibling;
						var He = T(S, ae, w[ue], I);
						if (He === null) {
							ae === null && (ae = hn);
							break;
						}
						O = $(S, He, w[ue], O), e && ae && He.alternate === null && n(S, ae), v = u(He, v, ue), oe === null ? Pe = He : oe.sibling = He, oe = He, ae = hn;
					}
					if (ue === w.length) return o(S, ae), le && uo(S, ue), Pe;
					if (ae === null) {
						for (; ue < w.length; ue++) ae = z(S, w[ue], I), ae !== null && (O = $(S, ae, w[ue], O), v = u(ae, v, ue), oe === null ? Pe = ae : oe.sibling = ae, oe = ae);
						return le && uo(S, ue), Pe;
					}
					for (ae = i(ae); ue < w.length; ue++) hn = H(ae, S, ue, w[ue], I), hn !== null && (O = $(S, hn, w[ue], O), e && (He = hn.alternate, He !== null && ae.delete(He.key === null ? ue : He.key)), v = u(hn, v, ue), oe === null ? Pe = hn : oe.sibling = hn, oe = hn);
					return e && ae.forEach(function(Xi) {
						return n(S, Xi);
					}), le && uo(S, ue), Pe;
				}
				function Hn(S, v, w, I) {
					if (w == null) throw Error("An iterable object provided no iterator.");
					for (var O = null, Pe = null, oe = v, ae = v = 0, ue = null, hn = null, He = w.next(); oe !== null && !He.done; ae++, He = w.next()) {
						oe.index > ae ? (ue = oe, oe = null) : ue = oe.sibling;
						var Xi = T(S, oe, He.value, I);
						if (Xi === null) {
							oe === null && (oe = ue);
							break;
						}
						hn = $(S, Xi, He.value, hn), e && oe && Xi.alternate === null && n(S, oe), v = u(Xi, v, ae), Pe === null ? O = Xi : Pe.sibling = Xi, Pe = Xi, oe = ue;
					}
					if (He.done) return o(S, oe), le && uo(S, ae), O;
					if (oe === null) {
						for (; !He.done; ae++, He = w.next()) oe = z(S, He.value, I), oe !== null && (hn = $(S, oe, He.value, hn), v = u(oe, v, ae), Pe === null ? O = oe : Pe.sibling = oe, Pe = oe);
						return le && uo(S, ae), O;
					}
					for (oe = i(oe); !He.done; ae++, He = w.next()) ue = H(oe, S, ae, He.value, I), ue !== null && (hn = $(S, ue, He.value, hn), e && (He = ue.alternate, He !== null && oe.delete(He.key === null ? ae : He.key)), v = u(ue, v, ae), Pe === null ? O = ue : Pe.sibling = ue, Pe = ue);
					return e && oe.forEach(function(V1) {
						return n(S, V1);
					}), le && uo(S, ae), O;
				}
				function ha(S, v, w, I) {
					if (typeof w == "object" && w !== null && w.type === Qr && w.key === null && w.props.ref === void 0 && (wa(w, null, S), w = w.props.children), typeof w == "object" && w !== null) {
						switch (w.$$typeof) {
							case xo:
								var O = bt(w._debugInfo);
								e: {
									for (var Pe = w.key; v !== null;) {
										if (v.key === Pe) {
											if (Pe = w.type, Pe === Qr) {
												if (v.tag === 7) {
													o(S, v.sibling), I = s(v, w.props.children), Wr(I, w), I.return = S, I._debugOwner = w._owner, I._debugInfo = pe, wa(w, I, S), S = I;
													break e;
												}
											} else if (v.elementType === Pe || hg(v, w) || typeof Pe == "object" && Pe !== null && Pe.$$typeof === qn && bo(Pe) === v.type) {
												o(S, v.sibling), I = s(v, w.props), Wr(I, w), I.return = S, I._debugOwner = w._owner, I._debugInfo = pe, S = I;
												break e;
											}
											o(S, v);
											break;
										} else n(S, v);
										v = v.sibling;
									}
									w.type === Qr ? (I = zi(w.props.children, S.mode, I, w.key), Wr(I, w), I.return = S, I._debugOwner = S, I._debugTask = S._debugTask, I._debugInfo = pe, wa(w, I, S), S = I) : (I = Id(w, S.mode, I), Wr(I, w), I.return = S, I._debugInfo = pe, S = I);
								}
								return S = f(S), pe = O, S;
							case Ua:
								e: {
									for (O = w, w = O.key; v !== null;) {
										if (v.key === w) {
											if (v.tag === 4 && v.stateNode.containerInfo === O.containerInfo && v.stateNode.implementation === O.implementation) {
												o(S, v.sibling), I = s(v, O.children || []), I.return = S, S = I;
												break e;
											} else {
												o(S, v);
												break;
											}
										} else n(S, v);
										v = v.sibling;
									}
									I = Hl(O, S.mode, I), I.return = S, S = I;
								}
								return f(S);
							case qn: return O = bt(w._debugInfo), w = bo(w), S = ha(S, v, w, I), pe = O, S;
						}
						if (Gn(w)) return an(S, v, w, I);
						if (ti(w)) {
							if (O = w, w = ti(O), typeof w != "function") throw Error("An object is not an iterable. This error is likely caused by a bug in React. Please file an issue.");
							return Pe = w.call(O), Pe === O ? (S.tag !== 0 || Object.prototype.toString.call(S.type) !== "[object GeneratorFunction]" || Object.prototype.toString.call(Pe) !== "[object Generator]") && (gy || console.error("Using Iterators as children is unsupported and will likely yield unexpected results because enumerating a generator mutates it. You may convert it to an array with `Array.from()` or the `[...spread]` operator before rendering. You can also use an Iterable that can iterate multiple times over the same items."), gy = !0) : O.entries !== w || fb || (console.error("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), fb = !0), Hn(S, v, Pe, I);
						}
						if (typeof w.then == "function") return O = bt(w._debugInfo), S = ha(S, v, yl(w), I), pe = O, S;
						if (w.$$typeof === sn) return ha(S, v, si(S, w), I);
						Ms(S, w);
					}
					return typeof w == "string" && w !== "" || typeof w == "number" || typeof w == "bigint" ? (O = "" + w, v !== null && v.tag === 6 ? (o(S, v.sibling), I = s(v, O), I.return = S, S = I) : (o(S, v), I = Nt(O, S.mode, I), I.return = S, I._debugOwner = S, I._debugTask = S._debugTask, I._debugInfo = pe, S = I), f(S)) : (typeof w == "function" && Vs(S, w), typeof w == "symbol" && yo(S, w), o(S, v));
				}
				return function(S, v, w, I) {
					var O = pe;
					pe = null;
					try {
						Bh = 0;
						var Pe = ha(S, v, w, I);
						return df = null, Pe;
					} catch (hn) {
						if (hn === cf || hn === Vg) throw hn;
						var oe = ht(29, hn, null, S.mode);
						oe.lanes = I, oe.return = S;
						var ae = oe._debugInfo = pe;
						if (oe._debugOwner = S._debugOwner, oe._debugTask = S._debugTask, ae != null) {
							for (var ue = ae.length - 1; 0 <= ue; ue--) if (typeof ae[ue].stack == "string") {
								oe._debugOwner = ae[ue], oe._debugTask = ae[ue].debugTask;
								break;
							}
						}
						return oe;
					} finally {
						pe = O;
					}
				};
			}
			function np(e, n) {
				var o = Gn(e);
				return e = !o && typeof ti(e) == "function", o || e ? (o = o ? "array" : "iterable", console.error("A nested %s was passed to row #%s in <SuspenseList />. Wrap it in an additional SuspenseList to configure its revealOrder: <SuspenseList revealOrder=...> ... <SuspenseList revealOrder=...>{%s}</SuspenseList> ... </SuspenseList>", o, n, o), !1) : !0;
			}
			function vl() {
				for (var e = ff, n = pb = ff = 0; n < e;) {
					var o = Io[n];
					Io[n++] = null;
					var i = Io[n];
					Io[n++] = null;
					var s = Io[n];
					Io[n++] = null;
					var u = Io[n];
					if (Io[n++] = null, i !== null && s !== null) {
						var f = i.pending;
						f === null ? s.next = s : (s.next = f.next, f.next = s), i.pending = s;
					}
					u !== 0 && wn(o, s, u);
				}
			}
			function Qs(e, n, o, i) {
				Io[ff++] = e, Io[ff++] = n, Io[ff++] = o, Io[ff++] = i, pb |= i, e.lanes |= i, e = e.alternate, e !== null && (e.lanes |= i);
			}
			function Rc(e, n, o, i) {
				return Qs(e, n, o, i), qs(e);
			}
			function tt(e, n) {
				return Qs(e, null, null, n), qs(e);
			}
			function wn(e, n, o) {
				e.lanes |= o;
				var i = e.alternate;
				i !== null && (i.lanes |= o);
				for (var s = !1, u = e.return; u !== null;) u.childLanes |= o, i = u.alternate, i !== null && (i.childLanes |= o), u.tag === 22 && (e = u.stateNode, e === null || e._visibility & Hh || (s = !0)), e = u, u = u.return;
				return e.tag === 3 ? (u = e.stateNode, s && n !== null && (s = 31 - d(o), e = u.hiddenUpdates, i = e[s], i === null ? e[s] = [n] : i.push(n), n.lane = o | 536870912), u) : null;
			}
			function qs(e) {
				if (rm > B1) throw fc = rm = 0, om = b0 = null, Error("Maximum update depth exceeded. This can happen when a component repeatedly calls setState inside componentWillUpdate or componentDidUpdate. React limits the number of nested updates to prevent infinite loops.");
				fc > H1 && (fc = 0, om = null, console.error("Maximum update depth exceeded. This can happen when a component calls setState inside useEffect, but useEffect either doesn't have a dependency array, or one of the dependencies changes on every render.")), e.alternate === null && e.flags & 4098 && pg(e);
				for (var n = e, o = n.return; o !== null;) n.alternate === null && n.flags & 4098 && pg(e), n = o, o = n.return;
				return n.tag === 3 ? n.stateNode : null;
			}
			function Lc(e) {
				e.updateQueue = {
					baseState: e.memoizedState,
					firstBaseUpdate: null,
					lastBaseUpdate: null,
					shared: {
						pending: null,
						lanes: 0,
						hiddenCallbacks: null
					},
					callbacks: null
				};
			}
			function Fc(e, n) {
				e = e.updateQueue, n.updateQueue === e && (n.updateQueue = {
					baseState: e.baseState,
					firstBaseUpdate: e.firstBaseUpdate,
					lastBaseUpdate: e.lastBaseUpdate,
					shared: e.shared,
					callbacks: null
				});
			}
			function Vo(e) {
				return {
					lane: e,
					tag: ky,
					payload: null,
					callback: null,
					next: null
				};
			}
			function rr(e, n, o) {
				var i = e.updateQueue;
				if (i === null) return null;
				if (i = i.shared, mb === i && !xy) {
					var s = G(e);
					console.error(`An update (setState, replaceState, or forceUpdate) was scheduled from inside an update function. Update functions should be pure, with zero side-effects. Consider using componentDidUpdate or a callback.

Please update the following component: %s`, s), xy = !0;
				}
				return (ve & pt) !== ft ? (s = i.pending, s === null ? n.next = n : (n.next = s.next, s.next = n), i.pending = n, n = qs(e), wn(e, null, o), n) : (Qs(e, i, n, o), qs(e));
			}
			function Sl(e, n, o) {
				if (n = n.updateQueue, n !== null && (n = n.shared, (o & 4194048) !== 0)) {
					var i = n.lanes;
					i &= e.pendingLanes, o |= i, n.lanes = o, If(e, o);
				}
			}
			function ui(e, n) {
				var o = e.updateQueue, i = e.alternate;
				if (i !== null && (i = i.updateQueue, o === i)) {
					var s = null, u = null;
					if (o = o.firstBaseUpdate, o !== null) {
						do {
							var f = {
								lane: o.lane,
								tag: o.tag,
								payload: o.payload,
								callback: null,
								next: null
							};
							u === null ? s = u = f : u = u.next = f, o = o.next;
						} while (o !== null);
						u === null ? s = u = n : u = u.next = n;
					} else s = u = n;
					o = {
						baseState: i.baseState,
						firstBaseUpdate: s,
						lastBaseUpdate: u,
						shared: i.shared,
						callbacks: i.callbacks
					}, e.updateQueue = o;
					return;
				}
				e = o.lastBaseUpdate, e === null ? o.firstBaseUpdate = n : e.next = n, o.lastBaseUpdate = n;
			}
			function kl() {
				if (gb) {
					var e = uf;
					if (e !== null) throw e;
				}
			}
			function Gs(e, n, o, i) {
				gb = !1;
				var s = e.updateQueue;
				hs = !1, mb = s.shared;
				var u = s.firstBaseUpdate, f = s.lastBaseUpdate, p = s.shared.pending;
				if (p !== null) {
					s.shared.pending = null;
					var g = p, b = g.next;
					g.next = null, f === null ? u = b : f.next = b, f = g;
					var k = e.alternate;
					k !== null && (k = k.updateQueue, p = k.lastBaseUpdate, p !== f && (p === null ? k.firstBaseUpdate = b : p.next = b, k.lastBaseUpdate = g));
				}
				if (u !== null) {
					var z = s.baseState;
					f = 0, k = b = g = null, p = u;
					do {
						var T = p.lane & -536870913, H = T !== p.lane;
						if (H ? (te & T) === T : (i & T) === T) {
							T !== 0 && T === ps && (gb = !0), k !== null && (k = k.next = {
								lane: 0,
								tag: p.tag,
								payload: p.payload,
								callback: null,
								next: null
							});
							e: {
								T = e;
								var $ = p, an = n, Hn = o;
								switch ($.tag) {
									case wy:
										if ($ = $.payload, typeof $ == "function") {
											of = !0;
											var ha = $.call(Hn, z, an);
											if (T.mode & 8) {
												Oe(!0);
												try {
													$.call(Hn, z, an);
												} finally {
													Oe(!1);
												}
											}
											of = !1, z = ha;
											break e;
										}
										z = $;
										break e;
									case hb: T.flags = T.flags & -65537 | 128;
									case ky:
										if (ha = $.payload, typeof ha == "function") {
											if (of = !0, $ = ha.call(Hn, z, an), T.mode & 8) {
												Oe(!0);
												try {
													ha.call(Hn, z, an);
												} finally {
													Oe(!1);
												}
											}
											of = !1;
										} else $ = ha;
										if ($ == null) break e;
										z = Un({}, z, $);
										break e;
									case Py: hs = !0;
								}
							}
							T = p.callback, T !== null && (e.flags |= 64, H && (e.flags |= 8192), H = s.callbacks, H === null ? s.callbacks = [T] : H.push(T));
						} else H = {
							lane: T,
							tag: p.tag,
							payload: p.payload,
							callback: p.callback,
							next: null
						}, k === null ? (b = k = H, g = z) : k = k.next = H, f |= T;
						if (p = p.next, p === null) {
							if (p = s.shared.pending, p === null) break;
							H = p, p = H.next, H.next = null, s.lastBaseUpdate = H, s.shared.pending = null;
						}
					} while (!0);
					k === null && (g = z), s.baseState = g, s.firstBaseUpdate = b, s.lastBaseUpdate = k, u === null && (s.shared.lanes = 0), bs |= f, e.lanes = f, e.memoizedState = z;
				}
				mb = null;
			}
			function ci(e, n) {
				if (typeof e != "function") throw Error("Invalid argument passed as callback. Expected a function. Instead received: " + e);
				e.call(n);
			}
			function tp(e, n) {
				var o = e.shared.hiddenCallbacks;
				if (o !== null) for (e.shared.hiddenCallbacks = null, e = 0; e < o.length; e++) ci(o[e], n);
			}
			function rp(e, n) {
				var o = e.callbacks;
				if (o !== null) for (e.callbacks = null, e = 0; e < o.length; e++) ci(o[e], n);
			}
			function op(e, n) {
				var o = ei;
				ze(qg, o, e), ze(ms, n, e), ei = o | n.baseLanes;
			}
			function Dc(e) {
				ze(qg, ei, e), ze(ms, ms.current, e);
			}
			function Js(e) {
				ei = qg.current, mn(ms, e), mn(qg, e);
			}
			function vo(e) {
				var n = e.alternate;
				ze(kt, kt.current & pf, e), ze(St, e, e), Zt === null && (n === null || ms.current !== null || n.memoizedState !== null) && (Zt = e);
			}
			function jc(e) {
				ze(kt, kt.current, e), ze(St, e, e), Zt === null && (Zt = e);
			}
			function Uc(e) {
				e.tag === 22 ? (ze(kt, kt.current, e), ze(St, e, e), Zt === null && (Zt = e)) : Ar(e);
			}
			function Ar(e) {
				ze(kt, kt.current, e), ze(St, St.current, e);
			}
			function rt(e) {
				mn(St, e), Zt === e && (Zt = null), mn(kt, e);
			}
			function Zs(e, n) {
				ze(St, St.current, e), ze(kt, n, e);
			}
			function Wc(e) {
				mn(kt, e), mn(St, e), Zt === e && (Zt = null);
			}
			function Xs(e) {
				for (var n = e; n !== null;) {
					if (n.tag === 13) {
						var o = n.memoizedState;
						if (o !== null && (o = o.dehydrated, o === null || xn(o) || Ce(o))) return n;
					} else if (n.tag === 19 && n.memoizedProps.revealOrder !== "independent") {
						if ((n.flags & 128) !== 0) return n;
					} else if (n.child !== null) {
						n.child.return = n, n = n.child;
						continue;
					}
					if (n === e) break;
					for (; n.sibling === null;) {
						if (n.return === null || n.return === e) return null;
						n = n.return;
					}
					n.sibling.return = n.return, n = n.sibling;
				}
				return null;
			}
			function ee() {
				var e = _;
				Lo === null ? Lo = [e] : Lo.push(e);
			}
			function L() {
				var e = _;
				if (Lo !== null && (qi++, Lo[qi] !== e)) {
					var n = G(X);
					if (!Cy.has(n) && (Cy.add(n), Lo !== null)) {
						for (var o = "", i = 0; i <= qi; i++) {
							var s = Lo[i], u = i === qi ? e : s;
							for (s = i + 1 + ". " + s; 30 > s.length;) s += " ";
							s += u + `
`, o += s;
						}
						console.error(`React has detected a change in the order of Hooks called by %s. This will lead to bugs and errors if not fixed. For more information, read the Rules of Hooks: https://react.dev/link/rules-of-hooks

   Previous render            Next render
   ------------------------------------------------------
%s   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
`, n, o);
					}
				}
			}
			function Pa(e) {
				e == null || Gn(e) || console.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", _, typeof e);
			}
			function Ys() {
				var e = G(X);
				Ey.has(e) || (Ey.add(e), console.error("ReactDOM.useFormState has been renamed to React.useActionState. Please update %s to use React.useActionState.", e));
			}
			function Ee() {
				throw Error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`);
			}
			function Ks(e, n) {
				if (Qh) return !1;
				if (n === null) return console.error("%s received a final argument during this render, but not during the previous render. Even though the final argument is optional, its type cannot change between renders.", _), !1;
				e.length !== n.length && console.error(`The final argument passed to %s changed size between renders. The order and size of this array must remain constant.

Previous: %s
Incoming: %s`, _, "[" + n.join(", ") + "]", "[" + e.join(", ") + "]");
				for (var o = 0; o < n.length && o < e.length; o++) if (!Gt(e[o], n[o])) return !1;
				return !0;
			}
			function ap(e, n, o, i, s, u) {
				Qi = u, X = n, Lo = e !== null ? e._debugHookTypes : null, qi = -1, Qh = e !== null && e.type !== n.type, (Object.prototype.toString.call(o) === "[object AsyncFunction]" || Object.prototype.toString.call(o) === "[object AsyncGeneratorFunction]") && (u = G(X), bb.has(u) || (bb.add(u), console.error("%s is an async Client Component. Only Server Components can be async at the moment. This error is often caused by accidentally adding `'use client'` to a module that was originally written for the server.", u === null ? "An unknown Component" : "<" + u + ">"))), n.memoizedState = null, n.updateQueue = null, n.lanes = 0, N.H = e !== null && e.memoizedState !== null ? vb : Lo !== null ? _y : yb, oc = u = (n.mode & 8) !== Z;
				var f = sb(o, i, s);
				if (oc = !1, mf && (f = Ht(n, o, i, s)), u) {
					Oe(!0);
					try {
						f = Ht(n, o, i, s);
					} finally {
						Oe(!1);
					}
				}
				return ip(e, n), f;
			}
			function ip(e, n) {
				n._debugHookTypes = Lo, n.dependencies === null ? Ja !== null && (n.dependencies = {
					lanes: 0,
					firstContext: null,
					_debugThenableState: Ja
				}) : n.dependencies._debugThenableState = Ja;
				var o = Ja;
				if (nc !== null && gm(nc, n) && (o !== null || Qg === null || db || (db = !0, console.error(Qg)), Qg = nc = null), N.H = Zg, o = qe !== null && qe.next !== null, Qi = 0, Lo = _ = On = qe = X = null, qi = -1, e !== null && (e.flags & 1206910976) !== (n.flags & 1206910976) && console.error("Internal React error: Expected static flag was missing. Please notify the React team."), Gg = !1, $h = 0, Ja = null, o) throw Error("Rendered fewer hooks than expected. This may be caused by an accidental early return statement.");
				e === null || In || (e = e.dependencies, e !== null && dl(e) && (In = !0)), Oh ? (Oh = !1, e = !0) : e = !1, e && (n = G(n) || "Unknown", zy.has(n) || bb.has(n) || (zy.add(n), console.error("`use` was called from inside a try/catch block. This is not allowed and can lead to unexpected behavior. To handle errors triggered by `use`, wrap your component in a error boundary.")));
			}
			function Ht(e, n, o, i) {
				X = e;
				var s = 0;
				do {
					if (mf && (Ja = null), $h = 0, mf = !1, s >= W1) throw Error("Too many re-renders. React limits the number of renders to prevent an infinite loop.");
					if (s += 1, Qh = !1, On = qe = null, e.updateQueue != null) {
						var u = e.updateQueue;
						u.lastEffect = null, u.events = null, u.stores = null, u.memoCache != null && (u.memoCache.index = 0);
					}
					qi = -1, N.H = Ny, u = sb(n, o, i);
				} while (mf);
				return u;
			}
			function Ac() {
				var e = N.H, n = e.useState()[0];
				return n = typeof n.then == "function" ? Pl(n) : n, e = e.useState()[0], (qe !== null ? qe.memoizedState : null) !== e && (X.flags |= 1024), n;
			}
			function Oc() {
				var e = Jg !== 0;
				return Jg = 0, e;
			}
			function eu(e, n, o) {
				n.updateQueue = e.updateQueue, n.flags = (n.mode & 16) !== Z ? n.flags & -805308421 : n.flags & -2053, e.lanes &= ~o;
			}
			function Bc(e) {
				if (Gg) {
					for (e = e.memoizedState; e !== null;) {
						var n = e.queue;
						n !== null && (n.pending = null), e = e.next;
					}
					Gg = !1;
				}
				Qi = 0, Lo = On = qe = X = null, qi = -1, _ = null, mf = !1, $h = Jg = 0, Ja = null;
			}
			function ot() {
				var e = {
					memoizedState: null,
					baseState: null,
					baseQueue: null,
					queue: null,
					next: null
				};
				return On === null ? X.memoizedState = On = e : On = On.next = e, On;
			}
			function xe() {
				if (qe === null) {
					var e = X.alternate;
					e = e !== null ? e.memoizedState : null;
				} else e = qe.next;
				var n = On === null ? X.memoizedState : On.next;
				if (n !== null) On = n, qe = e;
				else {
					if (e === null) throw X.alternate === null ? Error("Update hook called on initial render. This is likely a bug in React. Please file an issue.") : Error("Rendered more hooks than during the previous render.");
					qe = e, e = {
						memoizedState: qe.memoizedState,
						baseState: qe.baseState,
						baseQueue: qe.baseQueue,
						queue: qe.queue,
						next: null
					}, On === null ? X.memoizedState = On = e : On = On.next = e;
				}
				return On;
			}
			function wl() {
				return {
					lastEffect: null,
					events: null,
					stores: null,
					memoCache: null
				};
			}
			function Pl(e) {
				var n = $h;
				return $h += 1, Ja === null && (Ja = Gf()), e = Zf(Ja, e, n, X), n = X, (On === null ? n.memoizedState : On.next) === null && (n = n.alternate, N.H = n !== null && n.memoizedState !== null ? vb : yb), e;
			}
			function Or(e) {
				if (e !== null && typeof e == "object") {
					if (typeof e.then == "function") return Pl(e);
					if (e.$$typeof === Tt) return;
					if (e.$$typeof === sn) return K(e);
				}
				throw Error("An unsupported type was passed to use(): " + String(e));
			}
			function Br(e) {
				var n = null, o = X.updateQueue;
				if (o !== null && (n = o.memoCache), n == null) {
					var i = X.alternate;
					i !== null && (i = i.updateQueue, i !== null && (i = i.memoCache, i != null && (n = {
						data: i.data.map(function(s) {
							return s.slice();
						}),
						index: 0
					})));
				}
				if (n ??= {
					data: [],
					index: 0
				}, o === null && (o = wl(), X.updateQueue = o), o.memoCache = n, o = n.data[n.index], o === void 0 || Qh) for (o = n.data[n.index] = Array(e), i = 0; i < e; i++) o[i] = j0;
				else o.length !== e && console.error("Expected a constant size argument for each invocation of useMemoCache. The previous cache was allocated with size %s but size %s was requested.", o.length, e);
				return n.index++, o;
			}
			function ge(e, n) {
				return typeof n == "function" ? n(e) : n;
			}
			function lp(e, n, o) {
				var i = ot();
				if (o !== void 0) {
					var s = o(n);
					if (oc) {
						Oe(!0);
						try {
							o(n);
						} finally {
							Oe(!1);
						}
					}
				} else s = n;
				return i.memoizedState = i.baseState = s, e = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: e,
					lastRenderedState: s
				}, i.queue = e, e = e.dispatch = Mr.bind(null, X, e), [i.memoizedState, e];
			}
			function xl(e) {
				return Hc(xe(), qe, e);
			}
			function Hc(e, n, o) {
				var i = e.queue;
				if (i === null) throw Error("Should have a queue. You are likely calling Hooks conditionally, which is not allowed. (https://react.dev/link/invalid-hook-call)");
				i.lastRenderedReducer = o;
				var s = e.baseQueue, u = i.pending;
				if (u !== null) {
					if (s !== null) {
						var f = s.next;
						s.next = u.next, u.next = f;
					}
					n.baseQueue !== s && console.error("Internal error: Expected work-in-progress queue to be a clone. This is a bug in React."), n.baseQueue = s = u, i.pending = null;
				}
				if (u = e.baseState, s === null) e.memoizedState = u;
				else {
					n = s.next;
					var p = f = null, g = null, b = n, k = !1;
					do {
						var z = b.lane & -536870913;
						if (z !== b.lane ? (te & z) === z : (Qi & z) === z) {
							var T = b.revertLane;
							if (T === 0) g !== null && (g = g.next = {
								lane: 0,
								revertLane: 0,
								gesture: null,
								action: b.action,
								hasEagerState: b.hasEagerState,
								eagerState: b.eagerState,
								next: null
							}), z === ps && (k = !0);
							else if ((Qi & T) === T) {
								b = b.next, T === ps && (k = !0);
								continue;
							} else z = {
								lane: 0,
								revertLane: b.revertLane,
								gesture: null,
								action: b.action,
								hasEagerState: b.hasEagerState,
								eagerState: b.eagerState,
								next: null
							}, g === null ? (p = g = z, f = u) : g = g.next = z, X.lanes |= T, bs |= T;
							z = b.action, oc && o(u, z), u = b.hasEagerState ? b.eagerState : o(u, z);
						} else T = {
							lane: z,
							revertLane: b.revertLane,
							gesture: b.gesture,
							action: b.action,
							hasEagerState: b.hasEagerState,
							eagerState: b.eagerState,
							next: null
						}, g === null ? (p = g = T, f = u) : g = g.next = T, X.lanes |= z, bs |= z;
						b = b.next;
					} while (b !== null && b !== n);
					if (g === null ? f = u : g.next = p, !Gt(u, e.memoizedState) && (In = !0, k && (o = uf, o !== null))) throw o;
					e.memoizedState = u, e.baseState = f, e.baseQueue = g, i.lastRenderedState = u;
				}
				return s === null && (i.lanes = 0), [e.memoizedState, i.dispatch];
			}
			function $o(e) {
				var n = xe(), o = n.queue;
				if (o === null) throw Error("Should have a queue. You are likely calling Hooks conditionally, which is not allowed. (https://react.dev/link/invalid-hook-call)");
				o.lastRenderedReducer = e;
				var i = o.dispatch, s = o.pending, u = n.memoizedState;
				if (s !== null) {
					o.pending = null;
					var f = s = s.next;
					do
						u = e(u, f.action), f = f.next;
					while (f !== s);
					Gt(u, n.memoizedState) || (In = !0), n.memoizedState = u, n.baseQueue === null && (n.baseState = u), o.lastRenderedState = u;
				}
				return [u, i];
			}
			function So(e, n, o) {
				var i = X, s = ot();
				if (le) {
					if (o === void 0) throw Error("Missing getServerSnapshot, which is required for server-rendered content. Will revert to client rendering.");
					var u = o();
					hf || u === o() || (console.error("The result of getServerSnapshot should be cached to avoid an infinite loop"), hf = !0);
				} else {
					if (u = n(), hf || (o = n(), Gt(u, o) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), hf = !0)), Ge === null) throw Error("Expected a work-in-progress root. This is a bug in React. Please file an issue.");
					te & 127 || sp(i, n, u);
				}
				return s.memoizedState = u, o = {
					value: u,
					getSnapshot: n
				}, s.queue = o, lu(Fn.bind(null, i, o, e), [e]), i.flags |= 2048, Qo(Ro | Dt, { destroy: void 0 }, Hr.bind(null, i, o, u, n), null), u;
			}
			function nu(e, n, o) {
				var i = X, s = xe(), u = le;
				if (u) {
					if (o === void 0) throw Error("Missing getServerSnapshot, which is required for server-rendered content. Will revert to client rendering.");
					o = o();
				} else if (o = n(), !hf) {
					var f = n();
					Gt(o, f) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), hf = !0);
				}
				(f = !Gt((qe || s).memoizedState, o)) && (s.memoizedState = o, In = !0), s = s.queue;
				if (at(2048, Dt, Fn.bind(null, i, s, e), [e]), e = s.getSnapshot !== n || f || On !== null && (On.memoizedState.tag & Ro) !== Vh, Qo(e ? Ro | Dt : Dt, { destroy: void 0 }, Hr.bind(null, i, s, o, n), null), e) {
					if (i.flags |= 2048, Ge === null) throw Error("Expected a work-in-progress root. This is a bug in React. Please file an issue.");
					u || Qi & 127 || sp(i, n, o);
				}
				return o;
			}
			function sp(e, n, o) {
				e.flags |= 16384, e = {
					getSnapshot: n,
					value: o
				}, n = X.updateQueue, n === null ? (n = wl(), X.updateQueue = n, n.stores = [e]) : (o = n.stores, o === null ? n.stores = [e] : o.push(e));
			}
			function Hr(e, n, o, i) {
				n.value = o, n.getSnapshot = i, up(n) && Cl(e);
			}
			function Fn(e, n, o) {
				return o(function() {
					up(n) && (tr(2, "updateSyncExternalStore()", e), Cl(e));
				});
			}
			function up(e) {
				var n = e.getSnapshot;
				e = e.value;
				try {
					var o = n();
					return !Gt(e, o);
				} catch {
					return !0;
				}
			}
			function Cl(e) {
				var n = tt(e, 2);
				n !== null && nn(n, e, 2);
			}
			function Mc(e) {
				var n = ot();
				if (typeof e == "function") {
					var o = e;
					if (e = o(), oc) {
						Oe(!0);
						try {
							o();
						} finally {
							Oe(!1);
						}
					}
				}
				return n.memoizedState = n.baseState = e, n.queue = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: ge,
					lastRenderedState: e
				}, n;
			}
			function di(e) {
				e = Mc(e);
				var n = e.queue, o = rd.bind(null, X, n);
				return n.dispatch = o, [e.memoizedState, o];
			}
			function tu(e) {
				var n = ot();
				n.memoizedState = n.baseState = e;
				var o = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: null,
					lastRenderedState: null
				};
				return n.queue = o, n = Ct.bind(null, X, !0, o), o.dispatch = n, [e, n];
			}
			function Vc(e, n) {
				return $c(xe(), qe, e, n);
			}
			function $c(e, n, o, i) {
				return e.baseState = o, Hc(e, qe, typeof i == "function" ? i : ge);
			}
			function Qc(e, n) {
				var o = xe();
				return qe !== null ? $c(o, qe, e, n) : (o.baseState = e, [e, o.queue.dispatch]);
			}
			function bm(e, n, o, i, s) {
				if (du(e)) throw Error("Cannot update action state while rendering.");
				if (e = n.action, e !== null) {
					var u = {
						payload: s,
						action: e,
						next: null,
						isTransition: !0,
						status: "pending",
						value: null,
						reason: null,
						listeners: [],
						then: function(f) {
							u.listeners.push(f);
						}
					};
					N.T !== null ? o(!0) : u.isTransition = !1, i(u), o = n.pending, o === null ? (u.next = n.pending = u, qc(n, u)) : (u.next = o.next, n.pending = o.next = u);
				}
			}
			function qc(e, n) {
				var o = n.action, i = n.payload, s = e.state;
				if (n.isTransition) {
					var u = N.T, f = {};
					f.types = u !== null ? u.types : null, f._updatedFibers = /* @__PURE__ */ new Set(), N.T = f;
					try {
						var p = o(s, i), g = N.S;
						g !== null && g(f, p), Gc(e, n, p);
					} catch (b) {
						ou(e, n, b);
					} finally {
						u !== null && f.types !== null && (u.types !== null && u.types !== f.types && console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."), u.types = f.types), N.T = u, u === null && f._updatedFibers && (e = f._updatedFibers.size, f._updatedFibers.clear(), 10 < e && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."));
					}
				} else try {
					f = o(s, i), Gc(e, n, f);
				} catch (b) {
					ou(e, n, b);
				}
			}
			function Gc(e, n, o) {
				o !== null && typeof o == "object" && typeof o.then == "function" ? (N.asyncTransitions++, o.then(ed, ed), o.then(function(i) {
					ru(e, n, i);
				}, function(i) {
					return ou(e, n, i);
				}), n.isTransition || console.error("An async function with useActionState was called outside of a transition. This is likely not what you intended (for example, isPending will not update correctly). Either call the returned function inside startTransition, or pass it to an `action` or `formAction` prop.")) : ru(e, n, o);
			}
			function ru(e, n, o) {
				n.status = "fulfilled", n.value = o, cp(n), e.state = o, n = e.pending, n !== null && (o = n.next, o === n ? e.pending = null : (o = o.next, n.next = o, qc(e, o)));
			}
			function ou(e, n, o) {
				var i = e.pending;
				if (e.pending = null, i !== null) {
					i = i.next;
					do
						n.status = "rejected", n.reason = o, cp(n), n = n.next;
					while (n !== i);
				}
				e.action = null;
			}
			function cp(e) {
				e = e.listeners;
				for (var n = 0; n < e.length; n++) (0, e[n])();
			}
			function dp(e, n) {
				return n;
			}
			function fi(e, n) {
				if (le) {
					var o = Ge.formState;
					if (o !== null) {
						e: {
							var i = X;
							if (le) {
								if (rn) {
									var s = Ng(rn, No);
									if (s) {
										rn = gr(s), i = An(s);
										break e;
									}
								}
								Nr(i);
							}
							i = !1;
						}
						i && (n = o[0]);
					}
				}
				o = ot(), o.memoizedState = o.baseState = n, i = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: dp,
					lastRenderedState: n
				}, o.queue = i, o = rd.bind(null, X, i), i.dispatch = o, i = Mc(!1);
				var u = Ct.bind(null, X, !1, i.queue);
				return i = ot(), s = {
					state: n,
					dispatch: null,
					action: e,
					pending: null
				}, i.queue = s, o = bm.bind(null, X, s, u, o), s.dispatch = o, i.memoizedState = e, [
					n,
					o,
					!1
				];
			}
			function au(e) {
				return pi(xe(), qe, e);
			}
			function pi(e, n, o) {
				if (n = Hc(e, n, dp)[0], e = xl(ge)[0], typeof n == "object" && n !== null && typeof n.then == "function") try {
					var i = Pl(n);
				} catch (f) {
					throw f === cf ? Vg : f;
				}
				else i = n;
				n = xe();
				var s = n.queue, u = s.dispatch;
				return o !== n.memoizedState && (X.flags |= 2048, Qo(Ro | Dt, { destroy: void 0 }, ym.bind(null, s, o), null)), [
					i,
					u,
					e
				];
			}
			function ym(e, n) {
				e.action = n;
			}
			function Mt(e) {
				var n = xe(), o = qe;
				if (o !== null) return pi(n, o, e);
				xe(), n = n.memoizedState, o = xe();
				var i = o.queue.dispatch;
				return o.memoizedState = e, [
					n,
					i,
					!1
				];
			}
			function Qo(e, n, o, i) {
				return e = {
					tag: e,
					create: o,
					deps: i,
					inst: n,
					next: null
				}, n = X.updateQueue, n === null && (n = wl(), X.updateQueue = n), o = n.lastEffect, o === null ? n.lastEffect = e.next = e : (i = o.next, o.next = e, e.next = i, n.lastEffect = e), e;
			}
			function iu(e) {
				var n = ot();
				return e = { current: e }, n.memoizedState = e;
			}
			function qo(e, n, o, i) {
				var s = ot();
				X.flags |= e, s.memoizedState = Qo(Ro | n, { destroy: void 0 }, o, i === void 0 ? null : i);
			}
			function at(e, n, o, i) {
				var s = xe();
				i = i === void 0 ? null : i;
				var u = s.memoizedState.inst;
				qe !== null && i !== null && Ks(i, qe.memoizedState.deps) ? s.memoizedState = Qo(n, u, o, i) : (X.flags |= e, s.memoizedState = Qo(Ro | n, u, o, i));
			}
			function lu(e, n) {
				(X.mode & 16) !== Z ? qo(545261568, Dt, e, n) : qo(8390656, Dt, e, n);
			}
			function fp(e) {
				X.flags |= 4;
				var n = X.updateQueue;
				if (n === null) n = wl(), X.updateQueue = n, n.events = [e];
				else {
					var o = n.events;
					o === null ? n.events = [e] : o.push(e);
				}
			}
			function zl(e) {
				var n = ot(), o = { impl: e };
				return n.memoizedState = o, function() {
					if ((ve & pt) !== ft) throw Error("A function wrapped in useEffectEvent can't be called during rendering.");
					return o.impl.apply(void 0, arguments);
				};
			}
			function su(e) {
				var n = xe().memoizedState;
				return fp({
					ref: n,
					nextImpl: e
				}), function() {
					if ((ve & pt) !== ft) throw Error("A function wrapped in useEffectEvent can't be called during rendering.");
					return n.impl.apply(void 0, arguments);
				};
			}
			function uu(e, n) {
				var o = 4194308;
				return (X.mode & 16) !== Z && (o |= 268435456), qo(o, eo, e, n);
			}
			function pp(e, n) {
				if (typeof n == "function") {
					e = e();
					var o = n(e);
					return function() {
						typeof o == "function" ? o() : n(null);
					};
				}
				if (n != null) return n.hasOwnProperty("current") || console.error("Expected useImperativeHandle() first argument to either be a ref callback or React.createRef() object. Instead received: %s.", "an object with keys {" + Object.keys(n).join(", ") + "}"), e = e(), n.current = e, function() {
					n.current = null;
				};
			}
			function hp(e, n, o) {
				typeof n != "function" && console.error("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", n !== null ? typeof n : "null"), o = o != null ? o.concat([e]) : null;
				var i = 4194308;
				(X.mode & 16) !== Z && (i |= 268435456), qo(i, eo, pp.bind(null, n, e), o);
			}
			function hi(e, n, o) {
				typeof n != "function" && console.error("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", n !== null ? typeof n : "null"), o = o != null ? o.concat([e]) : null, at(4, eo, pp.bind(null, n, e), o);
			}
			function Jc(e, n) {
				return ot().memoizedState = [e, n === void 0 ? null : n], e;
			}
			function El(e, n) {
				var o = xe();
				n = n === void 0 ? null : n;
				var i = o.memoizedState;
				return n !== null && Ks(n, i[1]) ? i[0] : (o.memoizedState = [e, n], e);
			}
			function Zc(e, n) {
				var o = ot();
				n = n === void 0 ? null : n;
				var i = e();
				if (oc) {
					Oe(!0);
					try {
						e();
					} finally {
						Oe(!1);
					}
				}
				return o.memoizedState = [i, n], i;
			}
			function _l(e, n) {
				var o = xe();
				n = n === void 0 ? null : n;
				var i = o.memoizedState;
				if (n !== null && Ks(n, i[1])) return i[0];
				if (i = e(), oc) {
					Oe(!0);
					try {
						e();
					} finally {
						Oe(!1);
					}
				}
				return o.memoizedState = [i, n], i;
			}
			function Xc(e, n) {
				return Kc(ot(), e, n);
			}
			function xt(e, n) {
				return mp(xe(), qe.memoizedState, e, n);
			}
			function Yc(e, n) {
				var o = xe();
				return qe === null ? Kc(o, e, n) : mp(o, qe.memoizedState, e, n);
			}
			function Kc(e, n, o) {
				return o === void 0 || (Qi & 1073741824) !== 0 && (te & 261930) === 0 ? e.memoizedState = n : (e.memoizedState = o, e = Jm(), X.lanes |= e, bs |= e, o);
			}
			function mp(e, n, o, i) {
				return Gt(o, n) ? o : ms.current !== null ? (e = Kc(e, o, i), Gt(e, n) || (In = !0), e) : (Qi & 106) === 0 || (Qi & 1073741824) !== 0 && (te & 261930) === 0 ? (In = !0, e.memoizedState = o) : (e = Jm(), X.lanes |= e, bs |= e, n);
			}
			function ed() {
				N.asyncTransitions--;
			}
			function cu(e, n, o, i, s) {
				var u = fr();
				Je(u !== 0 && 8 > u ? u : 8);
				var f = N.T, p = {};
				p.types = f !== null ? f.types : null, p._updatedFibers = /* @__PURE__ */ new Set(), N.T = p, Ct(e, !1, n, o);
				try {
					var g = s(), b = N.S;
					if (b !== null && b(p, g), g !== null && typeof g == "object" && typeof g.then == "function") {
						N.asyncTransitions++, g.then(ed, ed);
						var k = mm(g, i);
						mi(e, n, k, _t(e));
					} else mi(e, n, i, _t(e));
				} catch (z) {
					mi(e, n, {
						then: function() {},
						status: "rejected",
						reason: z
					}, _t(e));
				} finally {
					Je(u), f !== null && p.types !== null && (f.types !== null && f.types !== p.types && console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."), f.types = p.types), N.T = f, f === null && p._updatedFibers && (e = p._updatedFibers.size, p._updatedFibers.clear(), 10 < e && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."));
				}
			}
			function Dn(e) {
				var n = e.memoizedState;
				if (n !== null) return n;
				n = {
					memoizedState: Gr,
					baseState: Gr,
					baseQueue: null,
					queue: {
						pending: null,
						lanes: 0,
						dispatch: null,
						lastRenderedReducer: ge,
						lastRenderedState: Gr
					},
					next: null
				};
				var o = {};
				return n.next = {
					memoizedState: o,
					baseState: o,
					baseQueue: null,
					queue: {
						pending: null,
						lanes: 0,
						dispatch: null,
						lastRenderedReducer: ge,
						lastRenderedState: o
					},
					next: null
				}, e.memoizedState = n, e = e.alternate, e !== null && (e.memoizedState = n), n;
			}
			function nd() {
				var e = Mc(!1);
				return e = cu.bind(null, X, e.queue, !0, !1), ot().memoizedState = e, [!1, e];
			}
			function Vn() {
				var e = xl(ge)[0], n = xe().memoizedState;
				return [typeof e == "boolean" ? e : Pl(e), n];
			}
			function gp() {
				var e = $o(ge)[0], n = xe().memoizedState;
				return [typeof e == "boolean" ? e : Pl(e), n];
			}
			function or() {
				return K(Jr);
			}
			function td() {
				var e = ot(), n = Ge.identifierPrefix;
				if (le) {
					var o = Oi, i = Ai;
					o = (i & ~(1 << 32 - d(i) - 1)).toString(32) + o, n = "_" + n + "R_" + o, o = Jg++, 0 < o && (n += "H" + o.toString(32)), n += "_";
				} else o = U1++, n = "_" + n + "r_" + o.toString(32) + "_";
				return e.memoizedState = n;
			}
			function ar() {
				return ot().memoizedState = xa.bind(null, X);
			}
			function xa(e, n) {
				for (var o = e.return; o !== null;) {
					switch (o.tag) {
						case 24:
						case 3:
							var i = _t(o), s = Vo(i), u = rr(o, s, i);
							u !== null && (tr(i, "refresh()", e), nn(u, o, i), Sl(u, o, i)), e = pl(), n != null && u !== null && console.error("The seed argument is not enabled outside experimental channels."), s.payload = { cache: e };
							return;
					}
					o = o.return;
				}
			}
			function Mr(e, n, o) {
				var i = arguments;
				typeof i[3] == "function" && console.error("State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect()."), i = _t(e);
				var s = {
					lane: i,
					revertLane: 0,
					gesture: null,
					action: o,
					hasEagerState: !1,
					eagerState: null,
					next: null
				};
				du(e) ? gi(n, s) : (s = Rc(e, n, s, i), s !== null && (tr(i, "dispatch()", e), nn(s, e, i), Nl(s, n, i)));
			}
			function rd(e, n, o) {
				var i = arguments;
				typeof i[3] == "function" && console.error("State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect()."), i = _t(e), mi(e, n, o, i) && tr(i, "setState()", e);
			}
			function mi(e, n, o, i) {
				var s = {
					lane: i,
					revertLane: 0,
					gesture: null,
					action: o,
					hasEagerState: !1,
					eagerState: null,
					next: null
				};
				if (du(e)) gi(n, s);
				else {
					var u = e.alternate;
					if (e.lanes === 0 && (u === null || u.lanes === 0) && (u = n.lastRenderedReducer, u !== null)) {
						var f = N.H;
						N.H = da;
						try {
							var p = n.lastRenderedState, g = u(p, o);
							if (s.hasEagerState = !0, s.eagerState = g, Gt(g, p)) return Qs(e, n, s, 0), Ge === null && vl(), !1;
						} catch {} finally {
							N.H = f;
						}
					}
					if (o = Rc(e, n, s, i), o !== null) return nn(o, e, i), Nl(o, n, i), !0;
				}
				return !1;
			}
			function Ct(e, n, o, i) {
				if (N.T === null && ps === 0 && console.error("An optimistic state update occurred outside a transition or action. To fix, move the update to an action, or wrap with startTransition."), i = {
					lane: 2,
					revertLane: Nc(),
					gesture: null,
					action: i,
					hasEagerState: !1,
					eagerState: null,
					next: null
				}, du(e)) {
					if (n) throw Error("Cannot update optimistic state while rendering.");
					console.error("Cannot call startTransition while rendering.");
				} else n = Rc(e, o, i, 2), n !== null && (tr(2, "setOptimistic()", e), nn(n, e, 2));
			}
			function du(e) {
				var n = e.alternate;
				return e === X || n !== null && n === X;
			}
			function gi(e, n) {
				mf = Gg = !0;
				var o = e.pending;
				o === null ? n.next = n : (n.next = o.next, o.next = n), e.pending = n;
			}
			function Nl(e, n, o) {
				if ((o & 4194048) !== 0) {
					var i = n.lanes;
					i &= e.pendingLanes, o |= i, n.lanes = o, If(e, o);
				}
			}
			function ko(e) {
				if (e !== null && typeof e != "function") {
					var n = String(e);
					Oy.has(n) || (Oy.add(n), console.error("Expected the last optional `callback` argument to be a function. Instead received: %s.", e));
				}
			}
			function od(e, n, o, i) {
				var s = e.memoizedState, u = o(i, s);
				if (e.mode & 8) {
					Oe(!0);
					try {
						u = o(i, s);
					} finally {
						Oe(!1);
					}
				}
				u === void 0 && (n = en(n) || "Component", jy.has(n) || (jy.add(n), console.error("%s.getDerivedStateFromProps(): A valid state object (or null) must be returned. You have returned undefined.", n))), s = u == null ? s : Un({}, s, u), e.memoizedState = s, e.lanes === 0 && (e.updateQueue.baseState = s);
			}
			function bp(e, n, o, i, s, u, f) {
				var p = e.stateNode;
				if (typeof p.shouldComponentUpdate == "function") {
					if (o = p.shouldComponentUpdate(i, u, f), e.mode & 8) {
						Oe(!0);
						try {
							o = p.shouldComponentUpdate(i, u, f);
						} finally {
							Oe(!1);
						}
					}
					return o === void 0 && console.error("%s.shouldComponentUpdate(): Returned undefined instead of a boolean value. Make sure to return true or false.", en(n) || "Component"), o;
				}
				return n.prototype && n.prototype.isPureReactComponent ? !bl(o, i) || !bl(s, u) : !0;
			}
			function Tl(e, n, o, i) {
				var s = n.state;
				typeof n.componentWillReceiveProps == "function" && n.componentWillReceiveProps(o, i), typeof n.UNSAFE_componentWillReceiveProps == "function" && n.UNSAFE_componentWillReceiveProps(o, i), n.state !== s && (e = G(e) || "Component", Iy.has(e) || (Iy.add(e), console.error("%s.componentWillReceiveProps(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.", e)), Sb.enqueueReplaceState(n, n.state, null));
			}
			function Ca(e, n) {
				var o = n;
				if ("ref" in n) {
					o = {};
					for (var i in n) i !== "ref" && (o[i] = n[i]);
				}
				if (e = e.defaultProps) {
					o === n && (o = Un({}, o));
					for (var s in e) o[s] === void 0 && (o[s] = e[s]);
				}
				return o;
			}
			function bi(e, n) {
				try {
					gf = n.source ? G(n.source) : null, kb = null;
					var o = n.value;
					if (N.actQueue !== null) N.thrownErrors.push(o);
					else {
						var i = e.onUncaughtError;
						i(o, { componentStack: n.stack });
					}
				} catch (s) {
					setTimeout(function() {
						throw s;
					});
				}
			}
			function yp(e, n, o) {
				try {
					gf = o.source ? G(o.source) : null, kb = G(n);
					var i = e.onCaughtError;
					i(o.value, {
						componentStack: o.stack,
						errorBoundary: n.tag === 1 ? n.stateNode : null
					});
				} catch (s) {
					setTimeout(function() {
						throw s;
					});
				}
			}
			function fu(e, n, o) {
				return o = Vo(o), o.tag = hb, o.payload = { element: null }, o.callback = function() {
					B(n.source, bi, e, n);
				}, o;
			}
			function pu(e) {
				return e = Vo(e), e.tag = hb, e;
			}
			function hu(e, n, o, i) {
				var s = o.type.getDerivedStateFromError;
				if (typeof s == "function") {
					var u = i.value;
					e.payload = function() {
						return s(u);
					}, e.callback = function() {
						mg(o), B(i.source, yp, n, o, i);
					};
				}
				var f = o.stateNode;
				f !== null && typeof f.componentDidCatch == "function" && (e.callback = function() {
					mg(o), B(i.source, yp, n, o, i), typeof s != "function" && (vs === null ? vs = /* @__PURE__ */ new Set([this]) : vs.add(this)), L1(this, i), typeof s == "function" || !(o.lanes & 2) && console.error("%s: Error boundaries should implement getDerivedStateFromError(). In that method, return a state update to display an error message or fallback UI.", G(o) || "Unknown");
				});
			}
			function vm(e, n, o, i, s) {
				if (o.flags |= 32768, Le && Ru(e, s), i !== null && typeof i == "object" && typeof i.then == "function") {
					if (n = o.alternate, n !== null && Ho(n, o, s, !0), le && (qa = !0), o = St.current, o !== null) {
						switch (o.tag) {
							case 31:
							case 13:
							case 19: return Zt === null ? Iu() : o.alternate === null && fn === Gi && (fn = s0), o.flags &= -257, o.flags |= 65536, o.lanes = s, i === $g ? o.flags |= 16384 : (n = o.updateQueue, n === null ? o.updateQueue = /* @__PURE__ */ new Set([i]) : n.add(i), Kp(e, i, s)), !1;
							case 22: return o.flags |= 65536, i === $g ? o.flags |= 16384 : (n = o.updateQueue, n === null ? (n = {
								transitions: null,
								markerInstances: null,
								retryQueue: /* @__PURE__ */ new Set([i])
							}, o.updateQueue = n) : (o = n.retryQueue, o === null ? n.retryQueue = /* @__PURE__ */ new Set([i]) : o.add(i)), Kp(e, i, s)), !1;
						}
						throw Error("Unexpected Suspense handler tag (" + o.tag + "). This is a bug in React.");
					}
					return Kp(e, i, s), Iu(), !1;
				}
				if (le) return qa = !0, n = St.current, n !== null ? (n.tag === 19 && console.error("SuspenseList should never catch while hydrating. This is a bug in React."), !(n.flags & 65536) && (n.flags |= 256), n.flags |= 65536, n.lanes = s, i !== J0 && Ve(Ot(Error("There was an error while hydrating but React was able to recover by instead client rendering from the nearest Suspense boundary.", { cause: i }), o))) : (i !== J0 && Ve(Ot(Error("There was an error while hydrating but React was able to recover by instead client rendering the entire root.", { cause: i }), o)), e = e.current.alternate, e.flags |= 65536, s &= -s, e.lanes |= s, i = Ot(i, o), s = fu(e.stateNode, i, s), ui(e, s), fn !== gs && (fn = lc)), !1;
				var u = Ot(Error("There was an error during concurrent rendering but React was able to recover by instead synchronously rendering the entire root.", { cause: i }), o);
				if (Kh === null ? Kh = [u] : Kh.push(u), fn !== gs && (fn = lc), n === null) return !0;
				i = Ot(i, o), o = n;
				do {
					switch (o.tag) {
						case 3: return o.flags |= 65536, e = s & -s, o.lanes |= e, e = fu(o.stateNode, i, e), ui(o, e), !1;
						case 1:
							if (n = o.type, u = o.stateNode, (o.flags & 128) === 0 && (typeof n.getDerivedStateFromError == "function" || u !== null && typeof u.componentDidCatch == "function" && (vs === null || !vs.has(u)))) return o.flags |= 65536, s &= -s, o.lanes |= s, s = pu(s), hu(s, e, o, i), ui(o, s), !1;
							break;
						case 22: if (o.memoizedState !== null) return o.flags |= 65536, !1;
					}
					o = o.return;
				} while (o !== null);
				return !1;
			}
			function bn(e, n, o, i) {
				n.child = e === null ? Sy(n, null, o, i) : rc(n, e.child, o, i);
			}
			function zt(e, n, o, i, s) {
				o = o.render;
				var u = Bl(o);
				if (u !== o && (o = u, e !== null && (In = !0)), u = n.ref, "ref" in i) {
					var f = {};
					for (var p in i) p !== "ref" && (f[p] = i[p]);
				} else f = i;
				return gn(n), i = ap(e, n, o, f, u, s), p = Oc(), e !== null && !In ? (eu(e, n, s), Jo(e, n, s)) : (le && p && rl(n), n.flags |= 1, bn(e, n, i, s), n.child);
			}
			function vp(e, n, o, i, s) {
				if (e === null) {
					var u = o.type;
					return typeof u == "function" && !nh(u) && u.defaultProps === void 0 && o.compare === null ? (o = Bl(u), n.tag = 15, n.type = o, id(n, u), yi(e, n, o, i, s)) : (e = Td(o.type, null, i, n, n.mode, s), e.ref = n.ref, e.return = n, n.child = e);
				}
				if (u = e.child, !vu(e, s)) {
					var f = u.memoizedProps;
					if (o = o.compare, o = o !== null ? o : bl, o(f, i) && e.ref === n.ref) return Jo(e, n, s);
				}
				return n.flags |= 1, e = Ko(u, i), e.ref = n.ref, e.return = n, n.child = e;
			}
			function yi(e, n, o, i, s) {
				if (e !== null) {
					var u = e.memoizedProps;
					if (bl(u, i) && e.ref === n.ref && n.type === e.type) if (In = !1, n.pendingProps = i = u, vu(e, s)) e.flags & 131072 && (In = !0);
					else return n.lanes = e.lanes, Jo(e, n, s);
				}
				return Ea(e, n, o, i, s);
			}
			function yt(e, n, o, i) {
				var s = i.children, u = e !== null ? e.memoizedState : null;
				if (e === null && n.stateNode === null && (n.stateNode = {
					_visibility: Hh,
					_pendingMarkers: null,
					_retryCache: null,
					_transitions: null
				}), i.mode === "hidden") {
					if ((n.flags & 128) !== 0) {
						if (u = u !== null ? u.baseLanes | o : o, e !== null) {
							for (i = n.child = e.child, s = 0; i !== null;) s = s | i.lanes | i.childLanes, i = i.sibling;
							i = s & ~u;
						} else i = 0, n.child = null;
						return Sp(e, n, u, o, i);
					}
					if ((o & 536870912) !== 0) n.memoizedState = {
						baseLanes: 0,
						cachePool: null
					}, e !== null && Hs(n, u !== null ? u.cachePool : null), u !== null ? op(n, u) : Dc(n), Uc(n);
					else return i = n.lanes = 536870912, Sp(e, n, u !== null ? u.baseLanes | o : o, o, i);
				} else u !== null ? (Hs(n, u.cachePool), op(n, u), Ar(n), n.memoizedState = null) : (e !== null && Hs(n, null), Dc(n), Ar(n));
				return bn(e, n, s, o), n.child;
			}
			function Il(e, n) {
				return e !== null && e.tag === 22 || n.stateNode !== null || (n.stateNode = {
					_visibility: Hh,
					_pendingMarkers: null,
					_retryCache: null,
					_transitions: null
				}), n.sibling;
			}
			function Sp(e, n, o, i, s) {
				var u = Bs();
				return u = u === null ? null : {
					parent: yn ? vn._currentValue : vn._currentValue2,
					pool: u
				}, n.memoizedState = {
					baseLanes: o,
					cachePool: u
				}, e !== null && Hs(n, null), Dc(n), Uc(n), e !== null && Ho(e, n, i, !0), n.childLanes = s, null;
			}
			function ad(e, n) {
				var o = n.hidden;
				return o !== void 0 && console.error(`<Activity> doesn't accept a hidden prop. Use mode="hidden" instead.
- <Activity %s>
+ <Activity %s>`, o === !0 ? "hidden" : o === !1 ? "hidden={false}" : "hidden={...}", o ? "mode=\"hidden\"" : "mode=\"visible\""), n = ld({
					mode: n.mode,
					children: n.children
				}, e.mode), n.ref = e.ref, e.child = n, n.return = e, n;
			}
			function Go(e, n, o) {
				return rc(n, e.child, null, o), e = ad(n, n.pendingProps), e.flags |= 2, rt(n), n.memoizedState = null, e;
			}
			function Sm(e, n, o) {
				var i = n.pendingProps, s = (n.flags & 128) !== 0;
				if (n.flags &= -129, e === null) {
					if (le) {
						if (i.mode === "hidden") return e = ad(n, i), n.lanes = 536870912, e.memoizedState = {
							baseLanes: 0,
							cachePool: null
						}, Il(null, e);
						if (jc(n), (e = rn) ? (o = qd(e, No), o !== null && (i = {
							dehydrated: o,
							treeContext: Uf(),
							retryLane: 536870912,
							hydrationErrors: null
						}, n.memoizedState = i, i = th(o), i.return = n, n.child = i, st = n, rn = null)) : o = null, o === null) throw _r(n, e), Nr(n);
						return n.lanes = 536870912, null;
					}
					return ad(n, i);
				}
				var u = e.memoizedState;
				if (u !== null) {
					var f = u.dehydrated;
					if (jc(n), s) {
						if (n.flags & 256) n.flags &= -257, n = Go(e, n, o);
						else if (n.memoizedState !== null) n.child = e.child, n.flags |= 128, n = null;
						else throw Error("Client rendering an Activity suspended it again. This is a bug in React.");
					} else if (xc(), o & 536870912 && zd(n), In || Ho(e, n, o, !1), s = (o & e.childLanes) !== 0, In || s) {
						if (ms.current === null) {
							if (i = Ge, i !== null && (f = Ps(i, o), f !== 0 && f !== u.retryLane)) throw u.retryLane = f, tt(e, f), nn(i, e, f), wb;
							Iu();
						}
						n = Go(e, n, o);
					} else e = u.treeContext, $e && (rn = Cn(f), st = n, le = !0, ss = null, qa = !1, Kr = null, No = !1, e !== null && Ts(n, e)), n = ad(n, i), n.flags |= 134221824;
					return n;
				}
				return u = e.child, i = {
					mode: i.mode,
					children: i.children
				}, o & 536870912 && (o & e.lanes) !== 0 && zd(n), e = Ko(u, i), e.ref = n.ref, n.child = e, e.return = n, e;
			}
			function za(e, n) {
				var o = n.ref;
				if (o === null) e !== null && e.ref !== null && (n.flags |= 4194816);
				else {
					if (typeof o != "function" && typeof o != "object") throw Error("Expected ref to be a function, an object returned by React.createRef(), or undefined/null.");
					(e === null || e.ref !== o) && (n.flags |= 4194816);
				}
			}
			function Ea(e, n, o, i, s) {
				if (o.prototype && typeof o.prototype.render == "function") {
					var u = en(o) || "Unknown";
					By[u] || (console.error("The <%s /> component appears to have a render method, but doesn't extend React.Component. This is likely to cause errors. Change %s to extend React.Component instead.", u, u), By[u] = !0);
				}
				return n.mode & 8 && ca.recordLegacyContextWarning(n, null), e === null && (id(n, n.type), o.contextTypes && (u = en(o) || "Unknown", My[u] || (My[u] = !0, console.error("%s uses the legacy contextTypes API which was removed in React 19. Use React.createContext() with React.useContext() instead. (https://react.dev/link/legacy-context)", u)))), gn(n), o = ap(e, n, o, i, void 0, s), i = Oc(), e !== null && !In ? (eu(e, n, s), Jo(e, n, s)) : (le && i && rl(n), n.flags |= 1, bn(e, n, o, s), n.child);
			}
			function kp(e, n, o, i, s, u) {
				return gn(n), qi = -1, Qh = e !== null && e.type !== n.type, n.updateQueue = null, o = Ht(n, i, o, s), ip(e, n), i = Oc(), e !== null && !In ? (eu(e, n, u), Jo(e, n, u)) : (le && i && rl(n), n.flags |= 1, bn(e, n, o, u), n.child);
			}
			function wp(e, n, o, i, s) {
				switch (mc(n)) {
					case !1:
						var u = n.stateNode, f = new n.type(n.memoizedProps, u.context).state;
						u.updater.enqueueSetState(u, f, null);
						break;
					case !0:
						n.flags |= 128, n.flags |= 65536, u = Error("Simulated error coming from DevTools");
						var p = s & -s;
						if (n.lanes |= p, f = Ge, f === null) throw Error("Expected a work-in-progress root. This is a bug in React. Please file an issue.");
						p = pu(p), hu(p, f, n, Ot(u, n)), ui(n, p);
				}
				if (gn(n), n.stateNode === null) {
					if (f = c, u = o.contextType, "contextType" in o && u !== null && (u === void 0 || u.$$typeof !== sn) && !Ay.has(o) && (Ay.add(o), p = u === void 0 ? " However, it is set to undefined. This can be caused by a typo or by mixing up named and default imports. This can also happen due to a circular dependency, so try moving the createContext() call to a separate file." : typeof u != "object" ? " However, it is set to a " + typeof u + "." : u.$$typeof === Aa ? " Did you accidentally pass the Context.Consumer instead?" : " However, it is set to an object with keys {" + Object.keys(u).join(", ") + "}.", console.error("%s defines an invalid contextType. contextType should point to the Context object returned by React.createContext().%s", en(o) || "Component", p)), typeof u == "object" && u !== null && (f = K(u)), u = new o(i, f), n.mode & 8) {
						Oe(!0);
						try {
							u = new o(i, f);
						} finally {
							Oe(!1);
						}
					}
					if (f = n.memoizedState = u.state !== null && u.state !== void 0 ? u.state : null, u.updater = Sb, n.stateNode = u, u._reactInternals = n, u._reactInternalInstance = Ty, typeof o.getDerivedStateFromProps == "function" && f === null && (f = en(o) || "Component", Ry.has(f) || (Ry.add(f), console.error("`%s` uses `getDerivedStateFromProps` but its initial state is %s. This is not recommended. Instead, define the initial state by assigning an object to `this.state` in the constructor of `%s`. This ensures that `getDerivedStateFromProps` arguments have a consistent shape.", f, u.state === null ? "null" : "undefined", f))), typeof o.getDerivedStateFromProps == "function" || typeof u.getSnapshotBeforeUpdate == "function") {
						var g = p = f = null;
						if (typeof u.componentWillMount == "function" && u.componentWillMount.__suppressDeprecationWarning !== !0 ? f = "componentWillMount" : typeof u.UNSAFE_componentWillMount == "function" && (f = "UNSAFE_componentWillMount"), typeof u.componentWillReceiveProps == "function" && u.componentWillReceiveProps.__suppressDeprecationWarning !== !0 ? p = "componentWillReceiveProps" : typeof u.UNSAFE_componentWillReceiveProps == "function" && (p = "UNSAFE_componentWillReceiveProps"), typeof u.componentWillUpdate == "function" && u.componentWillUpdate.__suppressDeprecationWarning !== !0 ? g = "componentWillUpdate" : typeof u.UNSAFE_componentWillUpdate == "function" && (g = "UNSAFE_componentWillUpdate"), f !== null || p !== null || g !== null) {
							u = en(o) || "Component";
							var b = typeof o.getDerivedStateFromProps == "function" ? "getDerivedStateFromProps()" : "getSnapshotBeforeUpdate()";
							Fy.has(u) || (Fy.add(u), console.error(`Unsafe legacy lifecycles will not be called for components using new component APIs.

%s uses %s but also contains the following legacy lifecycles:%s%s%s

The above lifecycles should be removed. Learn more about this warning here:
https://react.dev/link/unsafe-component-lifecycles`, u, b, f !== null ? `
  ` + f : "", p !== null ? `
  ` + p : "", g !== null ? `
  ` + g : ""));
						}
					}
					u = n.stateNode, f = en(o) || "Component", u.render || (o.prototype && typeof o.prototype.render == "function" ? console.error("No `render` method found on the %s instance: did you accidentally return an object from the constructor?", f) : console.error("No `render` method found on the %s instance: you may have forgotten to define `render`.", f)), !u.getInitialState || u.getInitialState.isReactClassApproved || u.state || console.error("getInitialState was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Did you mean to define a state property instead?", f), u.getDefaultProps && !u.getDefaultProps.isReactClassApproved && console.error("getDefaultProps was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Use a static property to define defaultProps instead.", f), u.contextType && console.error("contextType was defined as an instance property on %s. Use a static property to define contextType instead.", f), o.childContextTypes && !Wy.has(o) && (Wy.add(o), console.error("%s uses the legacy childContextTypes API which was removed in React 19. Use React.createContext() instead. (https://react.dev/link/legacy-context)", f)), o.contextTypes && !Uy.has(o) && (Uy.add(o), console.error("%s uses the legacy contextTypes API which was removed in React 19. Use React.createContext() with static contextType instead. (https://react.dev/link/legacy-context)", f)), typeof u.componentShouldUpdate == "function" && console.error("%s has a method called componentShouldUpdate(). Did you mean shouldComponentUpdate()? The name is phrased as a question because the function is expected to return a value.", f), o.prototype && o.prototype.isPureReactComponent && typeof u.shouldComponentUpdate < "u" && console.error("%s has a method called shouldComponentUpdate(). shouldComponentUpdate should not be used when extending React.PureComponent. Please extend React.Component if shouldComponentUpdate is used.", en(o) || "A pure component"), typeof u.componentDidUnmount == "function" && console.error("%s has a method called componentDidUnmount(). But there is no such lifecycle method. Did you mean componentWillUnmount()?", f), typeof u.componentDidReceiveProps == "function" && console.error("%s has a method called componentDidReceiveProps(). But there is no such lifecycle method. If you meant to update the state in response to changing props, use componentWillReceiveProps(). If you meant to fetch data or run side-effects or mutations after React has updated the UI, use componentDidUpdate().", f), typeof u.componentWillRecieveProps == "function" && console.error("%s has a method called componentWillRecieveProps(). Did you mean componentWillReceiveProps()?", f), typeof u.UNSAFE_componentWillRecieveProps == "function" && console.error("%s has a method called UNSAFE_componentWillRecieveProps(). Did you mean UNSAFE_componentWillReceiveProps()?", f), p = u.props !== i, u.props !== void 0 && p && console.error("When calling super() in `%s`, make sure to pass up the same props that your component's constructor was passed.", f), u.defaultProps && console.error("Setting defaultProps as an instance property on %s is not supported and will be ignored. Instead, define defaultProps as a static property on %s.", f, f), typeof u.getSnapshotBeforeUpdate != "function" || typeof u.componentDidUpdate == "function" || Ly.has(o) || (Ly.add(o), console.error("%s: getSnapshotBeforeUpdate() should be used with componentDidUpdate(). This component defines getSnapshotBeforeUpdate() only.", en(o))), typeof u.getDerivedStateFromProps == "function" && console.error("%s: getDerivedStateFromProps() is defined as an instance method and will be ignored. Instead, declare it as a static method.", f), typeof u.getDerivedStateFromError == "function" && console.error("%s: getDerivedStateFromError() is defined as an instance method and will be ignored. Instead, declare it as a static method.", f), typeof o.getSnapshotBeforeUpdate == "function" && console.error("%s: getSnapshotBeforeUpdate() is defined as a static method and will be ignored. Instead, declare it as an instance method.", f), (p = u.state) && (typeof p != "object" || Gn(p)) && console.error("%s.state: must be set to an object or null", f), typeof u.getChildContext == "function" && typeof o.childContextTypes != "object" && console.error("%s.getChildContext(): childContextTypes must be defined in order to use getChildContext().", f), u = n.stateNode, u.props = i, u.state = n.memoizedState, u.refs = {}, Lc(n), f = o.contextType, u.context = typeof f == "object" && f !== null ? K(f) : c, u.state === i && (f = en(o) || "Component", Dy.has(f) || (Dy.add(f), console.error("%s: It is not recommended to assign props directly to state because updates to props won't be reflected in state. In most cases, it is better to use props directly.", f))), n.mode & 8 && ca.recordLegacyContextWarning(n, u), ca.recordUnsafeLifecycleWarnings(n, u), u.state = n.memoizedState, f = o.getDerivedStateFromProps, typeof f == "function" && (od(n, o, f, i), u.state = n.memoizedState), typeof o.getDerivedStateFromProps == "function" || typeof u.getSnapshotBeforeUpdate == "function" || typeof u.UNSAFE_componentWillMount != "function" && typeof u.componentWillMount != "function" || (f = u.state, typeof u.componentWillMount == "function" && u.componentWillMount(), typeof u.UNSAFE_componentWillMount == "function" && u.UNSAFE_componentWillMount(), f !== u.state && (console.error("%s.componentWillMount(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.", G(n) || "Component"), Sb.enqueueReplaceState(u, u.state, null)), Gs(n, i, u, s), kl(), u.state = n.memoizedState), typeof u.componentDidMount == "function" && (n.flags |= 4194308), (n.mode & 16) !== Z && (n.flags |= 268435456), u = !0;
				} else if (e === null) {
					u = n.stateNode;
					var k = n.memoizedProps;
					p = Ca(o, k), u.props = p;
					var z = u.context;
					g = o.contextType, f = c, typeof g == "object" && g !== null && (f = K(g)), b = o.getDerivedStateFromProps, g = typeof b == "function" || typeof u.getSnapshotBeforeUpdate == "function", k = n.pendingProps !== k, g || typeof u.UNSAFE_componentWillReceiveProps != "function" && typeof u.componentWillReceiveProps != "function" || (k || z !== f) && Tl(n, u, i, f), hs = !1;
					var T = n.memoizedState;
					u.state = T, Gs(n, i, u, s), kl(), z = n.memoizedState, k || T !== z || hs ? (typeof b == "function" && (od(n, o, b, i), z = n.memoizedState), (p = hs || bp(n, o, p, i, T, z, f)) ? (g || typeof u.UNSAFE_componentWillMount != "function" && typeof u.componentWillMount != "function" || (typeof u.componentWillMount == "function" && u.componentWillMount(), typeof u.UNSAFE_componentWillMount == "function" && u.UNSAFE_componentWillMount()), typeof u.componentDidMount == "function" && (n.flags |= 4194308), (n.mode & 16) !== Z && (n.flags |= 268435456)) : (typeof u.componentDidMount == "function" && (n.flags |= 4194308), (n.mode & 16) !== Z && (n.flags |= 268435456), n.memoizedProps = i, n.memoizedState = z), u.props = i, u.state = z, u.context = f, u = p) : (typeof u.componentDidMount == "function" && (n.flags |= 4194308), (n.mode & 16) !== Z && (n.flags |= 268435456), u = !1);
				} else {
					u = n.stateNode, Fc(e, n), f = n.memoizedProps, g = Ca(o, f), u.props = g, b = n.pendingProps, T = u.context, z = o.contextType, p = c, typeof z == "object" && z !== null && (p = K(z)), k = o.getDerivedStateFromProps, (z = typeof k == "function" || typeof u.getSnapshotBeforeUpdate == "function") || typeof u.UNSAFE_componentWillReceiveProps != "function" && typeof u.componentWillReceiveProps != "function" || (f !== b || T !== p) && Tl(n, u, i, p), hs = !1, T = n.memoizedState, u.state = T, Gs(n, i, u, s), kl();
					var H = n.memoizedState;
					f !== b || T !== H || hs || e !== null && e.dependencies !== null && dl(e.dependencies) ? (typeof k == "function" && (od(n, o, k, i), H = n.memoizedState), (g = hs || bp(n, o, g, i, T, H, p) || e !== null && e.dependencies !== null && dl(e.dependencies)) ? (z || typeof u.UNSAFE_componentWillUpdate != "function" && typeof u.componentWillUpdate != "function" || (typeof u.componentWillUpdate == "function" && u.componentWillUpdate(i, H, p), typeof u.UNSAFE_componentWillUpdate == "function" && u.UNSAFE_componentWillUpdate(i, H, p)), typeof u.componentDidUpdate == "function" && (n.flags |= 4), typeof u.getSnapshotBeforeUpdate == "function" && (n.flags |= 1024)) : (typeof u.componentDidUpdate != "function" || f === e.memoizedProps && T === e.memoizedState || (n.flags |= 4), typeof u.getSnapshotBeforeUpdate != "function" || f === e.memoizedProps && T === e.memoizedState || (n.flags |= 1024), n.memoizedProps = i, n.memoizedState = H), u.props = i, u.state = H, u.context = p, u = g) : (typeof u.componentDidUpdate != "function" || f === e.memoizedProps && T === e.memoizedState || (n.flags |= 4), typeof u.getSnapshotBeforeUpdate != "function" || f === e.memoizedProps && T === e.memoizedState || (n.flags |= 1024), u = !1);
				}
				if (p = u, za(e, n), f = (n.flags & 128) !== 0, p || f) {
					if (p = n.stateNode, Pc(n), f && typeof o.getDerivedStateFromError != "function") o = null, Jt = -1;
					else if (o = iy(p), n.mode & 8) {
						Oe(!0);
						try {
							iy(p);
						} finally {
							Oe(!1);
						}
					}
					n.flags |= 1, e !== null && f ? (n.child = rc(n, e.child, null, s), n.child = rc(n, null, o, s)) : bn(e, n, o, s), n.memoizedState = p.state, e = n.child;
				} else e = Jo(e, n, s);
				return s = n.stateNode, u && s.props !== i && (bf || console.error("It looks like %s is reassigning its own `this.props` while rendering. This is not supported and can lead to confusing bugs.", G(n) || "a component"), bf = !0), e;
			}
			function Pp(e, n, o, i) {
				return Oo(), n.flags |= 256, bn(e, n, o, i), n.child;
			}
			function id(e, n) {
				n && n.childContextTypes && console.error(`childContextTypes cannot be defined on a function component.
  %s.childContextTypes = ...`, n.displayName || n.name || "Component"), typeof n.getDerivedStateFromProps == "function" && (e = en(n) || "Unknown", Vy[e] || (console.error("%s: Function components do not support getDerivedStateFromProps.", e), Vy[e] = !0)), typeof n.contextType == "object" && n.contextType !== null && (n = en(n) || "Unknown", Hy[n] || (console.error("%s: Function components do not support contextType.", n), Hy[n] = !0));
			}
			function Rl(e) {
				return {
					baseLanes: e,
					cachePool: qf()
				};
			}
			function mu(e, n, o) {
				return e = e !== null ? e.childLanes & ~o : 0, n && (e |= kr), e;
			}
			function km(e, n, o) {
				var i = n.pendingProps;
				hc(n) && (n.flags |= 128);
				var s = !1, u = (n.flags & 128) !== 0, f;
				if ((f = u) || (f = e !== null && e.memoizedState === null ? !1 : (kt.current & Mh) !== 0), f && (s = !0, n.flags &= -129), f = (n.flags & 32) !== 0, n.flags &= -33, e === null) {
					if (le) {
						if (s ? vo(n) : Ar(n), (e = rn) ? (o = Gd(e, No), o !== null && (f = {
							dehydrated: o,
							treeContext: Uf(),
							retryLane: 536870912,
							hydrationErrors: null
						}, n.memoizedState = f, f = th(o), f.return = n, n.child = f, st = n, rn = null)) : o = null, o === null) throw _r(n, e), Nr(n);
						return Ce(o) ? n.lanes = 32 : n.lanes = 536870912, null;
					}
					return u = i.children, i = i.fallback, s ? (Ar(n), s = n.mode, u = ld({
						mode: "hidden",
						children: u
					}, s), i = zi(i, s, o, null), u.return = n, i.return = n, u.sibling = i, n.child = u, i = n.child, i.memoizedState = Rl(o), i.childLanes = mu(e, f, o), n.memoizedState = xb, Il(null, i)) : (vo(n), xp(n, u));
				}
				var p = e.memoizedState;
				if (p !== null) {
					var g = p.dehydrated;
					if (g !== null) return wm(e, n, u, f, i, g, p, o);
				}
				return s ? (Ar(n), s = i.fallback, u = n.mode, p = e.child, g = p.sibling, i = Ko(p, {
					mode: "hidden",
					children: i.children
				}), i.subtreeFlags = p.subtreeFlags & 1206910976, g !== null ? s = Ko(g, s) : (s = zi(s, u, o, null), s.flags |= 2), s.return = n, i.return = n, i.sibling = s, n.child = i, Il(null, i), i = n.child, s = e.child.memoizedState, s === null ? s = Rl(o) : (u = s.cachePool, u !== null ? (p = yn ? vn._currentValue : vn._currentValue2, u = u.parent !== p ? {
					parent: p,
					pool: p
				} : u) : u = qf(), s = {
					baseLanes: s.baseLanes | o,
					cachePool: u
				}), i.memoizedState = s, i.childLanes = mu(e, f, o), n.memoizedState = xb, Il(e.child, i)) : (p !== null && (o & 62914560) === o && (o & e.lanes) !== 0 && zd(n), vo(n), o = e.child, e = o.sibling, o = Ko(o, {
					mode: "visible",
					children: i.children
				}), o.return = n, o.sibling = null, e !== null && (f = n.deletions, f === null ? (n.deletions = [e], n.flags |= 16) : f.push(e)), n.child = o, n.memoizedState = null, o);
			}
			function xp(e, n) {
				return n = ld({
					mode: "visible",
					children: n
				}, e.mode), n.return = e, e.child = n;
			}
			function ld(e, n) {
				return e = ht(22, e, null, n), e.lanes = 0, e;
			}
			function gu(e, n, o) {
				return rc(n, e.child, null, o), e = xp(n, n.pendingProps.children), e.flags |= 2, n.memoizedState = null, e;
			}
			function wm(e, n, o, i, s, u, f, p) {
				if (o) return n.flags & 256 ? (vo(n), n.flags &= -257, gu(e, n, p)) : n.memoizedState !== null ? (Ar(n), n.child = e.child, n.flags |= 128, null) : (Ar(n), u = s.fallback, f = n.mode, s = ld({
					mode: "visible",
					children: s.children
				}, f), u = zi(u, f, p, null), u.flags |= 2, s.return = n, u.return = n, s.sibling = u, n.child = s, rc(n, e.child, null, p), s = n.child, s.memoizedState = Rl(p), s.childLanes = mu(e, i, p), n.memoizedState = xb, Il(null, s));
				if (vo(n), xc(), p & 536870912 && zd(n), Ce(u)) return f = Co(u), i = f.digest, u = f.message, s = f.stack, f = f.componentStack, i !== R1 && (u = Error(u || "The server could not finish this Suspense boundary, likely due to an error during server rendering. Switched to client rendering."), u.stack = s || "", u.digest = i, i = f === void 0 ? null : f, s = {
					value: u,
					source: null,
					stack: i
				}, typeof i == "string" && G0.set(u, s), Ve(s)), gu(e, n, p);
				if (In || Ho(e, n, p, !1), i = (p & e.childLanes) !== 0, In || i) {
					if (ms.current !== null) return gu(e, n, p);
					if (i = Ge, i !== null && (s = Ps(i, p), s !== 0 && s !== f.retryLane)) throw f.retryLane = s, tt(e, s), nn(i, e, s), wb;
					return xn(u) || Iu(), gu(e, n, p);
				}
				return xn(u) ? (n.flags |= 192, n.child = e.child, null) : (e = f.treeContext, $e && (rn = Lt(u), st = n, le = !0, ss = null, qa = !1, Kr = null, No = !1, e !== null && Ts(n, e)), n = xp(n, s.children), n.flags |= 134221824, n);
			}
			function vi(e, n, o) {
				e.lanes |= n;
				var i = e.alternate;
				i !== null && (i.lanes |= n), Cc(e.return, n, o);
			}
			function bu(e) {
				for (var n = null; e !== null;) {
					var o = e.alternate;
					o !== null && Xs(o) === null && (n = e), e = e.sibling;
				}
				return n;
			}
			function yu(e, n, o, i, s, u) {
				var f = e.memoizedState;
				f === null ? e.memoizedState = {
					isBackwards: n,
					rendering: null,
					renderingStartTime: 0,
					last: i,
					tail: o,
					tailMode: s,
					treeForkCount: u
				} : (f.isBackwards = n, f.rendering = null, f.renderingStartTime = 0, f.last = i, f.tail = o, f.tailMode = s, f.treeForkCount = u);
			}
			function sd(e) {
				var n = e.child;
				for (e.child = null; n !== null;) {
					var o = n.sibling;
					n.sibling = e.child, e.child = n, n = o;
				}
			}
			function Cp(e, n, o) {
				var _s2;
				var i = n.pendingProps, s = i.revealOrder, u = i.tail, f = i.children, p = kt.current;
				if (n.flags & 128) return Zs(n, p), null;
				if ((i = (p & Mh) !== 0) ? (p = p & pf | Mh, n.flags |= 128) : p &= pf, Zs(n, p), p = (_s2 = s) != null ? _s2 : "null", s != null && s !== "forwards" && s !== "backwards" && s !== "unstable_legacy-backwards" && s !== "together" && s !== "independent" && !$y[p]) if ($y[p] = !0, typeof s == "string") switch (s.toLowerCase()) {
					case "together":
					case "forwards":
					case "backwards":
					case "independent":
						console.error("\"%s\" is not a valid value for revealOrder on <SuspenseList />. Use lowercase \"%s\" instead.", s, s.toLowerCase());
						break;
					case "forward":
					case "backward":
						console.error("\"%s\" is not a valid value for revealOrder on <SuspenseList />. React uses the -s suffix in the spelling. Use \"%ss\" instead.", s, s.toLowerCase());
						break;
					default: console.error("\"%s\" is not a supported revealOrder on <SuspenseList />. Did you mean \"independent\", \"together\", \"forwards\" or \"backwards\"?", s);
				}
				else console.error("%s is not a supported value for revealOrder on <SuspenseList />. Did you mean \"independent\", \"together\", \"forwards\" or \"backwards\"?", s);
				p = u != null ? u : "null", Pb[p] || u == null || (u !== "visible" && u !== "collapsed" && u !== "hidden" ? (Pb[p] = !0, console.error("\"%s\" is not a supported value for tail on <SuspenseList />. Did you mean \"visible\", \"collapsed\" or \"hidden\"?", u)) : s != null && s !== "forwards" && s !== "backwards" && s !== "unstable_legacy-backwards" && (Pb[p] = !0, console.error("<SuspenseList tail=\"%s\" /> is only valid if revealOrder is \"forwards\" (default) or \"backwards\". Did you mean to specify revealOrder=\"forwards\"?", u)));
				e: if ((s == null || s === "forwards" || s === "backwards" || s === "unstable_legacy-backwards") && f !== void 0 && f !== null && f !== !1) if (Gn(f)) {
					for (p = 0; p < f.length; p++) if (!np(f[p], p)) break e;
				} else if (p = ti(f), typeof p == "function") {
					if (p = p.call(f)) for (var g = p.next(), b = 0; !g.done; g = p.next()) {
						if (!np(g.value, b)) break e;
						b++;
					}
				} else console.error("A single row was passed to a <SuspenseList revealOrder=\"%s\" />. This is not useful since it needs multiple rows. Did you mean to pass multiple children or an array?", s);
				if (s === "backwards" && e !== null ? (sd(e), bn(e, n, f, o), sd(e)) : bn(e, n, f, o), le ? (jo(), f = zh) : f = 0, !i && e !== null && (e.flags & 128) !== 0) e: for (e = n.child; e !== null;) {
					if (e.tag === 13) e.memoizedState !== null && vi(e, o, n);
					else if (e.tag === 19) vi(e, o, n);
					else if (e.child !== null) {
						e.child.return = e, e = e.child;
						continue;
					}
					if (e === n) break e;
					for (; e.sibling === null;) {
						if (e.return === null || e.return === n) break e;
						e = e.return;
					}
					e.sibling.return = e.return, e = e.sibling;
				}
				switch (s) {
					case "backwards":
						o = bu(n.child), o === null ? (s = n.child, n.child = null) : (s = o.sibling, o.sibling = null, sd(n)), yu(n, !0, s, null, u, f);
						break;
					case "unstable_legacy-backwards":
						for (o = null, s = n.child, n.child = null; s !== null;) {
							if (e = s.alternate, e !== null && Xs(e) === null) {
								n.child = s;
								break;
							}
							e = s.sibling, s.sibling = o, o = s, s = e;
						}
						yu(n, !0, o, null, u, f);
						break;
					case "together":
						yu(n, !1, null, null, void 0, f);
						break;
					case "independent":
						n.memoizedState = null;
						break;
					default: o = bu(n.child), o === null ? (s = n.child, n.child = null) : (s = o.sibling, o.sibling = null), yu(n, !1, s, o, u, f);
				}
				return n.child;
			}
			function Pm(e, n, o) {
				var i = n.type, s = n.pendingProps, u = s.value;
				return "value" in s || qy || (qy = !0, console.error("The `value` prop is required for the `<Context.Provider>`. Did you misspell it or forget to pass it?")), Bo(n, i, u), bn(e, n, s.children, o), n.child;
			}
			function Jo(e, n, o) {
				if (e !== null && (n.dependencies = e.dependencies), Jt = -1, bs |= n.lanes, (o & n.childLanes) === 0) if (e !== null) {
					if (Ho(e, n, o, !1), (o & n.childLanes) === 0) return null;
				} else return null;
				if (e !== null && n.child !== e.child) throw Error("Resuming work not yet implemented.");
				if (n.child !== null) {
					for (e = n.child, o = Ko(e, e.pendingProps), n.child = o, o.return = n; e.sibling !== null;) e = e.sibling, o = o.sibling = Ko(e, e.pendingProps), o.return = n;
					o.sibling = null;
				}
				return n.child;
			}
			function vu(e, n) {
				return (e.lanes & n) !== 0 ? !0 : (e = e.dependencies, !!(e !== null && dl(e)));
			}
			function zp(e, n, o) {
				switch (n.tag) {
					case 3:
						co(n, n.stateNode.containerInfo), Bo(n, vn, e.memoizedState.cache), Oo();
						break;
					case 27:
					case 5:
						al(n);
						break;
					case 4:
						co(n, n.stateNode.containerInfo);
						break;
					case 10:
						Bo(n, n.type, n.memoizedProps.value);
						break;
					case 12:
						(o & n.childLanes) !== 0 && (n.flags |= 4), n.flags |= 2048;
						var i = n.stateNode;
						i.effectDuration = -0, i.passiveEffectDuration = -0;
						break;
					case 31:
						if (n.memoizedState !== null) return n.flags |= 128, jc(n), null;
						break;
					case 13:
						if (i = n.memoizedState, i !== null) {
							if (i.dehydrated !== null) return vo(n), n.flags |= 128, null;
							i = Ho(e, n, o, !1);
							var s = n.child.childLanes;
							return i || (o & s) !== 0 ? km(e, n, o) : (vo(n), e = Jo(e, n, o), e !== null ? e.sibling : null);
						}
						vo(n);
						break;
					case 19:
						if (n.flags & 128) return Cp(e, n, o);
						if (s = (e.flags & 128) !== 0, i = (o & n.childLanes) !== 0, i || (Ho(e, n, o, !1), i = (o & n.childLanes) !== 0), s) {
							if (i) return Cp(e, n, o);
							n.flags |= 128;
						}
						if (s = n.memoizedState, s !== null && (s.rendering = null, s.tail = null, s.lastEffect = null), Zs(n, kt.current), i) break;
						return null;
					case 22: return n.lanes = 0, yt(e, n, o, n.pendingProps);
					case 24: Bo(n, vn, e.memoizedState.cache);
				}
				return Jo(e, n, o);
			}
			function Su(e, n, o) {
				if (n._debugNeedsRemount && e !== null) {
					o = Td(Bl(n.elementType), n.key, n.pendingProps, n._debugOwner || null, n.mode, n.lanes), o._debugStack = n._debugStack, o._debugTask = n._debugTask;
					var i = n.return;
					if (i === null) throw Error("Cannot swap the root fiber.");
					if (e.alternate = null, n.alternate = null, o.index = n.index, o.sibling = n.sibling, o.return = n.return, o.ref = n.ref, o._debugInfo = n._debugInfo, n === i.child) i.child = o;
					else {
						var s = i.child;
						if (s === null) throw Error("Expected parent to have a child.");
						for (; s.sibling !== n;) if (s = s.sibling, s === null) throw Error("Expected to find the previous sibling.");
						s.sibling = o;
					}
					return n = i.deletions, n === null ? (i.deletions = [e], i.flags |= 16) : n.push(e), o.flags |= 134217730, o;
				}
				if (e !== null) {
					if (e.memoizedProps !== n.pendingProps || n.type !== e.type) In = !0;
					else {
						if (!vu(e, o) && (n.flags & 128) === 0) return In = !1, zp(e, n, o);
						In = (e.flags & 131072) !== 0;
					}
				} else In = !1, (i = le) && (jo(), i = (n.flags & 1048576) !== 0), i && (i = n.index, jo(), dm(n, zh, i));
				switch (n.lanes = 0, n.tag) {
					case 16:
						e: if (i = n.pendingProps, e = bo(n.elementType), e = Bl(e), n.type = e, typeof e == "function") nh(e) ? (i = Ca(e, i), n.tag = 1, n = wp(null, n, e, i, o)) : (n.tag = 0, id(n, e), n = Ea(null, n, e, i, o));
						else {
							if (e != null) {
								if (s = e.$$typeof, s === Fd) {
									n.tag = 11, n = zt(null, n, e, i, o);
									break e;
								} else if (s === Ei) {
									n.tag = 14, n = vp(null, n, e, i, o);
									break e;
								} else if (s === sn) {
									n.tag = 10, n.type = e, n = Pm(null, n, o);
									break e;
								}
							}
							throw n = "", e !== null && typeof e == "object" && e.$$typeof === qn && (n = " Did you wrap a component in React.lazy() more than once?"), e = en(e) || e, Error("Element type is invalid. Received a promise that resolves to: " + e + ". Lazy element type must resolve to a class or function." + n);
						}
						return n;
					case 0: return Ea(e, n, n.type, n.pendingProps, o);
					case 1: return i = n.type, s = Ca(i, n.pendingProps), wp(e, n, i, s, o);
					case 3:
						e: {
							if (co(n, n.stateNode.containerInfo), e === null) throw Error("Should have a current fiber. This is a bug in React.");
							var u = n.pendingProps;
							s = n.memoizedState, i = s.element, Fc(e, n), Gs(n, u, null, o);
							var f = n.memoizedState;
							if (u = f.cache, Bo(n, vn, u), u !== s.cache && Ds(n, [vn], o, !0), kl(), u = f.element, $e && s.isDehydrated) {
								if (s = {
									element: u,
									isDehydrated: !1,
									cache: f.cache
								}, n.updateQueue.baseState = s, n.memoizedState = s, n.flags & 256) {
									n = Pp(e, n, u, o);
									break e;
								} else if (u !== i) {
									i = Ot(Error("This root received an early update, before anything was able hydrate. Switched the entire root to client rendering."), n), Ve(i), n = Pp(e, n, u, o);
									break e;
								} else for ($e && (rn = kh(n.stateNode.containerInfo), st = n, le = !0, ss = null, qa = !1, Kr = null, No = !0), e = Sy(n, null, u, o), n.child = e; e;) e.flags = e.flags & -3 | 134221824, e = e.sibling;
							} else {
								if (Oo(), u === i) {
									n = Jo(e, n, o);
									break e;
								}
								bn(e, n, u, o);
							}
							n = n.child;
						}
						return n;
					case 26: if (Ze) return za(e, n), e === null ? (e = Ph(n.type, null, n.pendingProps, null)) ? n.memoizedState = e : le || (n.stateNode = $a(n.type, n.pendingProps, Uo(ls.current), n)) : n.memoizedState = Ph(n.type, e.memoizedProps, n.pendingProps, e.memoizedState), null;
					case 27: if (je) return al(n), e === null && je && le && (s = Uo(ls.current), i = Cr(), s = n.stateNode = Ui(n.type, n.pendingProps, s, i, !1), qa || (i = Ma(s, n.type, n.pendingProps, i), i !== null && (Ao(n, 0).serverProps = i)), st = n, No = !0, rn = Yr(n.type, s, rn)), bn(e, n, n.pendingProps.children, o), za(e, n), e === null && (n.flags |= 4194304), n.child;
					case 5: return e === null && le && (u = Cr(), i = es(n.type, n.pendingProps, u), s = rn, (f = !s) || (f = Di(s, n.type, n.pendingProps, No), f !== null ? (n.stateNode = f, qa || (u = Ma(f, n.type, n.pendingProps, u), u !== null && (Ao(n, 0).serverProps = u)), st = n, rn = Qd(f), No = !1, u = !0) : u = !1, f = !u), f && (i && _r(n, s), Nr(n))), al(n), s = n.type, u = n.pendingProps, f = e !== null ? e.memoizedProps : null, i = u.children, ea(s, u) ? i = null : f !== null && ea(s, f) && (n.flags |= 32), n.memoizedState !== null && (s = ap(e, n, Ac, null, null, o), yn ? Jr._currentValue = s : Jr._currentValue2 = s), za(e, n), bn(e, n, i, o), n.child;
					case 6: return e === null && le && (e = n.pendingProps, o = Cr(), e = Vu(e, o), o = rn, (i = !o) || (i = H0(o, n.pendingProps, No), i !== null ? (n.stateNode = i, st = n, rn = null, i = !0) : i = !1, i = !i), i && (e && _r(n, o), Nr(n))), null;
					case 13: return km(e, n, o);
					case 4: return co(n, n.stateNode.containerInfo), i = n.pendingProps, e === null ? n.child = rc(n, null, i, o) : bn(e, n, i, o), n.child;
					case 11: return zt(e, n, n.type, n.pendingProps, o);
					case 7: return i = n.pendingProps, za(e, n), bn(e, n, i, o), n.child;
					case 8: return bn(e, n, n.pendingProps.children, o), n.child;
					case 12: return n.flags |= 4, n.flags |= 2048, i = n.stateNode, i.effectDuration = -0, i.passiveEffectDuration = -0, bn(e, n, n.pendingProps.children, o), n.child;
					case 10: return Pm(e, n, o);
					case 9: return s = n.type._context, i = n.pendingProps.children, typeof i != "function" && console.error("A context consumer was rendered with multiple children, or a child that isn't a function. A context consumer expects a single child that is a function. If you did pass a function, make sure there is no trailing or leading whitespace around it."), gn(n), s = K(s), i = sb(i, s, void 0), n.flags |= 1, bn(e, n, i, o), n.child;
					case 14: return vp(e, n, n.type, n.pendingProps, o);
					case 15: return yi(e, n, n.type, n.pendingProps, o);
					case 19: return Cp(e, n, o);
					case 31: return Sm(e, n, o);
					case 22: return yt(e, n, o, n.pendingProps);
					case 24: return gn(n), i = K(vn), e === null ? (s = Bs(), s === null && (s = Ge, u = pl(), s.pooledCache = u, Mo(u), u !== null && (s.pooledCacheLanes |= o), s = u), n.memoizedState = {
						parent: i,
						cache: s
					}, Lc(n), Bo(n, vn, s)) : ((e.lanes & o) !== 0 && (Fc(e, n), Gs(n, null, null, o), kl()), s = e.memoizedState, u = n.memoizedState, s.parent !== i ? (s = {
						parent: i,
						cache: i
					}, n.memoizedState = s, n.lanes === 0 && (n.memoizedState = n.updateQueue.baseState = s), Bo(n, vn, i)) : (i = u.cache, Bo(n, vn, i), i !== s.cache && Ds(n, [vn], o, !0))), bn(e, n, n.pendingProps.children, o), n.child;
					case 30: return n.stateNode === null && (n.stateNode = {
						autoName: null,
						paired: null,
						clones: null,
						ref: null
					}), i = n.pendingProps, i.name != null && i.name !== "auto" ? n.flags |= e === null ? 18882560 : 18874368 : le && rl(n), i.className !== void 0 && (s = typeof i.className == "string" ? JSON.stringify(i.className) : "{...}", Qy[s] || (Qy[s] = !0, console.error(`<ViewTransition> doesn't accept a "className" prop. It has been renamed to "default".
-   <ViewTransition className=%s>
+   <ViewTransition default=%s>`, s, s))), e !== null && e.memoizedProps.name !== i.name ? n.flags |= 4194816 : za(e, n), bn(e, n, i.children, o), n.child;
					case 29: throw n.pendingProps;
				}
				throw Error("Unknown unit of work tag (" + n.tag + "). This error is likely caused by a bug in React. Please file an issue.");
			}
			function ir(e) {
				e.flags |= 4;
			}
			function _a(e) {
				_n && (e.flags |= 8);
			}
			function ud(e, n) {
				if (e !== null && e.child === n.child) return !1;
				if ((n.flags & 16) !== 0) return !0;
				for (e = n.child; e !== null;) {
					if ((e.flags & 8218) !== 0 || (e.subtreeFlags & 8218) !== 0) return !0;
					e = e.sibling;
				}
				return !1;
			}
			function cd(e, n, o, i) {
				if (_e) for (o = n.child; o !== null;) {
					if (o.tag === 5 || o.tag === 6) Fu(e, o.stateNode);
					else if (!(o.tag === 4 || je && o.tag === 27) && o.child !== null) {
						o.child.return = o, o = o.child;
						continue;
					}
					if (o === n) break;
					for (; o.sibling === null;) {
						if (o.return === null || o.return === n) return;
						o = o.return;
					}
					o.sibling.return = o.return, o = o.sibling;
				}
				else if (_n) for (var s = n.child; s !== null;) {
					if (s.tag === 5) {
						var u = s.stateNode;
						o && i && (u = Xr(u, s.type, s.memoizedProps)), Fu(e, u);
					} else if (s.tag === 6) u = s.stateNode, o && i && (u = vt(u, s.memoizedProps)), Fu(e, u);
					else if (s.tag !== 4) {
						if (s.tag === 22 && s.memoizedState !== null) u = s.child, u !== null && (u.return = s), cd(e, s, !0, !0);
						else if (s.child !== null) {
							s.child.return = s, s = s.child;
							continue;
						}
					}
					if (s === n) break;
					for (; s.sibling === null;) {
						if (s.return === null || s.return === n) return;
						s = s.return;
					}
					s.sibling.return = s.return, s = s.sibling;
				}
			}
			function ke(e, n, o, i) {
				var s = !1;
				if (_n) for (var u = n.child; u !== null;) {
					if (u.tag === 5) {
						var f = u.stateNode;
						o && i && (f = Xr(f, u.type, u.memoizedProps)), Yn(e, f);
					} else if (u.tag === 6) f = u.stateNode, o && i && (f = vt(f, u.memoizedProps)), Yn(e, f);
					else if (u.tag !== 4) {
						if (u.tag === 22 && u.memoizedState !== null) s = u.child, s !== null && (s.return = u), ke(e, u, !0, !0), s = !0;
						else if (u.child !== null) {
							u.child.return = u, u = u.child;
							continue;
						}
					}
					if (u === n) break;
					for (; u.sibling === null;) {
						if (u.return === null || u.return === n) return s;
						u = u.return;
					}
					u.sibling.return = u.return, u = u.sibling;
				}
				return s;
			}
			function dd(e, n) {
				if (_n && ud(e, n)) {
					e = n.stateNode;
					var o = e.containerInfo, i = Vd();
					ke(i, n, !1, !1), e.pendingChildren = i, ir(n), $d(o, i);
				}
			}
			function Ep(e, n, o, i) {
				if (_e) e.memoizedProps !== i && ir(n);
				else if (_n) {
					var s = e.stateNode, u = e.memoizedProps;
					if ((e = ud(e, n)) || u !== i) {
						var f = Cr();
						u = Pn(s, o, u, i, !e, null), u === s ? n.stateNode = s : (_a(n), ph(u, o, i, f) && ir(n), n.stateNode = u, e && cd(u, n, !1, !1));
					} else n.stateNode = s;
				}
			}
			function fd(e, n, o, i, s) {
				if ((e.mode & 32) !== Z && (o === null ? jd(n, i) : Ni(n, o, i))) {
					if (e.flags |= 16777216, (s & 335544128) === s || qr(n, i)) if (Pg(e.stateNode, n, i)) e.flags |= 8192;
					else if (Ym()) e.flags |= 8192;
					else throw tc = $g, cb;
				} else e.flags &= -16777217;
			}
			function xm(e, n) {
				if (xh(n)) {
					if (e.flags |= 16777216, !ef(n)) if (Ym()) e.flags |= 8192;
					else throw tc = $g, cb;
				} else e.flags &= -16777217;
			}
			function pd(e, n) {
				n !== null && (e.flags |= 4), e.flags & 16384 && (n = e.tag !== 22 ? ws() : 536870912, e.lanes |= n, cc |= n);
			}
			function ku(e, n) {
				if (!le) switch (e.tailMode) {
					case "visible": break;
					case "collapsed":
						for (var o = e.tail, i = null; o !== null;) o.alternate !== null && (i = o), o = o.sibling;
						i === null ? n || e.tail === null ? e.tail = null : e.tail.sibling = null : i.sibling = null;
						break;
					default:
						for (n = e.tail, o = null; n !== null;) n.alternate !== null && (o = n), n = n.sibling;
						o === null ? e.tail = null : o.sibling = null;
				}
			}
			function Fe(e) {
				var n = e.alternate !== null && e.alternate.child === e.child, o = 0, i = 0;
				if (n) {
					if ((e.mode & 2) !== Z) {
						for (var s = e.selfBaseDuration, u = e.child; u !== null;) o |= u.lanes | u.childLanes, i |= u.subtreeFlags & 1206910976, i |= u.flags & 1206910976, s += u.treeBaseDuration, u = u.sibling;
						e.treeBaseDuration = s;
					} else for (s = e.child; s !== null;) o |= s.lanes | s.childLanes, i |= s.subtreeFlags & 1206910976, i |= s.flags & 1206910976, s.return = e, s = s.sibling;
				} else if ((e.mode & 2) !== Z) {
					s = e.actualDuration, u = e.selfBaseDuration;
					for (var f = e.child; f !== null;) o |= f.lanes | f.childLanes, i |= f.subtreeFlags, i |= f.flags, s += f.actualDuration, u += f.treeBaseDuration, f = f.sibling;
					e.actualDuration = s, e.treeBaseDuration = u;
				} else for (s = e.child; s !== null;) o |= s.lanes | s.childLanes, i |= s.subtreeFlags, i |= s.flags, s.return = e, s = s.sibling;
				return e.subtreeFlags |= i, e.childLanes = o, n;
			}
			function _p(e, n, o) {
				var i = n.pendingProps;
				switch (ol(n), n.tag) {
					case 16:
					case 15:
					case 0:
					case 11:
					case 7:
					case 8:
					case 12:
					case 9:
					case 14: return Fe(n), null;
					case 1: return Fe(n), null;
					case 3: return o = n.stateNode, i = null, e !== null && (i = e.memoizedState.cache), n.memoizedState.cache !== i && (n.flags |= 2048), ho(vn, n), ai(n), o.pendingContext && (o.context = o.pendingContext, o.pendingContext = null), (e === null || e.child === null) && (Ln(n) ? (Fs(), ir(n)) : e === null || e.memoizedState.isDehydrated && !(n.flags & 256) || (n.flags |= 1024, ul())), dd(e, n), Fe(n), null;
					case 26: if (Ze) {
						var s = n.type, u = n.memoizedState;
						return e === null ? (ir(n), u !== null ? (Fe(n), xm(n, u)) : (Fe(n), fd(n, s, null, i, o))) : u ? u !== e.memoizedState ? (ir(n), Fe(n), xm(n, u)) : (Fe(n), n.flags &= -16777217) : (u = e.memoizedProps, _e ? u !== i && ir(n) : Ep(e, n, s, i), Fe(n), fd(n, s, u, i, o)), null;
					}
					case 27: if (je) {
						if (zr(n), o = Uo(ls.current), s = n.type, e !== null && n.stateNode != null) _e ? e.memoizedProps !== i && ir(n) : Ep(e, n, s, i);
						else {
							if (!i) {
								if (n.stateNode === null) throw Error("We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
								return Fe(n), n.subtreeFlags &= -33554433, null;
							}
							e = Cr(), Ln(n) ? Wf(n, e) : (e = Ui(s, i, o, e, !0), n.stateNode = e, ir(n));
						}
						return Fe(n), n.subtreeFlags &= -33554433, null;
					}
					case 5:
						if (zr(n), s = n.type, e !== null && n.stateNode != null) Ep(e, n, s, i);
						else {
							if (!i) {
								if (n.stateNode === null) throw Error("We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
								return Fe(n), n.subtreeFlags &= -33554433, null;
							}
							if (u = Cr(), Ln(n)) Wf(n, u), Qt(n.stateNode, s, i, u) && (n.flags |= 64);
							else {
								var f = Uo(ls.current);
								f = wg(s, i, f, u, n), _a(n), cd(f, n, !1, !1), n.stateNode = f, ph(f, s, i, u) && ir(n);
							}
						}
						return Fe(n), n.subtreeFlags &= -33554433, fd(n, n.type, e === null ? null : e.memoizedProps, n.pendingProps, o), null;
					case 6:
						if (e && n.stateNode != null) o = e.memoizedProps, _e ? o !== i && ir(n) : _n && (o !== i ? (e = Uo(ls.current), o = Cr(), _a(n), n.stateNode = _i(i, e, o, n)) : n.stateNode = e.stateNode);
						else {
							if (typeof i != "string" && n.stateNode === null) throw Error("We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
							if (e = Uo(ls.current), o = Cr(), Ln(n)) {
								if (!$e) throw Error("Expected prepareToHydrateHostTextInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
								if (e = n.stateNode, o = n.memoizedProps, s = !qa, i = null, u = st, u !== null) switch (u.tag) {
									case 3:
										s && (s = Yd(e, o, i), s !== null && (Ao(n, 0).serverProps = s));
										break;
									case 27:
									case 5: i = u.memoizedProps, s && (s = Yd(e, o, i), s !== null && (Ao(n, 0).serverProps = s));
								}
								Zd(e, o, n, i) || Nr(n, !0);
							} else _a(n), n.stateNode = _i(i, e, o, n);
						}
						return Fe(n), null;
					case 31:
						if (o = n.memoizedState, e === null || e.memoizedState !== null) {
							if (i = Ln(n), o !== null) {
								if (e === null) {
									if (!i) throw Error("A dehydrated suspense component was completed without a hydrated node. This is probably a bug in React.");
									if (!$e) throw Error("Expected prepareToHydrateHostActivityInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
									if (e = n.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error("Expected to have a hydrated activity instance. This error is likely caused by a bug in React. Please file an issue.");
									Xd(e, n), Fe(n), (n.mode & 2) !== Z && o !== null && (e = n.child, e !== null && (n.treeBaseDuration -= e.treeBaseDuration));
								} else Fs(), Oo(), !(n.flags & 128) && (o = n.memoizedState = null), n.flags |= 4, Fe(n), (n.mode & 2) !== Z && o !== null && (e = n.child, e !== null && (n.treeBaseDuration -= e.treeBaseDuration));
								e = !1;
							} else o = ul(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = o), e = !0;
							if (!e) return n.flags & 256 ? (rt(n), n) : (rt(n), null);
							if ((n.flags & 128) !== 0) throw Error("Client rendering an Activity suspended it again. This is a bug in React.");
						}
						return Fe(n), null;
					case 13:
						if (i = n.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
							if (s = i, u = Ln(n), s !== null && s.dehydrated !== null) {
								if (e === null) {
									if (!u) throw Error("A dehydrated suspense component was completed without a hydrated node. This is probably a bug in React.");
									if (!$e) throw Error("Expected prepareToHydrateHostSuspenseInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
									if (u = n.memoizedState, u = u !== null ? u.dehydrated : null, !u) throw Error("Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
									Mu(u, n), Fe(n), (n.mode & 2) !== Z && s !== null && (s = n.child, s !== null && (n.treeBaseDuration -= s.treeBaseDuration));
								} else Fs(), Oo(), !(n.flags & 128) && (s = n.memoizedState = null), n.flags |= 4, Fe(n), (n.mode & 2) !== Z && s !== null && (s = n.child, s !== null && (n.treeBaseDuration -= s.treeBaseDuration));
								s = !1;
							} else s = ul(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = s), s = !0;
							if (!s) return n.flags & 256 ? (rt(n), n) : (rt(n), null);
						}
						return rt(n), (n.flags & 128) !== 0 ? (n.lanes = o, (n.mode & 2) !== Z && ml(n), n) : (o = i !== null, e = e !== null && e.memoizedState !== null, o && (i = n.child, s = null, i.alternate !== null && i.alternate.memoizedState !== null && i.alternate.memoizedState.cachePool !== null && (s = i.alternate.memoizedState.cachePool.pool), u = null, i.memoizedState !== null && i.memoizedState.cachePool !== null && (u = i.memoizedState.cachePool.pool), u !== s && (i.flags |= 2048)), o !== e && o && (n.child.flags |= 8192), pd(n, n.updateQueue), Fe(n), (n.mode & 2) !== Z && o && (e = n.child, e !== null && (n.treeBaseDuration -= e.treeBaseDuration)), null);
					case 4: return ai(n), dd(e, n), e === null && ju(n.stateNode.containerInfo), n.flags |= 67108864, Fe(n), null;
					case 10: return ho(n.type, n), Fe(n), null;
					case 19:
						if (Wc(n), i = n.memoizedState, i === null) return Fe(n), null;
						if (s = (n.flags & 128) !== 0, u = i.rendering, u === null) {
							if (s) ku(i, !1);
							else {
								if (fn !== Gi || e !== null && (e.flags & 128) !== 0) for (e = n.child; e !== null;) {
									if (u = Xs(e), u !== null) {
										for (n.flags |= 128, ku(i, !1), e = u.updateQueue, n.updateQueue = e, pd(n, e), n.subtreeFlags = 0, e = o, o = n.child; o !== null;) bg(o, e), o = o.sibling;
										return Zs(n, kt.current & pf | Mh), le && uo(n, i.treeForkCount), n.child;
									}
									e = e.sibling;
								}
								i.tail !== null && Re() > em && (n.flags |= 128, s = !0, ku(i, !1), n.lanes = 4194304);
							}
						} else {
							if (!s) if (e = Xs(u), e !== null) {
								if (n.flags |= 128, s = !0, e = e.updateQueue, n.updateQueue = e, pd(n, e), ku(i, !0), i.tail === null && i.tailMode !== "collapsed" && i.tailMode !== "visible" && !u.alternate && !le) return Fe(n), null;
							} else 2 * Re() - i.renderingStartTime > em && o !== 536870912 && (n.flags |= 128, s = !0, ku(i, !1), n.lanes = 4194304);
							i.isBackwards ? (u.sibling = n.child, n.child = u) : (e = i.last, e !== null ? e.sibling = u : n.child = u, i.last = u);
						}
						if (i.tail !== null) {
							e = i.tail;
							e: {
								for (o = e; o !== null;) {
									if (o.alternate !== null) {
										o = !1;
										break e;
									}
									o = o.sibling;
								}
								o = !0;
							}
							return i.rendering = e, i.tail = e.sibling, i.renderingStartTime = Re(), e.sibling = null, u = kt.current, u = s ? u & pf | Mh : u & pf, i.tailMode === "visible" || i.tailMode === "collapsed" || !o || le ? Zs(n, u) : (o = u, ze(St, n, n), ze(kt, o, n), Zt === null && (Zt = n)), le && uo(n, i.treeForkCount), e;
						}
						return Fe(n), null;
					case 22:
					case 23: return rt(n), Js(n), i = n.memoizedState !== null, e !== null ? e.memoizedState !== null !== i && (n.flags |= 8192) : i && (n.flags |= 8192), i ? o & 536870912 && !(n.flags & 128) && (Fe(n), n.subtreeFlags & 6 && (n.flags |= 8192)) : Fe(n), o = n.updateQueue, o !== null && pd(n, o.retryQueue), o = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (o = e.memoizedState.cachePool.pool), i = null, n.memoizedState !== null && n.memoizedState.cachePool !== null && (i = n.memoizedState.cachePool.pool), i !== o && (n.flags |= 2048), e !== null && mn(Ku, n), null;
					case 24: return o = null, e !== null && (o = e.memoizedState.cache), n.memoizedState.cache !== o && (n.flags |= 2048), ho(vn, n), Fe(n), null;
					case 25: return null;
					case 30: return n.flags |= 33554432, Fe(n), null;
				}
				throw Error("Unknown unit of work tag (" + n.tag + "). This error is likely caused by a bug in React. Please file an issue.");
			}
			function Zo(e, n) {
				switch (ol(n), n.tag) {
					case 1: return e = n.flags, e & 65536 ? (n.flags = e & -65537 | 128, (n.mode & 2) !== Z && ml(n), n) : null;
					case 3: return ho(vn, n), ai(n), e = n.flags, (e & 65536) !== 0 && (e & 128) === 0 ? (n.flags = e & -65537 | 128, n) : null;
					case 26:
					case 27:
					case 5: return zr(n), null;
					case 31:
						if (n.memoizedState !== null) {
							if (rt(n), n.alternate === null) throw Error("Threw in newly mounted dehydrated component. This is likely a bug in React. Please file an issue.");
							Oo();
						}
						return e = n.flags, e & 65536 ? (n.flags = e & -65537 | 128, (n.mode & 2) !== Z && ml(n), n) : null;
					case 13:
						if (rt(n), e = n.memoizedState, e !== null && e.dehydrated !== null) {
							if (n.alternate === null) throw Error("Threw in newly mounted dehydrated component. This is likely a bug in React. Please file an issue.");
							Oo();
						}
						return e = n.flags, e & 65536 ? (n.flags = e & -65537 | 128, (n.mode & 2) !== Z && ml(n), n) : null;
					case 19: return Wc(n), e = n.flags, e & 65536 ? (n.flags = e & -65537 | 128, e = n.memoizedState, e !== null && (e.rendering = null, e.tail = null), n.flags |= 4, n) : null;
					case 4: return ai(n), null;
					case 10: return ho(n.type, n), null;
					case 22:
					case 23: return rt(n), Js(n), e !== null && mn(Ku, n), e = n.flags, e & 65536 ? (n.flags = e & -65537 | 128, (n.mode & 2) !== Z && ml(n), n) : null;
					case 24: return ho(vn, n), null;
					case 25: return null;
					default: return null;
				}
			}
			function Np(e, n) {
				switch (ol(n), n.tag) {
					case 3:
						ho(vn, n), ai(n);
						break;
					case 26:
					case 27:
					case 5:
						zr(n);
						break;
					case 4:
						ai(n);
						break;
					case 31:
						n.memoizedState !== null && rt(n);
						break;
					case 13:
						rt(n);
						break;
					case 19:
						Wc(n);
						break;
					case 10:
						ho(n.type, n);
						break;
					case 22:
					case 23:
						rt(n), Js(n), e !== null && mn(Ku, n);
						break;
					case 24: ho(vn, n);
				}
			}
			function Vt(e) {
				return (e.mode & 2) !== Z;
			}
			function Na(e, n) {
				Vt(e) ? (Dr(), Ll(n, e), Fr()) : Ll(n, e);
			}
			function wu(e, n, o) {
				Vt(e) ? (Dr(), Ta(o, e, n), Fr()) : Ta(o, e, n);
			}
			function Ll(e, n) {
				try {
					var o = n.updateQueue, i = o !== null ? o.lastEffect : null;
					if (i !== null) {
						var s = i.next;
						o = s;
						do {
							if ((o.tag & e) === e && (i = void 0, (e & Xt) !== Vh && (xf = !0), i = B(n, F1, o), (e & Xt) !== Vh && (xf = !1), i !== void 0 && typeof i != "function")) {
								var u = void 0;
								u = (o.tag & eo) !== 0 ? "useLayoutEffect" : (o.tag & Xt) !== 0 ? "useInsertionEffect" : "useEffect";
								var f = void 0;
								f = i === null ? " You returned null. If your effect does not require clean up, return undefined (or nothing)." : typeof i.then == "function" ? `

It looks like you wrote ` + u + `(async () => ...) or returned a Promise. Instead, write the async function inside your effect and call it immediately:

` + u + `(() => {
  async function fetchData() {
    // You can await here
    const response = await MyAPI.getData(someId);
    // ...
  }
  fetchData();
}, [someId]); // Or [] if effect doesn't need props or state

Learn more about data fetching with Hooks: https://react.dev/link/hooks-data-fetching` : " You returned: " + i, B(n, function(p, g) {
									console.error("%s must not return anything besides a function, which is used for clean-up.%s", p, g);
								}, u, f);
							}
							o = o.next;
						} while (o !== s);
					}
				} catch (p) {
					we(n, n.return, p);
				}
			}
			function Ta(e, n, o) {
				try {
					var i = n.updateQueue, s = i !== null ? i.lastEffect : null;
					if (s !== null) {
						var u = s.next;
						i = u;
						do {
							if ((i.tag & e) === e) {
								var f = i.inst, p = f.destroy;
								p !== void 0 && (f.destroy = void 0, (e & Xt) !== Vh && (xf = !0), s = n, B(s, D1, s, o, p), (e & Xt) !== Vh && (xf = !1));
							}
							i = i.next;
						} while (i !== u);
					}
				} catch (g) {
					we(n, n.return, g);
				}
			}
			function Cm(e, n) {
				Vt(e) ? (Dr(), Ll(n, e), Fr()) : Ll(n, e);
			}
			function hd(e, n, o) {
				Vt(e) ? (Dr(), Ta(o, e, n), Fr()) : Ta(o, e, n);
			}
			function Tp(e) {
				var n = e.updateQueue;
				if (n !== null) {
					var o = e.stateNode;
					e.type.defaultProps || "ref" in e.memoizedProps || bf || (o.props !== e.memoizedProps && console.error("Expected %s props to match memoized props before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", G(e) || "instance"), o.state !== e.memoizedState && console.error("Expected %s state to match memoized state before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", G(e) || "instance"));
					try {
						B(e, rp, n, o);
					} catch (i) {
						we(e, e.return, i);
					}
				}
			}
			function zm(e, n, o) {
				return e.getSnapshotBeforeUpdate(n, o);
			}
			function Em(e, n) {
				var o = n.memoizedProps, i = n.memoizedState;
				n = e.stateNode, e.type.defaultProps || "ref" in e.memoizedProps || bf || (n.props !== e.memoizedProps && console.error("Expected %s props to match memoized props before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", G(e) || "instance"), n.state !== e.memoizedState && console.error("Expected %s state to match memoized state before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", G(e) || "instance"));
				try {
					var s = Ca(e.type, o), u = B(e, zm, n, s, i);
					o = Gy, u !== void 0 || o.has(e.type) || (o.add(e.type), B(e, function() {
						console.error("%s.getSnapshotBeforeUpdate(): A snapshot value (or null) must be returned. You have returned undefined.", G(e));
					})), n.__reactInternalSnapshotBeforeUpdate = u;
				} catch (f) {
					we(e, e.return, f);
				}
			}
			function Ip(e, n, o) {
				o.props = Ca(e.type, e.memoizedProps), o.state = e.memoizedState, Vt(e) ? (Dr(), B(e, fy, e, n, o), Fr()) : B(e, fy, e, n, o);
			}
			function Rp(e) {
				var n = e.ref;
				if (n !== null) {
					switch (e.tag) {
						case 26:
						case 27:
						case 5:
							var o = Ql(e.stateNode);
							break;
						case 30:
							o = e.stateNode;
							var i = Mn(e.memoizedProps, o);
							(o.ref === null || o.ref.name !== i) && (o.ref = Bu(i)), o = o.ref;
							break;
						case 7:
							e.stateNode === null && (e.stateNode = _g(e)), o = e.stateNode;
							break;
						default: o = e.stateNode;
					}
					if (typeof n == "function") {
						if (Vt(e)) try {
							Dr(), e.refCleanup = n(o);
						} finally {
							Fr();
						}
						else e.refCleanup = n(o);
					} else typeof n == "string" ? console.error("String refs are no longer supported.") : n.hasOwnProperty("current") || console.error("Unexpected ref object provided for %s. Use either a ref-setter function or React.createRef().", G(e)), n.current = o;
				}
			}
			function Y(e, n) {
				try {
					B(e, Rp, e);
				} catch (o) {
					we(e, n, o);
				}
			}
			function $n(e, n) {
				var o = e.ref, i = e.refCleanup;
				if (o !== null) if (typeof i == "function") try {
					if (Vt(e)) try {
						Dr(), B(e, i);
					} finally {
						Fr(e);
					}
					else B(e, i);
				} catch (s) {
					we(e, n, s);
				} finally {
					e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null);
				}
				else if (typeof o == "function") try {
					if (Vt(e)) try {
						Dr(), B(e, o, null);
					} finally {
						Fr(e);
					}
					else B(e, o, null);
				} catch (s) {
					we(e, n, s);
				}
				else o.current = null;
			}
			function Et(e, n, o, i) {
				var s = e.memoizedProps, u = s.id, f = s.onCommit;
				s = s.onRender, n = n === null ? "mount" : "update", Og && (n = "nested-update"), typeof s == "function" && s(u, n, e.actualDuration, e.treeBaseDuration, e.actualStartTime, o), typeof f == "function" && f(u, n, i, o);
			}
			function Lp(e, n, o, i) {
				var s = e.memoizedProps;
				e = s.id, s = s.onPostCommit, n = n === null ? "mount" : "update", Og && (n = "nested-update"), typeof s == "function" && s(e, n, i, o);
			}
			function _m() {
				var e = jt;
				return jt = !1, e;
			}
			function Ia(e, n) {
				if ((e.tag === 5 || e.tag === 27 || e.tag === 6) && e.alternate === null && n !== null) for (var o = 0; o < n.length; o++) Md(e.stateNode, n[o]);
			}
			function Si(e) {
				for (var n = e.return; n !== null && (Pu(n) && Md(e.stateNode, n.stateNode), !md(n));) n = n.return;
			}
			function wo(e) {
				for (var n = e.return; n !== null && (Pu(n) && vh(e.stateNode, n.stateNode), !md(n));) n = n.return;
			}
			function md(e) {
				return e.tag === 5 || e.tag === 3 || (je ? e.tag === 27 : !1);
			}
			function Pu(e) {
				return e && e.tag === 7 && e.stateNode !== null;
			}
			function gd(e) {
				var n = e.type, o = e.memoizedProps, i = e.stateNode;
				try {
					B(e, Au, i, n, o, e);
				} catch (s) {
					we(e, e.return, s);
				}
			}
			function Vr(e, n, o) {
				try {
					B(e, Li, e.stateNode, e.type, o, n, e);
				} catch (i) {
					we(e, e.return, i);
				}
			}
			function bd(e) {
				return e.tag === 5 || e.tag === 3 || (Ze ? e.tag === 26 : !1) || (je ? e.tag === 27 && t(e.type) : !1) || e.tag === 4;
			}
			function xu(e) {
				e: for (;;) {
					for (; e.sibling === null;) {
						if (e.return === null || bd(e.return)) return null;
						e = e.return;
					}
					for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
						if (je && e.tag === 27 && t(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue e;
						e.child.return = e, e = e.child;
					}
					if (!(e.flags & 2)) return e.stateNode;
				}
			}
			function Cu(e, n, o, i) {
				var s = e.tag;
				if (s === 5 || s === 6) s = e.stateNode, n ? mr(o, s, n) : Ri(o, s), Ia(e, i), jt = !0;
				else if (s !== 4 && (je && s === 27 && (Ia(e, i), i = null, t(e.type) && (o = e.stateNode, n = null)), e = e.child, e !== null)) for (Cu(e, n, o, i), e = e.sibling; e !== null;) Cu(e, n, o, i), e = e.sibling;
			}
			function Fl(e, n, o, i) {
				var s = e.tag;
				if (s === 5 || s === 6) s = e.stateNode, n ? zg(o, s, n) : Ad(o, s), Ia(e, i), jt = !0;
				else if (s !== 4 && (je && s === 27 && (Ia(e, i), i = null, t(e.type) && (o = e.stateNode)), e = e.child, e !== null)) for (Fl(e, n, o, i), e = e.sibling; e !== null;) Fl(e, n, o, i), e = e.sibling;
			}
			function Ra(e) {
				for (var n, o = e.return; o !== null;) {
					if (bd(o)) {
						n = o;
						break;
					}
					o = o.return;
				}
				o = null;
				for (var i = e.return; i !== null;) {
					if (Pu(i)) {
						var s = i.stateNode;
						o === null ? o = [s] : o.push(s);
					}
					if (md(i)) break;
					i = i.return;
				}
				if (_e) {
					if (n == null) throw Error("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.");
					switch (n.tag) {
						case 27: if (je) {
							n = n.stateNode, i = xu(e), Fl(e, i, n, o);
							break;
						}
						case 5:
							i = n.stateNode, n.flags & 32 && (na(i), n.flags &= -33), n = xu(e), Fl(e, n, i, o);
							break;
						case 3:
						case 4:
							n = n.stateNode.containerInfo, i = xu(e), Cu(e, i, n, o);
							break;
						default: throw Error("Invalid host parent fiber. This error is likely caused by a bug in React. Please file an issue.");
					}
				} else zu(e, o);
			}
			function zu(e, n) {
				if (e.tag === 5 || je && e.tag === 27) Ia(e, n);
				else if (e.tag !== 4 && (e = e.child, e !== null)) for (zu(e, n), e = e.sibling; e !== null;) zu(e, n), e = e.sibling;
			}
			function Nm(e, n, o) {
				e = e.containerInfo;
				try {
					B(n, Rt, e, o);
				} catch (i) {
					we(n, n.return, i);
				}
			}
			function Tm(e) {
				var n = e.stateNode, o = e.memoizedProps;
				try {
					B(e, ts, e.type, o, n, e);
				} catch (i) {
					we(e, e.return, i);
				}
			}
			function yd(e) {
				(e.tag === 30 || e.subtreeFlags & 33554432) && (Yg = !0);
			}
			function Im() {
				var e = Xa;
				return Xa = null, e;
			}
			function ki(e, n, o, i, s) {
				return yr = 0, (n = Fp(e.child, n, o, i, s)) && e._debugTask != null && br === null && (br = e._debugTask), n;
			}
			function Fp(e, n, o, i, s) {
				if (!_e) return !1;
				for (var u = !1; e !== null;) {
					if (e.tag === 5) {
						var f = e.stateNode;
						if (i !== null) {
							var p = un(f);
							i.push(p), ra(p) && (u = !0);
						} else u || ra(un(f)) && (u = !0);
						Yg = !0, lt(f, yr === 0 ? n : n + "_" + yr, o), yr++;
					} else (e.tag !== 22 || e.memoizedState === null) && (e.tag === 30 && s || Fp(e.child, n, o, i, s) && (u = !0));
					e = e.sibling;
				}
				return u;
			}
			function Po(e, n) {
				if (_e) for (; e !== null;) e.tag === 5 ? Xn(e.stateNode, e.memoizedProps) : (e.tag !== 22 || e.memoizedState === null) && (e.tag === 30 && n || Po(e.child, n)), e = e.sibling;
			}
			function wi(e) {
				if ((e.subtreeFlags & 18874368) !== 0) for (e = e.child; e !== null;) {
					if ((e.tag !== 22 || e.memoizedState === null) && (wi(e), e.tag === 30 && (e.flags & 18874368) !== 0 && e.stateNode.paired)) {
						var n = e.memoizedProps;
						if (n.name == null || n.name === "auto") throw Error("Found a pair with an auto name. This is a bug in React.");
						var o = n.name;
						n = er(n.default, n.share), n !== "none" && (ki(e, o, n, null, !1) || Po(e.child, !1));
					}
					e = e.sibling;
				}
			}
			function Q(e, n) {
				if (e.tag === 30) {
					var o = e.stateNode, i = e.memoizedProps, s = Mn(i, o), u = er(i.default, o.paired ? i.share : i.enter);
					u !== "none" ? ki(e, s, u, null, !1) ? (wi(e), o.paired || n || Al(e, i.onEnter)) : Po(e.child, !1) : wi(e);
				} else if ((e.subtreeFlags & 33554432) !== 0) for (e = e.child; e !== null;) Q(e, n), e = e.sibling;
				else wi(e);
			}
			function Dp(e) {
				if (no !== null && no.size !== 0) {
					var n = no;
					if ((e.subtreeFlags & 18874368) !== 0) for (e = e.child; e !== null;) {
						if (e.tag !== 22 || e.memoizedState === null) {
							if (e.tag === 30 && (e.flags & 18874368) !== 0) {
								var o = e.memoizedProps, i = o.name;
								if (i != null && i !== "auto") {
									var s = n.get(i);
									if (s !== void 0) {
										var u = er(o.default, o.share);
										if (u !== "none" && (ki(e, i, u, null, !1) ? (u = e.stateNode, s.paired = u, u.paired = s, Al(e, o.onShare)) : Po(e.child, !1)), n.delete(i), n.size === 0) break;
									}
								}
							}
							Dp(e);
						}
						e = e.sibling;
					}
				}
			}
			function jp(e) {
				if (e.tag === 30) {
					var n = e.memoizedProps, o = Mn(n, e.stateNode), i = no !== null ? no.get(o) : void 0, s = er(n.default, i !== void 0 ? n.share : n.exit);
					s !== "none" && (ki(e, o, s, null, !1) ? i !== void 0 ? (s = e.stateNode, i.paired = s, s.paired = i, no.delete(o), Al(e, n.onShare)) : Al(e, n.onExit) : Po(e.child, !1)), no !== null && Dp(e);
				} else if ((e.subtreeFlags & 33554432) !== 0) for (e = e.child; e !== null;) jp(e), e = e.sibling;
				else no !== null && Dp(e);
			}
			function Up(e) {
				for (e = e.child; e !== null;) {
					if (e.tag === 30) {
						var n = e.memoizedProps, o = Mn(n, e.stateNode);
						n = er(n.default, n.update), e.flags &= -5, n !== "none" && ki(e, o, n, e.memoizedState = [], !1);
					} else e.subtreeFlags & 33554432 && Up(e);
					e = e.sibling;
				}
			}
			function Pi(e) {
				if ((e.subtreeFlags & 18874368) !== 0) for (e = e.child; e !== null;) {
					if (e.tag !== 22 || e.memoizedState === null) {
						if (e.tag === 30 && (e.flags & 18874368) !== 0) {
							var n = e.stateNode;
							n.paired !== null && (n.paired = null, Po(e.child, !1));
						}
						Pi(e);
					}
					e = e.sibling;
				}
			}
			function vd(e) {
				if (e.tag === 30) e.stateNode.paired = null, Po(e.child, !1), Pi(e);
				else if ((e.subtreeFlags & 33554432) !== 0) for (e = e.child; e !== null;) vd(e), e = e.sibling;
				else Pi(e);
			}
			function Rm(e) {
				for (e = e.child; e !== null;) e.tag === 30 ? Po(e.child, !1) : e.subtreeFlags & 33554432 && Rm(e), e = e.sibling;
			}
			function Wp(e, n, o, i, s, u, f) {
				if (!_e) return !1;
				for (var p = !1; n !== null;) {
					if (n.tag === 5) {
						var g = n.stateNode;
						if (u !== null && yr < u.length) {
							var b = u[yr], k = un(g);
							(ra(b) || ra(k)) && (p = !0), !(e.flags & 4) && Fi(b, k) && (e.flags |= 4), Hd(b, k) && (e.flags |= 32);
						} else e.flags |= 32;
						e.flags & 4 && lt(g, yr === 0 ? o : o + "_" + yr, s), p && e.flags & 4 || (Xa === null && (Xa = []), Xa.push(g, yr === 0 ? i : i + "_" + yr, n.memoizedProps)), yr++;
					} else (n.tag !== 22 || n.memoizedState === null) && (n.tag === 30 && f ? e.flags |= n.flags & 32 : Wp(e, n.child, o, i, s, u, f) && (p = !0));
					n = n.sibling;
				}
				return p;
			}
			function Lm(e, n) {
				for (e = e.child; e !== null;) {
					if (e.tag === 30) {
						var o = e.memoizedProps, i = e.stateNode, s = Mn(o, i), u = er(o.default, o.update);
						if (n) {
							i = i.clones;
							var f = i === null ? null : i.map(Bd);
						} else f = e.memoizedState, e.memoizedState = null;
						i = e;
						var p = e.child, g = s;
						yr = 0, u = Wp(i, p, g, s, u, f, !1), e.flags & 4 && u && (n || Al(e, o.onUpdate));
					} else e.subtreeFlags & 33554432 && Lm(e, n);
					e = e.sibling;
				}
			}
			function Fm(e) {
				var n = e.memoizedProps.name;
				if (n != null && n !== "auto") {
					var o = Kg.get(n);
					if (o !== void 0) {
						if (o !== e && o !== e.alternate && !Jy[n]) {
							Jy[n] = !0;
							var i = JSON.stringify(n);
							B(e, function() {
								console.error("There are two <ViewTransition name=%s> components with the same name mounted at the same time. This is not supported and will cause View Transitions to error. Try to use a more unique name e.g. by using a namespace prefix and adding the id of an item to the name.", i);
							}), B(o, function() {
								console.error("The existing <ViewTransition name=%s> duplicate has this stack trace.", i);
							});
						}
					} else Kg.set(n, e);
				}
			}
			function Sd(e) {
				var n = e.memoizedProps.name;
				if (n != null && n !== "auto") {
					var o = Kg.get(n);
					o === void 0 || o !== e && o !== e.alternate || Kg.delete(n);
				}
			}
			function Ap(e, n) {
				return n.tag === 31 ? (n = n.memoizedState, e.memoizedState !== null && n === null) : n.tag === 13 ? (e = e.memoizedState, n = n.memoizedState, e !== null && e.dehydrated !== null && (n === null || n.dehydrated === null)) : n.tag === 3 ? e.memoizedState.isDehydrated && (n.flags & 256) === 0 : !1;
			}
			function kd(e, n, o) {
				for (W0(e.containerInfo), e = (o & 335544064) === o, dt = n, n = e ? 9270 : 1024; dt !== null;) {
					if (o = dt, e) {
						var i = o.deletions;
						if (i !== null) for (var s = 0; s < i.length; s++) e && jp(i[s]);
					}
					if (o.alternate === null && (o.flags & 2) !== 0) e && yd(o), Eu(e);
					else {
						if (o.tag === 22) {
							if (i = o.alternate, o.memoizedState !== null) {
								i !== null && i.memoizedState === null && e && jp(i), Eu(e);
								continue;
							} else if (i !== null && i.memoizedState !== null) {
								e && yd(o), Eu(e);
								continue;
							}
						}
						i = o.child, (o.subtreeFlags & n) !== 0 && i !== null ? (i.return = o, dt = i) : (e && Up(o), Eu(e));
					}
				}
				no = null;
			}
			function Eu(e) {
				for (; dt !== null;) {
					var n = dt, o = n, i = e, s = o.alternate, u = o.flags;
					switch (o.tag) {
						case 0:
						case 11:
						case 15: break;
						case 1:
							u & 1024 && s !== null && Em(o, s);
							break;
						case 3:
							u & 1024 && _e && Eg(o.stateNode.containerInfo);
							break;
						case 5:
						case 26:
						case 27:
						case 6:
						case 4:
						case 17: break;
						case 30:
							i && s !== null && (i = s, s = o, o = Mn(i.memoizedProps, i.stateNode), s = s.memoizedProps, s = er(s.default, s.update), s !== "none" && ki(i, o, s, i.memoizedState = [], !0));
							break;
						default: if ((u & 1024) !== 0) throw Error("This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
					}
					if (i = n.sibling, i !== null) {
						i.return = n.return, dt = i;
						break;
					}
					dt = n.return;
				}
			}
			function Dm(e, n, o) {
				var i = Pt(), s = Ir(), u = Rr(), f = Lr(), p = o.flags;
				switch (o.tag) {
					case 0:
					case 11:
					case 15:
						ur(e, o), p & 4 && Na(o, eo | Ro);
						break;
					case 1:
						if (ur(e, o), p & 4) if (e = o.stateNode, n === null) o.type.defaultProps || "ref" in o.memoizedProps || bf || (e.props !== o.memoizedProps && console.error("Expected %s props to match memoized props before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", G(o) || "instance"), e.state !== o.memoizedState && console.error("Expected %s state to match memoized state before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", G(o) || "instance")), Vt(o) ? (Dr(), B(o, ub, o, e), Fr()) : B(o, ub, o, e);
						else {
							var g = Ca(o.type, n.memoizedProps);
							n = n.memoizedState, o.type.defaultProps || "ref" in o.memoizedProps || bf || (e.props !== o.memoizedProps && console.error("Expected %s props to match memoized props before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", G(o) || "instance"), e.state !== o.memoizedState && console.error("Expected %s state to match memoized state before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", G(o) || "instance")), Vt(o) ? (Dr(), B(o, uy, o, e, g, n, e.__reactInternalSnapshotBeforeUpdate), Fr()) : B(o, uy, o, e, g, n, e.__reactInternalSnapshotBeforeUpdate);
						}
						p & 64 && Tp(o), p & 512 && Y(o, o.return);
						break;
					case 3:
						if (n = mo(), ur(e, o), p & 64 && (p = o.updateQueue, p !== null)) {
							if (g = null, o.child !== null) switch (o.child.tag) {
								case 27:
								case 5:
									g = Ql(o.child.stateNode);
									break;
								case 1: g = o.child.stateNode;
							}
							try {
								B(o, rp, p, g);
							} catch (k) {
								we(o, o.return, k);
							}
						}
						e.effectDuration += Us(n);
						break;
					case 27: je && n === null && p & 4 && Tm(o);
					case 26:
					case 5:
						if (ur(e, o), n === null) {
							if (p & 4) gd(o);
							else if (p & 64) {
								e = o.type, n = o.memoizedProps, g = o.stateNode;
								try {
									B(o, Be, g, e, n, o);
								} catch (k) {
									we(o, o.return, k);
								}
							}
						}
						p & 512 && Y(o, o.return);
						break;
					case 12:
						if (p & 4) {
							p = mo(), ur(e, o), e = o.stateNode, e.effectDuration += hl(p);
							try {
								B(o, Et, o, n, Hi, e.effectDuration);
							} catch (k) {
								we(o, o.return, k);
							}
						} else ur(e, o);
						break;
					case 31:
						ur(e, o), p & 4 && jm(e, o);
						break;
					case 13:
						ur(e, o), p & 4 && Um(e, o), p & 64 && (e = o.memoizedState, e !== null && (e = e.dehydrated, e !== null && (p = _0.bind(null, o), Sh(e, p))));
						break;
					case 22:
						if (p = o.memoizedState !== null || ct, !p) {
							var b = n !== null && n.memoizedState !== null || We;
							n = ct, g = We, ct = p, (We = b) && !g ? (p = je ? e0 : ac, o.subtreeFlags & 8772 && (p |= Cb), cr(e, o, p), (o.mode & 2) !== Z && 0 <= V && 0 <= J && .05 < J - V && so(o, V, J)) : ur(e, o), ct = n, We = g;
						}
						break;
					case 30:
						p & 18874368 && Fm(o), ur(e, o), p & 512 && Y(o, o.return);
						break;
					case 7: p & 512 && Y(o, o.return);
					default: ur(e, o);
				}
				(o.mode & 2) !== Z && 0 <= V && 0 <= J && ((Sn || .05 < dn) && Me(o, V, J, dn, on), o.alternate === null && o.return !== null && o.return.alternate !== null && .05 < J - V && (Ap(o.return.alternate, o.return) || nr(o, V, J, "Mount"))), gt(i), go(s), on = u, Sn = f;
			}
			function Op(e, n) {
				if (_e) for (e = e.child; e !== null;) La(e, n), e = e.sibling;
			}
			function La(e, n) {
				if (_e) switch (e.tag) {
					case 5:
					case 26:
						try {
							var o = e.stateNode;
							n ? B(e, yh, o) : B(e, Od, e.stateNode, e.memoizedProps);
						} catch (u) {
							we(e, e.return, u);
						}
						lr(e, n);
						break;
					case 6:
						try {
							var i = e.stateNode;
							n ? B(e, Ba, i) : B(e, Zn, i, e.memoizedProps), jt = !0;
						} catch (u) {
							we(e, e.return, u);
						}
						break;
					case 18:
						try {
							var s = e.stateNode;
							n ? B(e, oa, s) : B(e, cn, e.stateNode);
						} catch (u) {
							we(e, e.return, u);
						}
						break;
					case 22:
					case 23:
						e.memoizedState === null && Op(e, n);
						break;
					default: Op(e, n);
				}
			}
			function lr(e, n) {
				if (_e && e.subtreeFlags & 67108864) for (e = e.child; e !== null;) {
					var o = e, i = n;
					if (_e) switch (o.tag) {
						case 4:
							La(o, i);
							break;
						case 22:
							o.memoizedState === null && lr(o, i);
							break;
						default: lr(o, i);
					}
					e = e.sibling;
				}
			}
			function Ye(e) {
				var n = e.alternate;
				n !== null && (e.alternate = null, Ye(n)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (n = e.stateNode, n !== null && hh(n)), e.stateNode = null, e._debugOwner = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
			}
			function ln(e, n, o) {
				for (o = o.child; o !== null;) En(e, n, o), o = o.sibling;
			}
			function En(e, n, o) {
				if (M && typeof M.onCommitFiberUnmount == "function") try {
					M.onCommitFiberUnmount(Ue, o);
				} catch (b) {
					ie || (ie = !0, console.error("React instrumentation encountered an error: %o", b));
				}
				var i = Pt(), s = Ir(), u = Rr(), f = Lr();
				switch (o.tag) {
					case 26: if (Ze) {
						We || $n(o, n), ln(e, n, o), o.memoizedState ? $u(o.memoizedState) : o.stateNode && (We || qt(o.stateNode));
						break;
					}
					case 27: if (je) {
						We || $n(o, n), wo(o);
						var p = Bn, g = vr;
						t(o.type) && (Bn = o.stateNode, vr = !1), ln(e, n, o), B(o, rs, o.stateNode, o.type, o.memoizedProps), Bn = p, vr = g;
						break;
					}
					case 5: We || $n(o, n), wo(o);
					case 6:
						if (o.tag === 6 && wo(o), _e) {
							if (p = Bn, g = vr, Bn = null, ln(e, n, o), Bn = p, vr = g, Bn !== null) if (vr) try {
								B(o, bh, Bn, o.stateNode), jt = !0;
							} catch (b) {
								we(o, n, b);
							}
							else try {
								B(o, Xl, Bn, o.stateNode), jt = !0;
							} catch (b) {
								we(o, n, b);
							}
						} else ln(e, n, o);
						break;
					case 18:
						_e && Bn !== null && (vr ? wh(Bn, o.stateNode) : Kl(Bn, o.stateNode));
						break;
					case 4:
						_e ? (p = Bn, g = vr, Bn = o.stateNode.containerInfo, vr = !0, ln(e, n, o), Bn = p, vr = g) : (_n && Nm(o.stateNode, o, Vd()), ln(e, n, o));
						break;
					case 0:
					case 11:
					case 14:
					case 15:
						Ta(Xt, o, n), We || wu(o, n, eo), ln(e, n, o);
						break;
					case 1:
						We || ($n(o, n), p = o.stateNode, typeof p.componentWillUnmount == "function" && Ip(o, n, p)), ln(e, n, o);
						break;
					case 21:
						ln(e, n, o);
						break;
					case 22:
						We = (p = We) || o.memoizedState !== null, ln(e, n, o), We = p;
						break;
					case 30:
						o.flags & 18874368 && Sd(o), $n(o, n), ln(e, n, o);
						break;
					case 7:
						We || $n(o, n), ln(e, n, o);
						break;
					default: ln(e, n, o);
				}
				(o.mode & 2) !== Z && 0 <= V && 0 <= J && (Sn || .05 < dn) && Me(o, V, J, dn, on), gt(i), go(s), on = u, Sn = f;
			}
			function jm(e, n) {
				if ($e && n.memoizedState === null && (e = n.alternate, e !== null && (e = e.memoizedState, e !== null))) {
					e = e.dehydrated;
					try {
						B(n, ye, e);
					} catch (o) {
						we(n, n.return, o);
					}
				}
			}
			function Um(e, n) {
				if ($e && n.memoizedState === null && (e = n.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
					B(n, Ie, e);
				} catch (o) {
					we(n, n.return, o);
				}
			}
			function jn(e) {
				switch (e.tag) {
					case 31:
					case 13:
					case 19:
						var n = e.stateNode;
						return n === null && (n = e.stateNode = new Zy()), n;
					case 22: return e = e.stateNode, n = e._retryCache, n === null && (n = e._retryCache = new Zy()), n;
					default: throw Error("Unexpected Suspense handler tag (" + e.tag + "). This is a bug in React.");
				}
			}
			function sr(e, n) {
				var o = jn(e);
				n.forEach(function(i) {
					if (!o.has(i)) {
						if (o.add(i), Le) if (yf !== null && vf !== null) Ru(vf, yf);
						else throw Error("Expected finished root and lanes to be set. This is a bug in React.");
						var s = N0.bind(null, e, i);
						i.then(s, s);
					}
				});
			}
			function Qn(e, n, o) {
				var i = n.deletions;
				if (i !== null) for (var s = 0; s < i.length; s++) {
					var u = e, f = n, p = i[s], g = Pt();
					if (_e) {
						var b = f;
						e: for (; b !== null;) {
							switch (b.tag) {
								case 27: if (je) {
									if (t(b.type)) {
										Bn = b.stateNode, vr = !1;
										break e;
									}
									break;
								}
								case 5:
									Bn = b.stateNode, vr = !1;
									break e;
								case 3:
								case 4:
									Bn = b.stateNode.containerInfo, vr = !0;
									break e;
							}
							b = b.return;
						}
						if (Bn === null) throw Error("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.");
						En(u, f, p), Bn = null, vr = !1;
					} else En(u, f, p);
					(p.mode & 2) !== Z && 0 <= V && 0 <= J && .05 < J - V && nr(p, V, J, "Unmount"), gt(g), u = p, f = u.alternate, f !== null && (f.return = null), u.return = null;
				}
				if (n.subtreeFlags & 13886) for (n = n.child; n !== null;) Wm(n, e, o), n = n.sibling;
			}
			function Wm(e, n, o) {
				var i = Pt(), s = Ir(), u = Rr(), f = Lr(), p = e.alternate, g = e.flags;
				switch (e.tag) {
					case 0:
					case 11:
					case 14:
					case 15:
						if (g & 4 && (p = e.updateQueue, p = p !== null ? p.events : null, p !== null)) for (var b = 0; b < p.length; b++) {
							var k = p[b];
							k.ref.impl = k.nextImpl;
						}
						Qn(n, e, o), it(e), g & 4 && (Ta(Xt | Ro, e, e.return), Ll(Xt | Ro, e), wu(e, e.return, eo | Ro));
						break;
					case 1:
						Qn(n, e, o), it(e), g & 512 && (We || p === null || $n(p, p.return)), g & 64 && ct && (n = e.updateQueue, n !== null && (g = n.callbacks, g !== null && (o = n.shared.hiddenCallbacks, n.shared.hiddenCallbacks = o === null ? g : o.concat(g))));
						break;
					case 26: if (Ze) {
						b = fa, Qn(n, e, o), it(e), g & 512 && (We || p === null || $n(p, p.return)), g & 4 && (o = p !== null ? p.memoizedState : null, g = e.memoizedState, p === null ? g === null ? e.stateNode === null ? e.stateNode = ct ? $a(e.type, e.memoizedProps, n.containerInfo, e) : Va(b, e.type, e.memoizedProps, e) : ct || Xe(b, e.type, e.stateNode) : e.stateNode = ns(b, g, e.memoizedProps) : o !== g ? (o === null ? (n = p.stateNode, n === null || We || qt(n)) : $u(o), g === null ? ct || Xe(b, e.type, e.stateNode) : ns(b, g, e.memoizedProps)) : g === null && e.stateNode !== null && Vr(e, e.memoizedProps, p.memoizedProps));
						break;
					}
					case 27: if (je) {
						Qn(n, e, o), it(e), g & 512 && (We || p === null || $n(p, p.return)), p !== null && g & 4 && Vr(e, e.memoizedProps, p.memoizedProps);
						break;
					}
					case 5:
						if (b = Ya, Ya = !1, Qn(n, e, o), Ya = b, it(e), g & 512 && (We || p === null || $n(p, p.return)), _e) {
							if (e.flags & 32) {
								n = e.stateNode;
								try {
									B(e, na, n), jt = !0;
								} catch ($) {
									we(e, e.return, $);
								}
							}
							g & 4 && e.stateNode != null && (n = e.memoizedProps, Vr(e, n, p !== null ? p.memoizedProps : n)), g & 1024 && (zb = !0, e.type !== "form" && console.error("Unexpected host component type. Expected a form. This is a bug in React."));
						} else _n && e.alternate !== null && (e.alternate.stateNode = e.stateNode);
						break;
					case 6:
						if (Qn(n, e, o), it(e), g & 4 && _e) {
							if (e.stateNode === null) throw Error("This should have a text node initialized. This error is likely caused by a bug in React. Please file an issue.");
							n = e.memoizedProps, g = p !== null ? p.memoizedProps : n, o = e.stateNode;
							try {
								B(e, Zl, o, g, n), jt = !0;
							} catch ($) {
								we(e, e.return, $);
							}
						}
						break;
					case 3:
						if (b = mo(), jt = !1, Ze ? (zo(), k = fa, fa = ji(n.containerInfo), Qn(n, e, o), fa = k) : Qn(n, e, o), it(e), g & 4) {
							if (_e && $e && p !== null && p.memoizedState.isDehydrated) try {
								B(e, he, n.containerInfo);
							} catch ($) {
								we(e, e.return, $);
							}
							if (_n) {
								g = n.containerInfo, o = n.pendingChildren;
								try {
									B(e, Rt, g, o), jt = !0;
								} catch ($) {
									we(e, e.return, $);
								}
							}
						}
						zb && (zb = !1, Am(e)), n.effectDuration += Us(b), jt = !1;
						break;
					case 4:
						p = Ya, Ya = ct, b = _m(), Ze ? (k = fa, fa = ji(e.stateNode.containerInfo), Qn(n, e, o), it(e), fa = k) : (Qn(n, e, o), it(e)), jt && qh && (n0 = !0), jt = b, Ya = p, g & 4 && _n && Nm(e.stateNode, e, e.stateNode.pendingChildren);
						break;
					case 12:
						g = mo(), Qn(n, e, o), it(e), e.stateNode.effectDuration += hl(g);
						break;
					case 31:
						Qn(n, e, o), it(e), g & 4 && (n = e.updateQueue, n !== null && (e.updateQueue = null, sr(e, n)));
						break;
					case 13:
						Qn(n, e, o), it(e), e.child.flags & 8192 && e.memoizedState !== null != (p !== null && p.memoizedState !== null) && (f0 = Re()), g & 4 && (n = e.updateQueue, n !== null && (e.updateQueue = null, sr(e, n)));
						break;
					case 22:
						b = e.memoizedState !== null, k = p !== null && p.memoizedState !== null;
						var z = ct, T = We, H = Ya;
						ct = z || b, Ya = H || b, We = T || k, Qn(n, e, o), We = T, Ya = H, ct = z, k && !b && !z && !T && (e.mode & 2) !== Z && 0 <= V && 0 <= J && .05 < J - V && so(e, V, J), it(e), g & 8192 && (n = e.stateNode, n._visibility = b ? n._visibility & ~Hh : n._visibility | Hh, !b || p === null || k || ct || We || (n = je ? e0 : ac, o = k || We, p = ct, k = We, ct = b || ct, We = o, Xo(e, n), (e.mode & 2) !== Z && 0 <= V && 0 <= J && .05 < J - V && nr(e, V, J, "Disconnect"), ct = p, We = k), _e && (b || !Ya) && Op(e, b)), g & 4 && (n = e.updateQueue, n !== null && (g = n.retryQueue, g !== null && (n.retryQueue = null, sr(e, g))));
						break;
					case 19:
						Qn(n, e, o), it(e), g & 4 && (n = e.updateQueue, n !== null && (e.updateQueue = null, sr(e, n)));
						break;
					case 30:
						g & 512 && (We || p === null || $n(p, p.return)), g = _m(), b = qh, k = (o & 335544064) === o, z = e.memoizedProps, qh = k && er(z.default, z.update) !== "none", Qn(n, e, o), it(e), k && p !== null && jt && (e.flags |= 4), qh = b, jt = g;
						break;
					case 21: break;
					case 7: g & 512 && (We || p === null || $n(p, p.return)), p && p.stateNode !== null && B0(e, p.stateNode);
					default: Qn(n, e, o), it(e);
				}
				(e.mode & 2) !== Z && 0 <= V && 0 <= J && ((Sn || .05 < dn) && Me(e, V, J, dn, on), e.alternate === null && e.return !== null && e.return.alternate !== null && .05 < J - V && (Ap(e.return.alternate, e.return) || nr(e, V, J, "Mount"))), gt(i), go(s), on = u, Sn = f;
			}
			function it(e) {
				var n = e.flags;
				if (n & 2) {
					try {
						B(e, Ra, e);
					} catch (o) {
						we(e, e.return, o);
					}
					e.flags &= -3;
				}
				n & 4096 && (e.flags &= -4097);
			}
			function Am(e) {
				if (e.subtreeFlags & 1024) for (e = e.child; e !== null;) {
					var n = e;
					Am(n), n.tag === 5 && n.flags & 1024 && Ud(n.stateNode), e = e.sibling;
				}
			}
			function Dl(e, n) {
				if (n.subtreeFlags & 9270) for (n = n.child; n !== null;) wd(n, e), n = n.sibling;
				else Lm(n, !1);
			}
			function wd(e, n) {
				var o = e.alternate;
				if (o === null) Q(e, !1);
				else switch (e.tag) {
					case 3:
						if (Eb = Ka = !1, Im(), Dl(n, e), !Ka && !n0) {
							if (e = Xa, e !== null) for (var i = 0; i < e.length; i += 3) ta(e[i], e[i + 1], e[i + 2]);
							re(n.containerInfo), Eb = !0;
						}
						Xa = null;
						break;
					case 5:
						Dl(n, e);
						break;
					case 4:
						i = Ka, Ka = !1, Dl(n, e), Ka && (n0 = !0), Ka = i;
						break;
					case 22:
						e.memoizedState === null && (o.memoizedState !== null ? Q(e, !1) : Dl(n, e));
						break;
					case 30:
						i = Ka;
						var s = Im();
						Ka = !1, Dl(n, e), Ka && (e.flags |= 4);
						var u = e.memoizedProps, f = e.stateNode;
						n = Mn(u, f), f = Mn(o.memoizedProps, f);
						var p = er(u.default, u.update);
						p === "none" ? o = !1 : (u = o.memoizedState, o.memoizedState = null, o = e.child, yr = 0, o = Wp(e, o, n, f, p, u, !0), yr !== (u === null ? 0 : u.length) && (e.flags |= 32)), (e.flags & 4) !== 0 && o ? (Al(e, e.memoizedProps.onUpdate), Xa = s) : s !== null && (s.push.apply(s, Xa), Xa = s), Ka = (e.flags & 32) !== 0 ? !0 : i;
						break;
					default: Dl(n, e);
				}
			}
			function ur(e, n) {
				if (n.subtreeFlags & 8772) for (n = n.child; n !== null;) Dm(e, n.alternate, n), n = n.sibling;
			}
			function Om(e, n) {
				var o = Pt(), i = Ir(), s = Rr(), u = Lr();
				switch (e.tag) {
					case 0:
					case 11:
					case 14:
					case 15:
						wu(e, e.return, eo), Xo(e, n);
						break;
					case 1:
						$n(e, e.return);
						var f = e.stateNode;
						typeof f.componentWillUnmount == "function" && Ip(e, e.return, f), Xo(e, n);
						break;
					case 27: je && (n & e0) !== ac && B(e, rs, e.stateNode, e.type, e.memoizedProps);
					case 5:
						$n(e, e.return), e.tag !== 5 && e.tag !== 27 || wo(e), Xo(e, n);
						break;
					case 6:
						wo(e);
						break;
					case 26:
						$n(e, e.return), Ze && (f = e.stateNode, e.memoizedState !== null || f === null || We || qt(f)), Xo(e, n);
						break;
					case 22:
						e.memoizedState === null && Xo(e, n);
						break;
					case 30:
						e.flags & 18874368 && Sd(e), $n(e, e.return), Xo(e, n);
						break;
					case 7: $n(e, e.return);
					default: Xo(e, n);
				}
				(e.mode & 2) !== Z && 0 <= V && 0 <= J && (Sn || .05 < dn) && Me(e, V, J, dn, on), gt(o), go(i), on = s, Sn = u;
			}
			function Xo(e, n) {
				for (e = e.child; e !== null;) Om(e, n), e = e.sibling;
			}
			function Bm(e, n, o, i) {
				var s = Pt(), u = Ir(), f = Rr(), p = Lr(), g = o.flags, b = (i & Cb) !== ac;
				switch (o.tag) {
					case 0:
					case 11:
					case 15:
						cr(e, o, i), Na(o, eo);
						break;
					case 1:
						if (cr(e, o, i), n = o.stateNode, typeof n.componentDidMount == "function" && B(o, ub, o, n), n = o.updateQueue, n !== null) {
							e = o.stateNode;
							try {
								B(o, tp, n, e);
							} catch (z) {
								we(o, o.return, z);
							}
						}
						b && g & 64 && Tp(o), Y(o, o.return);
						break;
					case 27: je && (i & e0) !== ac && Tm(o);
					case 5:
						o.tag !== 5 && o.tag !== 27 || Si(o), cr(e, o, i), b && n === null && g & 4 && gd(o), Y(o, o.return);
						break;
					case 6:
						Si(o);
						break;
					case 26:
						if (Ze) {
							var k = o.stateNode;
							o.memoizedState !== null || k === null || ct || Xe(ji(k.ownerDocument), o.type, k);
						}
						cr(e, o, i), b && n === null && g & 4 && gd(o), Y(o, o.return);
						break;
					case 12:
						if (b && g & 4) {
							g = mo(), cr(e, o, i), b = o.stateNode, b.effectDuration += hl(g);
							try {
								B(o, Et, o, n, Hi, b.effectDuration);
							} catch (z) {
								we(o, o.return, z);
							}
						} else cr(e, o, i);
						break;
					case 31:
						cr(e, o, i), b && g & 4 && jm(e, o);
						break;
					case 13:
						cr(e, o, i), b && g & 4 && Um(e, o);
						break;
					case 22:
						o.memoizedState === null && cr(e, o, i), Y(o, o.return);
						break;
					case 30:
						cr(e, o, i), g & 18874368 && Fm(o), Y(o, o.return);
						break;
					case 7: Y(o, o.return);
					default: cr(e, o, i);
				}
				(o.mode & 2) !== Z && 0 <= V && 0 <= J && (Sn || .05 < dn) && Me(o, V, J, dn, on), gt(s), go(u), on = f, Sn = p;
			}
			function cr(e, n, o) {
				for (o = (n.subtreeFlags & 8772) !== 0 ? o : o & ~Cb, n = n.child; n !== null;) Bm(e, n.alternate, n, o), n = n.sibling;
			}
			function Fa(e, n) {
				var o = null;
				e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (o = e.memoizedState.cachePool.pool), e = null, n.memoizedState !== null && n.memoizedState.cachePool !== null && (e = n.memoizedState.cachePool.pool), e !== o && (e != null && Mo(e), o != null && Bt(o));
			}
			function $r(e, n) {
				e = null, n.alternate !== null && (e = n.alternate.memoizedState.cache), n = n.memoizedState.cache, n !== e && (Mo(n), e != null && Bt(e));
			}
			function dr(e, n, o, i, s) {
				var u = (o & 335544064) === o;
				if (n.subtreeFlags & (u ? 10262 : 10256) || n.actualDuration !== 0 && (n.alternate === null || n.alternate.child !== n.child)) for (n = n.child; n !== null;) u = n.sibling, Hm(e, n, o, i, u !== null ? u.actualStartTime : s), n = u;
				else u && Rm(n);
			}
			function Hm(e, n, o, i, s) {
				var u = Pt(), f = Ir(), p = Rr(), g = Lr(), b = os, k = (o & 335544064) === o;
				k && n.alternate === null && n.return !== null && n.return.alternate !== null && vd(n);
				var z = n.flags;
				switch (n.tag) {
					case 0:
					case 11:
					case 15:
						(n.mode & 2) !== Z && 0 < n.actualStartTime && n.flags & 1 && oi(n, n.actualStartTime, s, Kn, o), dr(e, n, o, i, s), z & 2048 && Cm(n, Dt | Ro);
						break;
					case 1:
						(n.mode & 2) !== Z && 0 < n.actualStartTime && ((n.flags & 128) !== 0 ? Do(n, n.actualStartTime, s, []) : n.flags & 1 && oi(n, n.actualStartTime, s, Kn, o)), dr(e, n, o, i, s);
						break;
					case 3:
						var T = mo(), H = Kn;
						Kn = n.alternate !== null && n.alternate.memoizedState.isDehydrated && (n.flags & 256) === 0, dr(e, n, o, i, s), Kn = H, k && _e && Eb && De(e.containerInfo), z & 2048 && (o = null, n.alternate !== null && (o = n.alternate.memoizedState.cache), i = n.memoizedState.cache, i !== o && (Mo(i), o != null && Bt(o))), e.passiveEffectDuration += Us(T);
						break;
					case 12:
						if (z & 2048) {
							z = mo(), dr(e, n, o, i, s), e = n.stateNode, e.passiveEffectDuration += hl(z);
							try {
								B(n, Lp, n, n.alternate, Hi, e.passiveEffectDuration);
							} catch ($) {
								we(n, n.return, $);
							}
						} else dr(e, n, o, i, s);
						break;
					case 31:
						z = Kn, k = n.alternate !== null ? n.alternate.memoizedState : null, T = n.memoizedState, k !== null && T === null ? (T = n.deletions, T !== null && 0 < T.length && T[0].tag === 18 ? (Kn = !1, k = k.hydrationErrors, k !== null && Do(n, n.actualStartTime, s, k)) : Kn = !0) : Kn = !1, dr(e, n, o, i, s), Kn = z;
						break;
					case 13:
						z = Kn, k = n.alternate !== null ? n.alternate.memoizedState : null, T = n.memoizedState, k === null || k.dehydrated === null || T !== null && T.dehydrated !== null ? Kn = !1 : (T = n.deletions, T !== null && 0 < T.length && T[0].tag === 18 ? (Kn = !1, k = k.hydrationErrors, k !== null && Do(n, n.actualStartTime, s, k)) : Kn = !0), dr(e, n, o, i, s), Kn = z;
						break;
					case 23: break;
					case 22:
						H = n.stateNode, T = n.alternate, n.memoizedState !== null ? (k && T !== null && T.memoizedState === null && vd(T), H._visibility & $i ? dr(e, n, o, i, s) : _u(e, n, o, i, s)) : (k && T !== null && T.memoizedState !== null && vd(n), H._visibility & $i ? dr(e, n, o, i, s) : (H._visibility |= $i, jl(e, n, o, i, (n.subtreeFlags & 10256) !== 0 || n.actualDuration !== 0 && (n.alternate === null || n.alternate.child !== n.child), s), (n.mode & 2) === Z || Kn || (e = n.actualStartTime, 0 <= e && .05 < s - e && so(n, e, s), 0 <= V && 0 <= J && .05 < J - V && so(n, V, J)))), z & 2048 && Fa(T, n);
						break;
					case 24:
						dr(e, n, o, i, s), z & 2048 && $r(n.alternate, n);
						break;
					case 30:
						k && (z = n.alternate, z !== null && (Po(z.child, !0), Po(n.child, !0))), dr(e, n, o, i, s);
						break;
					default: dr(e, n, o, i, s);
				}
				(n.mode & 2) !== Z && ((e = !Kn && n.alternate === null && n.return !== null && n.return.alternate !== null) && (o = n.actualStartTime, 0 <= o && .05 < s - o && nr(n, o, s, "Mount")), 0 <= V && 0 <= J && ((Sn || .05 < dn) && Me(n, V, J, dn, on), e && .05 < J - V && nr(n, V, J, "Mount"))), gt(u), go(f), on = p, Sn = g, os = b;
			}
			function jl(e, n, o, i, s, u) {
				for (s = s && ((n.subtreeFlags & 10256) !== 0 || n.actualDuration !== 0 && (n.alternate === null || n.alternate.child !== n.child)), n = n.child; n !== null;) {
					var f = n.sibling;
					Ul(e, n, o, i, s, f !== null ? f.actualStartTime : u), n = f;
				}
			}
			function Ul(e, n, o, i, s, u) {
				var f = Pt(), p = Ir(), g = Rr(), b = Lr(), k = os;
				s && (n.mode & 2) !== Z && 0 < n.actualStartTime && n.flags & 1 && oi(n, n.actualStartTime, u, Kn, o);
				var z = n.flags;
				switch (n.tag) {
					case 0:
					case 11:
					case 15:
						jl(e, n, o, i, s, u), Cm(n, Dt);
						break;
					case 23: break;
					case 22:
						var T = n.stateNode;
						n.memoizedState !== null ? T._visibility & $i ? jl(e, n, o, i, s, u) : _u(e, n, o, i, u) : (T._visibility |= $i, jl(e, n, o, i, s, u)), s && z & 2048 && Fa(n.alternate, n);
						break;
					case 24:
						jl(e, n, o, i, s, u), s && z & 2048 && $r(n.alternate, n);
						break;
					default: jl(e, n, o, i, s, u);
				}
				(n.mode & 2) !== Z && 0 <= V && 0 <= J && (Sn || .05 < dn) && Me(n, V, J, dn, on), gt(f), go(p), on = g, Sn = b, os = k;
			}
			function _u(e, n, o, i, s) {
				if (n.subtreeFlags & 10256 || n.actualDuration !== 0 && (n.alternate === null || n.alternate.child !== n.child)) for (var u = n.child; u !== null;) {
					n = u.sibling;
					var f = e, p = o, g = i, b = n !== null ? n.actualStartTime : s, k = os;
					(u.mode & 2) !== Z && 0 < u.actualStartTime && u.flags & 1 && oi(u, u.actualStartTime, b, Kn, p);
					var z = u.flags;
					switch (u.tag) {
						case 22:
							_u(f, u, p, g, b), z & 2048 && Fa(u.alternate, u);
							break;
						case 24:
							_u(f, u, p, g, b), z & 2048 && $r(u.alternate, u);
							break;
						default: _u(f, u, p, g, b);
					}
					os = k, u = n;
				}
			}
			function Da(e, n, o) {
				if (e.subtreeFlags & ic) for (e = e.child; e !== null;) Mm(e, n, o), e = e.sibling;
			}
			function Mm(e, n, o) {
				switch (e.tag) {
					case 26:
						if (Da(e, n, o), e.flags & ic) if (e.memoizedState !== null) Tg(o, fa, e.memoizedState, e.memoizedProps);
						else {
							var i = e.stateNode, s = e.type;
							e = e.memoizedProps, ((n & 335544128) === n || qr(s, e)) && xg(o, i, s, e);
						}
						break;
					case 5:
						Da(e, n, o), e.flags & ic && (i = e.stateNode, s = e.type, e = e.memoizedProps, ((n & 335544128) === n || qr(s, e)) && xg(o, i, s, e));
						break;
					case 3:
					case 4:
						Ze ? (i = fa, fa = ji(e.stateNode.containerInfo), Da(e, n, o), fa = i) : Da(e, n, o);
						break;
					case 22:
						e.memoizedState === null && (i = e.alternate, i !== null && i.memoizedState !== null ? (i = ic, ic = 16777216, Da(e, n, o), ic = i) : Da(e, n, o));
						break;
					case 30:
						(e.flags & ic) !== 0 && (i = e.memoizedProps.name, i != null && i !== "auto" && (s = e.stateNode, s.paired = null, no === null && (no = /* @__PURE__ */ new Map()), no.set(i, s))), Da(e, n, o);
						break;
					default: Da(e, n, o);
				}
			}
			function Wl(e) {
				var n = e.alternate;
				if (n !== null && (e = n.child, e !== null)) {
					n.child = null;
					do
						n = e.sibling, e.sibling = null, e = n;
					while (e !== null);
				}
			}
			function Nu(e) {
				var n = e.deletions;
				if ((e.flags & 16) !== 0) {
					if (n !== null) for (var o = 0; o < n.length; o++) {
						var i = n[o], s = Pt();
						dt = i, Qm(i, e), (i.mode & 2) !== Z && 0 <= V && 0 <= J && .05 < J - V && nr(i, V, J, "Unmount"), gt(s);
					}
					Wl(e);
				}
				if (e.subtreeFlags & 10256) for (e = e.child; e !== null;) Vm(e), e = e.sibling;
			}
			function Vm(e) {
				var n = Pt(), o = Ir(), i = Rr(), s = Lr();
				switch (e.tag) {
					case 0:
					case 11:
					case 15:
						Nu(e), e.flags & 2048 && hd(e, e.return, Dt | Ro);
						break;
					case 3:
						var u = mo();
						Nu(e), e.stateNode.passiveEffectDuration += Us(u);
						break;
					case 12:
						u = mo(), Nu(e), e.stateNode.passiveEffectDuration += hl(u);
						break;
					case 22:
						u = e.stateNode, e.memoizedState !== null && u._visibility & $i && (e.return === null || e.return.tag !== 13) ? (u._visibility &= ~$i, Pd(e), (e.mode & 2) !== Z && 0 <= V && 0 <= J && .05 < J - V && nr(e, V, J, "Disconnect")) : Nu(e);
						break;
					default: Nu(e);
				}
				(e.mode & 2) !== Z && 0 <= V && 0 <= J && (Sn || .05 < dn) && Me(e, V, J, dn, on), gt(n), go(o), Sn = s, on = i;
			}
			function Pd(e) {
				var n = e.deletions;
				if ((e.flags & 16) !== 0) {
					if (n !== null) for (var o = 0; o < n.length; o++) {
						var i = n[o], s = Pt();
						dt = i, Qm(i, e), (i.mode & 2) !== Z && 0 <= V && 0 <= J && .05 < J - V && nr(i, V, J, "Unmount"), gt(s);
					}
					Wl(e);
				}
				for (e = e.child; e !== null;) $m(e), e = e.sibling;
			}
			function $m(e) {
				var n = Pt(), o = Ir(), i = Rr(), s = Lr();
				switch (e.tag) {
					case 0:
					case 11:
					case 15:
						hd(e, e.return, Dt), Pd(e);
						break;
					case 22:
						var u = e.stateNode;
						u._visibility & $i && (u._visibility &= ~$i, Pd(e));
						break;
					default: Pd(e);
				}
				(e.mode & 2) !== Z && 0 <= V && 0 <= J && (Sn || .05 < dn) && Me(e, V, J, dn, on), gt(n), go(o), Sn = s, on = i;
			}
			function Qm(e, n) {
				for (; dt !== null;) {
					var o = dt, i = o, s = n, u = Pt(), f = Ir(), p = Rr(), g = Lr();
					switch (i.tag) {
						case 0:
						case 11:
						case 15:
							hd(i, s, Dt);
							break;
						case 23:
						case 22:
							i.memoizedState !== null && i.memoizedState.cachePool !== null && (s = i.memoizedState.cachePool.pool, s != null && Mo(s));
							break;
						case 24: Bt(i.memoizedState.cache);
					}
					if ((i.mode & 2) !== Z && 0 <= V && 0 <= J && (Sn || .05 < dn) && Me(i, V, J, dn, on), gt(u), go(f), Sn = g, on = p, i = o.child, i !== null) i.return = o, dt = i;
					else e: for (o = e; dt !== null;) {
						if (i = dt, u = i.sibling, f = i.return, Ye(i), i === o) {
							dt = null;
							break e;
						}
						if (u !== null) {
							u.return = f, dt = u;
							break e;
						}
						dt = f;
					}
				}
			}
			function Bp(e) {
				var n = Jn(e);
				if (n != null) {
					if (typeof n.memoizedProps["data-testname"] != "string") throw Error("Invalid host root specified. Should be either a React container or a node with a testname attribute.");
					return n;
				}
				if (e = Ii(e), e === null) throw Error("Could not find React container within specified host subtree.");
				return e.stateNode.current;
			}
			function Hp(e, n) {
				var o = e.tag;
				switch (n.$$typeof) {
					case t0:
						if (e.type === n.value) return !0;
						break;
					case r0:
						e: {
							for (n = n.value, e = [e, 0], o = 0; o < e.length;) {
								var i = e[o++], s = i.tag, u = e[o++], f = n[u];
								if (s !== 5 && s !== 26 && s !== 27 || !Zr(i)) {
									for (; f != null && Hp(i, f);) u++, f = n[u];
									if (u === n.length) {
										n = !0;
										break e;
									} else for (i = i.child; i !== null;) e.push(i, u), i = i.sibling;
								}
							}
							n = !1;
						}
						return n;
					case o0:
						if ((o === 5 || o === 26 || o === 27) && Jl(e.stateNode, n.value)) return !0;
						break;
					case i0:
						if ((o === 5 || o === 6 || o === 26 || o === 27) && (e = Cg(e), e !== null && 0 <= e.indexOf(n.value))) return !0;
						break;
					case a0:
						if ((o === 5 || o === 26 || o === 27) && (e = e.memoizedProps["data-testname"], typeof e == "string" && e.toLowerCase() === n.value.toLowerCase())) return !0;
						break;
					default: throw Error("Invalid selector type specified.");
				}
				return !1;
			}
			function Mp(e) {
				switch (e.$$typeof) {
					case t0: return "<" + (en(e.value) || "Unknown") + ">";
					case r0: return ":has(" + (Mp(e) || "") + ")";
					case o0: return "[role=\"" + e.value + "\"]";
					case i0: return "\"" + e.value + "\"";
					case a0: return "[data-testname=\"" + e.value + "\"]";
					default: throw Error("Invalid selector type specified.");
				}
			}
			function qm(e, n) {
				var o = [];
				e = [e, 0];
				for (var i = 0; i < e.length;) {
					var s = e[i++], u = s.tag, f = e[i++], p = n[f];
					if (u !== 5 && u !== 26 && u !== 27 || !Zr(s)) {
						for (; p != null && Hp(s, p);) f++, p = n[f];
						if (f === n.length) o.push(s);
						else for (s = s.child; s !== null;) e.push(s, f), s = s.sibling;
					}
				}
				return o;
			}
			function xd(e, n) {
				if (!Oa) throw Error("Test selector API is not supported by this renderer.");
				e = Bp(e), e = qm(e, n), n = [], e = Array.from(e);
				for (var o = 0; o < e.length;) {
					var i = e[o++], s = i.tag;
					if (s === 5 || s === 26 || s === 27) Zr(i) || n.push(i.stateNode);
					else for (i = i.child; i !== null;) e.push(i), i = i.sibling;
				}
				return n;
			}
			function w0() {
				Oa && l0.forEach(function(e) {
					return e();
				});
			}
			function Gm() {
				var e = typeof IS_REACT_ACT_ENVIRONMENT < "u" ? IS_REACT_ACT_ENVIRONMENT : void 0;
				return e || N.actQueue === null || console.error("The current testing environment is not configured to support act(...)"), e;
			}
			function _t(e) {
				if ((ve & pt) !== ft && te !== 0) return te & -te;
				var n = N.T;
				return n !== null ? (n._updatedFibers || (n._updatedFibers = /* @__PURE__ */ new Set()), n._updatedFibers.add(e), nc !== null && Nn() === 2 && (nc = null), Nc()) : (e = Nn(), e === 2 && (nc = null), e);
			}
			function Jm() {
				if (kr === 0) if ((te & 536870912) === 0 || le) {
					var e = R;
					R <<= 1, !(R & 3932160) && (R = 262144), kr = e;
				} else kr = 536870912;
				return e = St.current, e !== null && (e.flags |= 32), kr;
			}
			function Al(e, n) {
				if (n != null) {
					var o = e.stateNode, i = o.ref;
					i === null && (i = o.ref = Bu(Mn(e.memoizedProps, o))), wf === null && (wf = []), wf.push(n.bind(null, i));
				}
			}
			function nn(e, n, o) {
				if (xf && console.error("useInsertionEffect must not schedule updates."), Ab && (y0 = !0), (e === Ge && (Ae === sc || Ae === uc) || e.cancelPendingCommit !== null) && (Yo(e, 0), ja(e, te, kr, !1)), el(e, o), (ve & pt) !== ft && e === Ge) {
					if (Qa) switch (n.tag) {
						case 0:
						case 11:
						case 15:
							e = se && G(se) || "Unknown", l1.has(e) || (l1.add(e), n = G(n) || "Unknown", console.error("Cannot update a component (`%s`) while rendering a different component (`%s`). To locate the bad setState() call inside `%s`, follow the stack trace as described in https://react.dev/link/setstate-in-render", n, e, e));
							break;
						case 1: i1 || (console.error("Cannot update during an existing state transition (such as within `render`). Render methods should be a pure function of props and state."), i1 = !0);
					}
				} else Le && Rf(e, n, o), I0(n), e === Ge && ((ve & pt) === ft && (ys |= o), fn === gs && ja(e, te, kr, !1)), jr(e);
			}
			function Zm(e, n, o) {
				if ((ve & (pt | Fo)) !== ft) throw Error("Should not already be working.");
				if (te !== 0 && se !== null) {
					var i = se, s = Re();
					switch (ny) {
						case Xh:
						case sc:
							var u = Rh;
							Ke && ((i = i._debugTask) ? i.run(console.timeStamp.bind(console, "Suspended", u, s, "Components ⚛", void 0, "primary-light")) : console.timeStamp("Suspended", u, s, "Components ⚛", void 0, "primary-light"));
							break;
						case uc:
							u = Rh, Ke && ((i = i._debugTask) ? i.run(console.timeStamp.bind(console, "Action", u, s, "Components ⚛", void 0, "primary-light")) : console.timeStamp("Action", u, s, "Components ⚛", void 0, "primary-light"));
							break;
						default: Ke && (i = s - Rh, 3 > i || console.timeStamp("Blocked", Rh, s, "Components ⚛", void 0, 5 > i ? "primary-light" : 10 > i ? "primary" : 100 > i ? "primary-dark" : "error"));
					}
				}
				u = (o = !o && (n & 127) === 0 && (n & e.expiredLanes) === 0 || At(e, n)) ? x0(e, n) : Qp(e, n, !0);
				var f = o;
				do {
					if (u === Gi) {
						Sf && !o && ja(e, n, 0, !1), n = Ae, Rh = Tn(), ny = n;
						break;
					} else {
						if (i = Re(), s = e.current.alternate, f && !P0(s)) {
							zn(n), s = ut, u = i, !Ke || u <= s || (kn ? kn.run(console.timeStamp.bind(console, "Teared Render", s, u, me, "Scheduler ⚛", "error")) : console.timeStamp("Teared Render", s, u, me, "Scheduler ⚛", "error")), xi(n, i), u = Qp(e, n, !1), f = !1;
							continue;
						}
						if (u === lc) {
							if (f = n, e.errorRecoveryDisabledLanes & f) var p = 0;
							else p = e.pendingLanes & -536870913, p = p !== 0 ? p : p & 536870912 ? 536870912 : 0;
							if (p !== 0) {
								zn(n), _s(ut, i, n, kn), xi(n, i), n = p;
								e: {
									i = e, u = f, f = Kh;
									var g = $e && i.current.memoizedState.isDehydrated;
									if (g && (Yo(i, p).flags |= 256), p = Qp(i, p, !1), p !== lc && p !== Zh) {
										if (Tb && !g) {
											i.errorRecoveryDisabledLanes |= u, ys |= u, u = gs;
											break e;
										}
										i = Yt, Yt = f, i !== null && (Yt === null ? Yt = i : Yt.push.apply(Yt, i));
									}
									u = p;
								}
								if (f = !1, u !== lc) continue;
								i = Re();
							}
						}
						if (u === Jh) {
							zn(n), _s(ut, i, n, kn), xi(n, i), Yo(e, 0), ja(e, n, 0, !0);
							break;
						}
						e: {
							switch (o = e, u) {
								case Gi:
								case Jh: throw Error("Root did not complete. This is a bug in React.");
								case gs: if ((n & 4194048) !== n && (n & 62914560) !== n) break;
								case Zh:
									zn(n), Es(ut, i, n, kn), xi(n, i), s = n, (s & 127) !== 0 ? Wg = i : s & 4194048 && (Ag = i), ja(o, n, kr, !Ji);
									break e;
								case lc:
									Yt = null;
									break;
								case s0:
								case Xy: break;
								default: throw Error("Unknown root exit status.");
							}
							if (N.actQueue !== null) _d(o, s, n, Yt, nm, d0, kr, ys, cc, Ji, u, null, null, ut, i);
							else {
								if ((n & 62914560) === n && (f = f0 + e1 - Re(), 10 < f)) {
									if (ja(o, n, kr, !Ji), ks(o, 0, !0) !== 0) break e;
									wr = n, o.timeoutHandle = Dd(Vp.bind(null, o, s, Yt, nm, d0, n, kr, ys, cc, Ji, u, "Throttled", ut, i), f);
									break e;
								}
								Vp(o, s, Yt, nm, d0, n, kr, ys, cc, Ji, u, null, ut, i);
							}
						}
					}
					break;
				} while (!0);
				jr(e);
			}
			function Vp(e, n, o, i, s, u, f, p, g, b, k, z, T, H) {
				e.timeoutHandle = Wn;
				var $ = n.subtreeFlags, an = (u & 335544064) === u, Hn = null;
				if ((an || $ & 8192 || ($ & 16785408) === 16785408) && (Hn = A0(), no = null, Mm(n, u, Hn), an && tn(Hn, e.containerInfo), $ = (u & 62914560) === u ? f0 - Re() : (u & 4194048) === u ? Ky - Re() : 0, $ = Uu(Hn, $), $ !== null)) {
					wr = u, e.cancelPendingCommit = $(_d.bind(null, e, n, u, o, i, s, f, p, g, b, k, Hn, ql(Hn, e.containerInfo), T, H)), ja(e, u, f, !b);
					return;
				}
				_d(e, n, u, o, i, s, f, p, g, b, k, Hn, z, T, H);
			}
			function P0(e) {
				for (var n = e;;) {
					var o = n.tag;
					if ((o === 0 || o === 11 || o === 15) && n.flags & 16384 && (o = n.updateQueue, o !== null && (o = o.stores, o !== null))) for (var i = 0; i < o.length; i++) {
						var s = o[i], u = s.getSnapshot;
						s = s.value;
						try {
							if (!Gt(u(), s)) return !1;
						} catch {
							return !1;
						}
					}
					if (o = n.child, n.subtreeFlags & 16384 && o !== null) o.return = n, n = o;
					else {
						if (n === e) break;
						for (; n.sibling === null;) {
							if (n.return === null || n.return === e) return !0;
							n = n.return;
						}
						n.sibling.return = n.return, n = n.sibling;
					}
				}
				return !0;
			}
			function ja(e, n, o, i) {
				n = im(e, n), n &= ~Ib, n &= ~ys, e.suspendedLanes |= n, e.pingedLanes &= ~n, i && (e.warmLanes |= n), i = e.expirationTimes;
				for (var s = n; 0 < s;) {
					var u = 31 - d(s), f = 1 << u;
					i[u] = -1, s &= ~f;
				}
				o !== 0 && io(e, o, n);
			}
			function Cd() {
				return (ve & (pt | Fo)) === ft ? (Ur(0, !1), !1) : !0;
			}
			function $p() {
				return (ve & (pt | Fo)) !== ft;
			}
			function Tu() {
				if (se !== null) {
					if (Ae === Sr) var e = se.return;
					else e = se, cl(), Bc(e), df = null, Bh = 0, e = se;
					for (; e !== null;) Np(e.alternate, e), e = e.return;
					se = null;
				}
			}
			function xi(e, n) {
				e & 127 && (us = n), e & 4194048 && (ua = n), e & 62914560 && (nb = n), e & 2080374784 && (tb = n);
			}
			function Yo(e, n) {
				Ke && (console.timeStamp("Blocking Track", .003, .003, "Blocking", "Scheduler ⚛", "primary-light"), console.timeStamp("Transition Track", .003, .003, "Transition", "Scheduler ⚛", "primary-light"), console.timeStamp("Suspense Track", .003, .003, "Suspense", "Scheduler ⚛", "primary-light"), console.timeStamp("Idle Track", .003, .003, "Idle", "Scheduler ⚛", "primary-light"));
				var o = ut;
				if (ut = Tn(), te !== 0 && 0 < o) {
					if (zn(te), fn === s0 || fn === gs) Es(o, ut, n, kn);
					else {
						var i = ut, s = kn;
						if (Ke && !(i <= o)) {
							var u = (n & 738197653) === n ? "tertiary-dark" : "primary-dark", f = (n & 536870912) === n ? "Prewarm" : (n & 201326741) === n ? "Interrupted Hydration" : "Interrupted Render";
							s ? s.run(console.timeStamp.bind(console, f, o, i, me, "Scheduler ⚛", u)) : console.timeStamp(f, o, i, me, "Scheduler ⚛", u);
						}
					}
					xi(te, ut);
				}
				if (o = kn, kn = null, (n & 127) !== 0) {
					kn = Nh, s = 0 <= Ga && Ga < us ? us : Ga, i = 0 <= Ju && Ju < us ? us : Ju, u = 0 <= i ? i : 0 <= s ? s : ut, 0 <= Wg ? (zn(2), Df(Wg, u, n, o)) : Xu & 127 && (zn(2), Pr(us, u, br)), o = s;
					var p = i, g = Th, b = 0 < af, k = cs === 1, z = cs === 2;
					if (s = ut, i = Nh, u = Y0, f = K0, Ke) {
						if (me = "Blocking", 0 < o ? o > s && (o = s) : o = s, 0 < p ? p > o && (p = o) : p = o, g !== null && o > p) {
							var T = b ? "secondary-light" : "warning";
							i ? i.run(console.timeStamp.bind(console, b ? "Consecutive" : "Event: " + g, p, o, me, "Scheduler ⚛", T)) : console.timeStamp(b ? "Consecutive" : "Event: " + g, p, o, me, "Scheduler ⚛", T);
						}
						s > o && (p = k ? "error" : (n & 738197653) === n ? "tertiary-light" : "primary-light", k = z ? "Promise Resolved" : k ? "Cascading Update" : 5 < s - o ? "Update Blocked" : "Update", z = [], f != null && z.push(["Component name", f]), u != null && z.push(["Method name", u]), o = {
							start: o,
							end: s,
							detail: { devtools: {
								properties: z,
								track: me,
								trackGroup: "Scheduler ⚛",
								color: p
							} }
						}, i ? i.run(performance.measure.bind(performance, k, o)) : performance.measure(k, o), performance.clearMeasures(k));
					}
					Ga = -1.1, cs = 0, K0 = Y0 = null, Wg = -1.1, af = Ju, Ju = -1.1, us = Tn();
				}
				return n & 4194048 && (kn = Ih, s = 0 <= Vi && Vi < ua ? ua : Vi, o = 0 <= To && To < ua ? ua : To, i = 0 <= ds && ds < ua ? ua : ds, u = 0 <= i ? i : 0 <= o ? o : ut, 0 <= Ag ? (zn(256), Df(Ag, u, n, kn)) : Xu & 4194048 && (zn(256), Pr(ua, u, br)), z = i, p = Zu, g = 0 < fs, b = eb === 2, u = ut, i = Ih, f = Kb, k = ey, Ke && (me = "Transition", 0 < o ? o > u && (o = u) : o = u, 0 < s ? s > o && (s = o) : s = o, 0 < z ? z > s && (z = s) : z = s, s > z && p !== null && (T = g ? "secondary-light" : "warning", i ? i.run(console.timeStamp.bind(console, g ? "Consecutive" : "Event: " + p, z, s, me, "Scheduler ⚛", T)) : console.timeStamp(g ? "Consecutive" : "Event: " + p, z, s, me, "Scheduler ⚛", T)), o > s && (i ? i.run(console.timeStamp.bind(console, "Action", s, o, me, "Scheduler ⚛", "primary-dark")) : console.timeStamp("Action", s, o, me, "Scheduler ⚛", "primary-dark")), u > o && (s = b ? "Promise Resolved" : 5 < u - o ? "Update Blocked" : "Update", z = [], k != null && z.push(["Component name", k]), f != null && z.push(["Method name", f]), o = {
					start: o,
					end: u,
					detail: { devtools: {
						properties: z,
						track: me,
						trackGroup: "Scheduler ⚛",
						color: "primary-light"
					} }
				}, i ? i.run(performance.measure.bind(performance, s, o)) : performance.measure(s, o), performance.clearMeasures(s))), To = Vi = -1.1, eb = 0, Ag = -1.1, fs = ds, ds = -1.1, ua = Tn()), n & 62914560 && Xu & 62914560 && (zn(4194304), Pr(nb, ut, br)), n & 2080374784 && Xu & 2080374784 && (zn(268435456), Pr(tb, ut, br)), o = e.timeoutHandle, o !== Wn && (e.timeoutHandle = Wn, Du(o)), o = e.cancelPendingCommit, o !== null && (e.cancelPendingCommit = null, o()), wr = 0, Tu(), Ge = e, se = o = Ko(e.current, null), te = n, Ae = Sr, to = null, Ji = !1, Sf = At(e, n), Tb = !1, fn = Gi, cc = kr = Ib = ys = bs = 0, Yt = Kh = null, d0 = !1, ei = im(e, n), vl(), e = Hb(), 1e3 < e - la && (N.recentlyCreatedOwnerStacks = 0, la = e), ca.discardPendingWarnings(), o;
			}
			function Xm(e, n) {
				X = null, N.H = Zg, N.getCurrentStack = null, Qa = !1, Bi = null, n === cf || n === Vg ? (n = Xf(), Ae = Xh) : n === cb ? (n = Xf(), Ae = Yy) : Ae = n === wb ? Nb : n !== null && typeof n == "object" && typeof n.then == "function" ? Yh : u0, to = n;
				var o = se;
				o === null ? (fn = Jh, bi(e, Ot(n, e.current))) : o.mode & 2 && As(o);
			}
			function Ym() {
				var e = St.current;
				return e === null ? !0 : (te & 4194048) === te ? Zt === null : (te & 62914560) === te || (te & 536870912) !== 0 ? e === Zt : !1;
			}
			function Km() {
				var e = N.H;
				return N.H = Zg, e === null ? Zg : e;
			}
			function eg() {
				var e = N.A;
				return N.A = A1, e;
			}
			function zd(e) {
				kn === null && (kn = e._debugTask == null ? null : e._debugTask);
			}
			function Iu() {
				fn = gs, Ji || (te & 4194048) !== te && St.current !== null || (Sf = !0), !(bs & 134217727) && !(ys & 134217727) || Ge === null || ja(Ge, te, kr, !1);
			}
			function Qp(e, n, o) {
				var i = ve;
				ve |= pt;
				var s = Km(), u = eg();
				if (Ge !== e || te !== n) {
					if (Le) {
						var f = e.memoizedUpdaters;
						0 < f.size && (Ru(e, te), f.clear()), Cs(e, n);
					}
					nm = null, Yo(e, n);
				}
				n = !1, f = fn;
				e: do
					try {
						if (Ae !== Sr && se !== null) {
							var p = se, g = to;
							switch (Ae) {
								case Nb:
									Tu(), f = Zh;
									break e;
								case Xh:
								case sc:
								case uc:
								case Yh:
									St.current === null && (n = !0);
									var b = Ae;
									if (Ae = Sr, to = null, Ci(e, p, g, b), o && Sf) {
										f = Gi;
										break e;
									}
									break;
								default: b = Ae, Ae = Sr, to = null, Ci(e, p, g, b);
							}
						}
						ng(), f = fn;
						break;
					} catch (k) {
						Xm(e, k);
					}
				while (!0);
				return n && e.shellSuspendCounter++, cl(), ve = i, N.H = s, N.A = u, se === null && (Ge = null, te = 0, vl()), f;
			}
			function ng() {
				for (; se !== null;) rg(se);
			}
			function x0(e, n) {
				var o = ve;
				ve |= pt;
				var i = Km(), s = eg();
				if (Ge !== e || te !== n) {
					if (Le) {
						var u = e.memoizedUpdaters;
						0 < u.size && (Ru(e, te), u.clear()), Cs(e, n);
					}
					nm = null, em = Re() + Rb, Yo(e, n);
				} else Sf = At(e, n);
				e: do
					try {
						if (Ae !== Sr && se !== null) n: switch (n = se, u = to, Ae) {
							case u0:
								Ae = Sr, to = null, Ci(e, n, u, u0);
								break;
							case sc:
							case uc:
								if (Jf(u)) {
									Ae = Sr, to = null, og(n);
									break;
								}
								n = function() {
									Ae !== sc && Ae !== uc || Ge !== e || (Ae = c0), jr(e);
								}, u.then(n, n);
								break e;
							case Xh:
								Ae = c0;
								break e;
							case Yy:
								Ae = _b;
								break e;
							case c0:
								Jf(u) ? (Ae = Sr, to = null, og(n)) : (Ae = Sr, to = null, Ci(e, n, u, c0));
								break;
							case _b:
								var f = null;
								switch (se.tag) {
									case 26: f = se.memoizedState;
									case 5:
									case 27:
										var p = se, g = p.type, b = p.pendingProps;
										if (f ? ef(f) : Pg(p.stateNode, g, b)) {
											Ae = Sr, to = null;
											var k = p.sibling;
											if (k !== null) se = k;
											else {
												var z = p.return;
												z !== null ? (se = z, Ed(z)) : se = null;
											}
											break n;
										}
										break;
									default: console.error("Unexpected type of fiber triggered a suspensey commit. This is a bug in React.");
								}
								Ae = Sr, to = null, Ci(e, n, u, _b);
								break;
							case Yh:
								Ae = Sr, to = null, Ci(e, n, u, Yh);
								break;
							case Nb:
								Tu(), fn = Zh;
								break e;
							default: throw Error("Unexpected SuspendedReason. This is a bug in React.");
						}
						N.actQueue !== null ? ng() : tg();
						break;
					} catch (T) {
						Xm(e, T);
					}
				while (!0);
				return cl(), N.H = i, N.A = s, ve = o, se !== null ? Gi : (Ge = null, te = 0, vl(), fn);
			}
			function tg() {
				for (; se !== null && !fe();) rg(se);
			}
			function rg(e) {
				var n = e.alternate;
				(e.mode & 2) !== Z ? (zc(e), n = B(e, Su, n, e, ei), As(e)) : n = B(e, Su, n, e, ei), e.memoizedProps = e.pendingProps, n === null ? Ed(e) : se = n;
			}
			function og(e) {
				var n = B(e, ag, e);
				e.memoizedProps = e.pendingProps, n === null ? Ed(e) : se = n;
			}
			function ag(e) {
				var n = e.alternate, o = (e.mode & 2) !== Z;
				switch (o && zc(e), e.tag) {
					case 15:
					case 0:
						n = kp(n, e, e.pendingProps, e.type, void 0, te);
						break;
					case 11:
						n = kp(n, e, e.pendingProps, e.type.render, e.ref, te);
						break;
					case 5:
						Bc(e);
						var i = e;
						$e && i === st && (le ? (Tr(i), i.tag === 5 && i.stateNode != null && (rn = i.stateNode)) : (Tr(i), le = !0));
					default: Np(n, e), e = se = bg(e, ei), n = Su(n, e, ei);
				}
				return o && As(e), n;
			}
			function Ci(e, n, o, i) {
				cl(), Bc(n), df = null, Bh = 0;
				var s = n.return;
				try {
					if (vm(e, s, n, o, te)) {
						fn = Jh, bi(e, Ot(o, e.current)), se = null;
						return;
					}
				} catch (u) {
					if (s !== null) throw se = s, u;
					fn = Jh, bi(e, Ot(o, e.current)), se = null;
					return;
				}
				n.flags & 32768 ? (le || i === u0 ? e = !0 : Sf || (te & 536870912) !== 0 ? e = !1 : (Ji = e = !0, (i === sc || i === uc || i === Xh || i === Yh) && (i = St.current, i !== null && i.tag === 13 && (i.flags |= 16384))), qp(n, e)) : Ed(n);
			}
			function Ed(e) {
				var n = e;
				do {
					if ((n.flags & 32768) !== 0) {
						qp(n, Ji);
						return;
					}
					var o = n.alternate;
					if (e = n.return, zc(n), o = B(n, _p, o, n, ei), (n.mode & 2) !== Z && Of(n), o !== null) {
						se = o;
						return;
					}
					if (n = n.sibling, n !== null) {
						se = n;
						return;
					}
					se = n = e;
				} while (n !== null);
				fn === Gi && (fn = Xy);
			}
			function qp(e, n) {
				do {
					var o = Zo(e.alternate, e);
					if (o !== null) {
						o.flags &= 32767, se = o;
						return;
					}
					if ((e.mode & 2) !== Z) {
						Of(e), o = e.actualDuration;
						for (var i = e.child; i !== null;) o += i.actualDuration, i = i.sibling;
						e.actualDuration = o;
					}
					if (o = e.return, o !== null && (o.flags |= 32768, o.subtreeFlags = 0, o.deletions = null), !n && (e = e.sibling, e !== null)) {
						se = e;
						return;
					}
					se = e = o;
				} while (e !== null);
				fn = Zh, se = null;
			}
			function _d(e, n, o, i, s, u, f, p, g, b, k, z, T, H, $) {
				e.cancelPendingCommit = null;
				do
					Ol();
				while (pn !== ni);
				if (ca.flushLegacyContextWarning(), ca.flushPendingUnsafeLifecycleWarnings(), (ve & (pt | Fo)) !== ft) throw Error("Should not already be working.");
				if (zn(o), k === lc) _s(H, $, o, kn);
				else if (i !== null) {
					if (b = n !== null && n.alternate !== null && n.alternate.memoizedState.isDehydrated && (n.flags & 256) !== 0, u = kn, Ke && !($ <= H)) {
						k = [];
						for (var an = 0; an < i.length; an++) {
							var Hn = i[an].value;
							k.push(["Recoverable Error", typeof Hn == "object" && Hn !== null && typeof Hn.message == "string" ? String(Hn.message) : String(Hn)]);
						}
						H = {
							start: H,
							end: $,
							detail: { devtools: {
								color: "primary-dark",
								track: me,
								trackGroup: "Scheduler ⚛",
								tooltipText: b ? "Hydration Failed" : "Recovered after Error",
								properties: k
							} }
						}, u ? u.run(performance.measure.bind(performance, "Recovered", H)) : performance.measure("Recovered", H), performance.clearMeasures("Recovered");
					}
				} else u = kn, !Ke || $ <= H || (b = (o & 738197653) === o ? "tertiary-dark" : "primary-dark", k = (o & 536870912) === o ? "Prepared" : (o & 201326741) === o ? "Hydrated" : "Render", u ? u.run(console.timeStamp.bind(console, k, H, $, me, "Scheduler ⚛", b)) : console.timeStamp(k, H, $, me, "Scheduler ⚛", b));
				if (n !== null) {
					if (o === 0 && console.error("finishedLanes should not be empty during a commit. This is a bug in React."), n === e.current) throw Error("Cannot commit the same tree as before. This error is likely caused by a bug in React. Please file an issue.");
					e === Ge && (se = Ge = null, te = 0), dc = n, pa = e, wr = o, Ub = s, o1 = i, m0 = $, g0 = T, ro = p0, Wb = null, ig(e, n, o, f, p, g, z, T, $);
				}
			}
			function ig(e, n, o, i, s, u, f, p, g) {
				var b = n.lanes | n.childLanes;
				if (jb = b, b |= pb, Kt(e, o, b, i, s, u), wf = null, (o & 335544064) === o ? (Pf = Af(e), i = 10262) : (Pf = null, i = 10256), n.actualDuration !== 0 || (n.subtreeFlags & i) !== 0 || (n.flags & i) !== 0 ? (e.callbackNode = null, e.callbackPriority = 0, T0(P, function() {
					return Qe(), ro === p0 && (ro = Lb), Yp(), null;
				})) : (e.callbackNode = null, e.callbackPriority = 0), Mi = null, Hi = Tn(), p !== null && Ns(g, Hi, p, kn), Yg = !1, p = (n.flags & 13878) !== 0, (n.subtreeFlags & 13878) !== 0 || p) {
					p = N.T, N.T = null, g = fr(), Je(2), i = ve, ve |= Fo;
					try {
						kd(e, n, o);
					} finally {
						ve = i, Je(g), N.T = p;
					}
				}
				pn = t1, Yg ? (Xu |= o, br = null, kf = Ou(f, e.containerInfo, Pf, Zp, Xp, z0, Nd, Yp, Gp, Jp, C0.bind(null, o))) : (Zp(), Xp(), Nd());
			}
			function Gp(e) {
				if (pn !== ni) {
					var n = pa.onRecoverableError;
					n(e, lg(null));
				}
			}
			function Jp(e) {
				sa = Tn(), lm(g0 === null ? m0 : Hi, sa, Mi, ro === tm, kn), g0 = Wb = e;
			}
			function C0(e) {
				if ((Xu & e) !== 0) {
					var n = br;
					Xu &= ~e, br = null, e & 4194048 && !(te & 4194048) && !(wr & 4194048) && (zn(256), Pr(ua, Re(), n)), e & 62914560 && !(te & 62914560) && !(wr & 62914560) && (zn(4194304), Pr(nb, Re(), n)), e & 2080374784 && !(te & 2080374784) && !(wr & 2080374784) && (zn(268435456), Pr(tb, Re(), n));
				}
			}
			function z0() {
				pn === Fb && (pn = ni, wd(dc, pa), pn = Db);
			}
			function Zp() {
				if (pn === t1) {
					pn = ni;
					var e = pa, n = dc, o = wr, i = (n.flags & 13878) !== 0;
					if ((n.subtreeFlags & 13878) !== 0 || i) {
						i = N.T, N.T = null;
						var s = fr();
						Je(2);
						var u = ve;
						ve |= Fo;
						try {
							yf = o, vf = e, qh = n0 = !1, Ws(), Wm(n, e, o), vf = yf = null, fh(e.containerInfo);
						} finally {
							ve = u, Je(s), N.T = i;
						}
					}
					e.current = n, pn = r1;
				}
			}
			function Xp() {
				if (pn === r1) {
					pn = ni;
					var e = Wb;
					if (e !== null) {
						Hi = Tn();
						var n = sa, o = Hi;
						!Ke || o <= n || (br ? br.run(console.timeStamp.bind(console, e, n, o, me, "Scheduler ⚛", "secondary-light")) : console.timeStamp(e, n, o, me, "Scheduler ⚛", "secondary-light"));
					}
					e = pa, n = dc, o = wr;
					var i = (n.flags & 8772) !== 0;
					if ((n.subtreeFlags & 8772) !== 0 || i) {
						i = N.T, N.T = null;
						var s = fr();
						Je(2);
						var u = ve;
						ve |= Fo;
						try {
							yf = o, vf = e, Ws(), Dm(e, n.alternate, n), vf = yf = null;
						} finally {
							ve = u, Je(s), N.T = i;
						}
					}
					e = m0, n = g0, sa = Tn(), lm(n === null ? e : Hi, sa, Mi, ro === tm, kn), pn = Fb;
				}
			}
			function Nd() {
				if (pn === Db || pn === Fb) {
					if (pn === Db) {
						var e = sa;
						sa = Tn();
						var n = sa, o = ro === tm;
						!Ke || n <= e || (br ? br.run(console.timeStamp.bind(console, o ? "Interrupted View Transition" : "Starting Animation", e, n, me, "Scheduler ⚛", o ? "error" : "secondary-light")) : console.timeStamp(o ? "Interrupted View Transition" : "Starting Animation", e, n, me, "Scheduler ⚛", o ? " error" : "secondary-light")), ro !== tm && (ro = n1);
					}
					pn = ni, e = kf, kf = null, Ne(), n = pa;
					var i = dc;
					o = wr;
					var s = o1, u = (o & 335544064) === o ? 10262 : 10256;
					(u = i.actualDuration !== 0 || (i.subtreeFlags & u) !== 0 || (i.flags & u) !== 0) ? pn = h0 : (pn = ni, dc = pa = null, sg(n, n.pendingLanes), fc = 0, om = null);
					var f = n.pendingLanes;
					if (f === 0 && (vs = null), u || fg(n), f = ya(o), i = i.stateNode, M && typeof M.onCommitFiberRoot == "function") try {
						var p = (i.current.flags & 128) === 128;
						switch (f) {
							case 2:
								var g = ia;
								break;
							case 8:
								g = x;
								break;
							case 32:
								g = P;
								break;
							case 268435456:
								g = E;
								break;
							default: g = P;
						}
						M.onCommitFiberRoot(Ue, i, g, p);
					} catch (T) {
						ie || (ie = !0, console.error("React instrumentation encountered an error: %o", T));
					}
					if (Le && n.memoizedUpdaters.clear(), w0(), s !== null) {
						p = N.T, g = fr(), Je(2), N.T = null;
						try {
							var b = n.onRecoverableError;
							for (i = 0; i < s.length; i++) {
								var k = s[i], z = lg(k.stack);
								B(k.source, b, k.value, z);
							}
						} finally {
							N.T = p, Je(g);
						}
					}
					if (b = wf, k = Pf, Pf = null, b !== null && (wf = null, k === null && (k = []), e !== null)) for (z = 0; z < b.length; z++) s = (0, b[z])(k), s !== void 0 && O0(e, s);
					wr & 3 && Ol(), jr(n), f = n.pendingLanes, (o & 261930) !== 0 && (f & 42) !== 0 ? (Bg = !0, n === b0 ? rm++ : (rm = 0, b0 = n)) : (rm = 0, b0 = null), u || xi(o, sa), $e && Ha(), Ur(0, !1);
				}
			}
			function lg(e) {
				return e = { componentStack: e }, Object.defineProperty(e, "digest", { get: function() {
					console.error("You are accessing \"digest\" from the errorInfo object passed to onRecoverableError. This property is no longer provided as part of errorInfo but can be accessed as a property of the Error instance itself.");
				} }), e;
			}
			function sg(e, n) {
				(e.pooledCacheLanes &= n) === 0 && (n = e.pooledCache, n != null && (e.pooledCache = null, Bt(n)));
			}
			function Ol() {
				return kf !== null && (Yl(kf), a1 || (a1 = !0, console.warn("A flushSync update cancelled a View Transition because it was called while the View Transition was still preparing. To preserve the synchronous semantics, React had to skip the View Transition. If you can, try to avoid flushSync() in a scenario that's likely to interfere.")), kf = null, ro = tm), Zp(), Xp(), Nd(), Yp();
			}
			function Yp() {
				if (pn !== h0) return !1;
				var e = pa, n = jb;
				jb = 0;
				var o = ya(wr), i = 32 > o ? 32 : o;
				o = N.T;
				var s = fr();
				try {
					Je(i), N.T = null;
					var u = Ub;
					Ub = null, i = pa;
					var f = wr;
					if (pn = ni, dc = pa = null, wr = 0, (ve & (pt | Fo)) !== ft) throw Error("Cannot flush passive effects while already rendering.");
					zn(f), Ab = !0, y0 = !1;
					var p = 0;
					if (Mi = null, p = Re(), ro === n1) Pr(sa, p, br);
					else {
						var g = sa, b = p, k = ro === Lb;
						!Ke || b <= g || (kn ? kn.run(console.timeStamp.bind(console, k ? "Waiting for Paint" : "Waiting", g, b, me, "Scheduler ⚛", "secondary-light")) : console.timeStamp(k ? "Waiting for Paint" : "Waiting", g, b, me, "Scheduler ⚛", "secondary-light"));
					}
					g = ve, ve |= Fo;
					var z = i.current;
					Ws(), Vm(z);
					var T = i.current;
					z = m0, Ws(), Hm(i, T, f, u, z), fg(i), ve = g;
					var H = Re();
					if (T = p, z = kn, Mi !== null ? jf(T, H, Mi, !0, z) : !Ke || H <= T || (z ? z.run(console.timeStamp.bind(console, "Remaining Effects", T, H, me, "Scheduler ⚛", "secondary-dark")) : console.timeStamp("Remaining Effects", T, H, me, "Scheduler ⚛", "secondary-dark")), xi(f, H), Ur(0, !1), y0 ? i === om ? fc++ : (fc = 0, om = i) : fc = 0, y0 = Ab = !1, M && typeof M.onPostCommitFiberRoot == "function") try {
						M.onPostCommitFiberRoot(Ue, i);
					} catch (an) {
						ie || (ie = !0, console.error("React instrumentation encountered an error: %o", an));
					}
					var $ = i.current.stateNode;
					return $.effectDuration = 0, $.passiveEffectDuration = 0, !0;
				} finally {
					Je(s), N.T = o, sg(e, n);
				}
			}
			function ug(e, n, o) {
				n = Ot(o, n), Bf(n), n = fu(e.stateNode, n, 2), e = rr(e, n, 2), e !== null && (el(e, 2), jr(e));
			}
			function we(e, n, o) {
				if (xf = !1, e.tag === 3) ug(e, e, o);
				else {
					for (; n !== null;) {
						if (n.tag === 3) {
							ug(n, e, o);
							return;
						}
						if (n.tag === 1) {
							var i = n.stateNode;
							if (typeof n.type.getDerivedStateFromError == "function" || typeof i.componentDidCatch == "function" && (vs === null || !vs.has(i))) {
								e = Ot(o, e), Bf(e), o = pu(2), i = rr(n, o, 2), i !== null && (hu(o, i, n, e), el(i, 2), jr(i));
								return;
							}
						}
						n = n.return;
					}
					console.error(`Internal React error: Attempted to capture a commit phase error inside a detached tree. This indicates a bug in React. Potential causes include deleting the same fiber more than once, committing an already-finished tree, or an inconsistent return pointer.

Error message:

%s`, o);
				}
			}
			function Kp(e, n, o) {
				var i = e.pingCache;
				if (i === null) {
					i = e.pingCache = new O1();
					var s = /* @__PURE__ */ new Set();
					i.set(n, s);
				} else s = i.get(n), s === void 0 && (s = /* @__PURE__ */ new Set(), i.set(n, s));
				s.has(o) || (Tb = !0, s.add(o), i = E0.bind(null, e, n, o), Le && Ru(e, o), n.then(i, i));
			}
			function E0(e, n, o) {
				var i = e.pingCache;
				i !== null && i.delete(n), e.pingedLanes |= e.suspendedLanes & o, e.warmLanes &= ~o, (o & 127) !== 0 ? 0 > Ga && (us = Ga = Tn(), Nh = Ug("Promise Resolved"), cs = 2) : o & 4194048 && 0 > To && (ua = To = Tn(), Ih = Ug("Promise Resolved"), eb = 2), Gm() && N.actQueue === null && console.error(`A suspended resource finished loading inside a test, but the event was not wrapped in act(...).

When testing, code that resolves suspended data should be wrapped into act(...):

act(() => {
  /* finish loading suspended data */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://react.dev/link/wrap-tests-with-act`), Ge === e && (te & o) === o && ((fn === gs || fn === s0 && (te & 62914560) === te && Re() - f0 < e1) && (ve & pt) === ft ? Yo(e, 0) : Ib |= o, cc === te && (cc = 0)), jr(e);
			}
			function cg(e, n) {
				n === 0 && (n = ws()), e = tt(e, n), e !== null && (el(e, n), jr(e));
			}
			function _0(e) {
				var n = e.memoizedState, o = 0;
				n !== null && (o = n.retryLane), cg(e, o);
			}
			function N0(e, n) {
				var o = 0;
				switch (e.tag) {
					case 31:
					case 13:
						var i = e.stateNode, s = e.memoizedState;
						s !== null && (o = s.retryLane);
						break;
					case 19:
						i = e.stateNode;
						break;
					case 22:
						i = e.stateNode._retryCache;
						break;
					default: throw Error("Pinged unknown suspense boundary type. This is probably a bug in React.");
				}
				i !== null && i.delete(n), cg(e, o);
			}
			function eh(e, n, o) {
				if ((n.subtreeFlags & 134225920) !== 0) for (n = n.child; n !== null;) {
					var i = e, s = n, u = s.type === Ml;
					u = o || u, s.tag !== 22 ? s.flags & 134217728 ? u && B(s, dg, i, s) : eh(i, s, u) : s.memoizedState === null && (u && s.flags & 134225920 ? B(s, dg, i, s) : s.subtreeFlags & 134217728 && B(s, eh, i, s, u)), n = n.sibling;
				}
			}
			function dg(e, n) {
				Oe(!0);
				try {
					Om(n, ac), $m(n), Bm(e, n.alternate, n, ac), Ul(e, n, 0, null, !1, 0);
				} finally {
					Oe(!1);
				}
			}
			function fg(e) {
				var n = !0;
				e.current.mode & 24 || (n = !1), eh(e, e.current, n);
			}
			function pg(e) {
				if ((ve & pt) === ft) {
					var n = e.tag;
					if (n === 3 || n === 1 || n === 0 || n === 11 || n === 14 || n === 15) {
						if (n = G(e) || "ReactComponent", v0 !== null) {
							if (v0.has(n)) return;
							v0.add(n);
						} else v0 = /* @__PURE__ */ new Set([n]);
						B(e, function() {
							console.error("Can't perform a React state update on a component that hasn't mounted yet. This indicates that you have a side-effect in your render function that asynchronously tries to update the component. Move this work to useEffect instead.");
						});
					}
				}
			}
			function Ru(e, n) {
				Le && e.memoizedUpdaters.forEach(function(o) {
					Rf(e, o, n);
				});
			}
			function T0(e, n) {
				var o = N.actQueue;
				return o !== null ? (o.push(n), M1) : U(e, n);
			}
			function I0(e) {
				Gm() && N.actQueue === null && B(e, function() {
					console.error(`An update to %s inside a test was not wrapped in act(...).

When testing, code that causes React state updates should be wrapped into act(...):

act(() => {
  /* fire events that update state */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://react.dev/link/wrap-tests-with-act`, G(e));
				});
			}
			function Bl(e) {
				if (Zi === null) return e;
				var n = Zi(e);
				return n === void 0 ? e : n.current;
			}
			function hg(e, n) {
				if (Zi === null) return !1;
				var o = Zi, i = e.elementType;
				n = n.type;
				var s = !1, u = typeof n == "object" && n !== null ? n.$$typeof : null;
				switch (e.tag) {
					case 1:
						typeof n == "function" && (s = !0);
						break;
					case 0:
						(typeof n == "function" || u === qn) && (s = !0);
						break;
					case 11:
						(u === Fd || u === qn) && (s = !0);
						break;
					case 14:
					case 15:
						(u === Ei || u === qn) && (s = !0);
						break;
					default: return !1;
				}
				return !!(s && (e = o(i), e !== void 0 && e === o(n)));
			}
			function mg(e) {
				Zi !== null && typeof WeakSet == "function" && (Cf === null && (Cf = /* @__PURE__ */ new WeakSet()), Cf.add(e));
			}
			function gg(e, n, o) {
				do {
					var i = e, s = i.alternate, u = i.child, f = i.sibling, p = i.tag, g = i.type, b = i.elementType, k = null;
					switch (i = null, p) {
						case 0:
						case 1:
							k = g;
							break;
						case 15:
							k = g, i = b;
							break;
						case 14:
							i = b;
							break;
						case 11: k = g.render, i = b;
					}
					if (Zi === null) throw Error("Expected resolveFamily to be set during hot reload.");
					var z = Zi;
					if (g = b = !1, k !== null && (k = z(k), k !== void 0 && (o.has(k) ? g = !0 : n.has(k) && (p === 1 ? g = !0 : b = !0))), g || i === null || (p = z(i), p !== void 0 && o.has(p) ? g = !0 : typeof i == "object" && i.$$typeof === qn && (p = i._payload, p._status === 1 && (p = z(p._result.default), p !== void 0 && o.has(p) && (g = !0)))), Cf !== null && (Cf.has(e) || s !== null && Cf.has(s)) && (g = !0), g && (e._debugNeedsRemount = !0), (g || b) && (s = tt(e, 2), s !== null && nn(s, e, 2)), u === null || g || gg(u, n, o), f === null) break;
					e = f;
				} while (!0);
			}
			function R0(e, n, o, i) {
				this.tag = e, this.key = o, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = n, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = i, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null, this.actualDuration = -0, this.actualStartTime = -1.1, this.treeBaseDuration = this.selfBaseDuration = -0, this._debugTask = this._debugStack = this._debugOwner = this._debugInfo = null, this._debugNeedsRemount = !1, this._debugHookTypes = null, s1 || typeof Object.preventExtensions != "function" || Object.preventExtensions(this);
			}
			function nh(e) {
				return e = e.prototype, !(!e || !e.isReactComponent);
			}
			function Ko(e, n) {
				var o = e.alternate;
				switch (o === null ? (o = ht(e.tag, n, e.key, e.mode), o.elementType = e.elementType, o.type = e.type, o.stateNode = e.stateNode, o._debugOwner = e._debugOwner, o._debugStack = e._debugStack, o._debugTask = e._debugTask, o._debugHookTypes = e._debugHookTypes, o.alternate = e, e.alternate = o) : (o.pendingProps = n, o.type = e.type, o.flags = 0, o.subtreeFlags = 0, o.deletions = null, o.actualDuration = -0, o.actualStartTime = -1.1), o.flags = e.flags & 1206910976, o.childLanes = e.childLanes, o.lanes = e.lanes, o.child = e.child, o.memoizedProps = e.memoizedProps, o.memoizedState = e.memoizedState, o.updateQueue = e.updateQueue, n = e.dependencies, o.dependencies = n === null ? null : {
					lanes: n.lanes,
					firstContext: n.firstContext,
					_debugThenableState: n._debugThenableState
				}, o.sibling = e.sibling, o.index = e.index, o.ref = e.ref, o.refCleanup = e.refCleanup, o.selfBaseDuration = e.selfBaseDuration, o.treeBaseDuration = e.treeBaseDuration, o._debugInfo = e._debugInfo, o._debugNeedsRemount = e._debugNeedsRemount, o.tag) {
					case 0:
					case 15:
					case 14:
					case 1:
					case 11: o.type = Bl(e.type);
				}
				return o;
			}
			function bg(e, n) {
				e.flags &= 1206910978;
				var o = e.alternate;
				return o === null ? (e.childLanes = 0, e.lanes = n, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null, e.selfBaseDuration = 0, e.treeBaseDuration = 0) : (e.childLanes = o.childLanes, e.lanes = o.lanes, e.child = o.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = o.memoizedProps, e.memoizedState = o.memoizedState, e.updateQueue = o.updateQueue, e.type = o.type, n = o.dependencies, e.dependencies = n === null ? null : {
					lanes: n.lanes,
					firstContext: n.firstContext,
					_debugThenableState: n._debugThenableState
				}, e.selfBaseDuration = o.selfBaseDuration, e.treeBaseDuration = o.treeBaseDuration), e;
			}
			function Td(e, n, o, i, s, u) {
				var f = 0, p = Bl(e);
				if (typeof p == "function") nh(p) && (f = 1);
				else if (typeof p == "string") Ze && je ? (f = Cr(), f = Kd(e, o, f) ? 26 : Qu(e) ? 27 : 5) : Ze ? (f = Cr(), f = Kd(e, o, f) ? 26 : 5) : f = je && Qu(e) ? 27 : 5;
				else e: switch (p) {
					case $l: return n = ht(31, o, n, s), n.elementType = $l, n.lanes = u, n;
					case Qr: return zi(o.children, s, u, n);
					case Ml:
						f = 8, s |= 24;
						break;
					case Wa: return e = o, i = s, typeof e.id != "string" && console.error("Profiler must specify an \"id\" of type `string` as a prop. Received the type `%s` instead.", typeof e.id), n = ht(12, e, n, i | 2), n.elementType = Wa, n.lanes = u, n.stateNode = {
						effectDuration: 0,
						passiveEffectDuration: 0
					}, n;
					case lh: return n = ht(13, o, n, s), n.elementType = lh, n.lanes = u, n;
					case Vl: return n = ht(19, o, n, s), n.elementType = Vl, n.lanes = u, n;
					case sh:
					case uh: return e = s | 32, n = ht(30, o, n, e), n.elementType = uh, n.lanes = u, n.stateNode = {
						autoName: null,
						paired: null,
						clones: null,
						ref: null
					}, n;
					default:
						if (typeof p == "object" && p !== null) switch (p.$$typeof) {
							case sn:
								f = 10;
								break e;
							case Aa:
								f = 9;
								break e;
							case Fd:
								f = 11;
								break e;
							case Ei:
								f = 14;
								break e;
							case qn:
								f = 16, p = null;
								break e;
						}
						o = "", (e === void 0 || typeof e == "object" && e !== null && Object.keys(e).length === 0) && (o += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports."), e === null ? p = "null" : Gn(e) ? p = "array" : e !== void 0 && e.$$typeof === xo ? (p = "<" + (en(e.type) || "Unknown") + " />", o = " Did you accidentally export a JSX literal instead of a component?") : p = typeof e, f = i ? typeof i.tag == "number" ? G(i) : typeof i.name == "string" ? i.name : null : null, f && (o += `

Check the render method of \`` + f + "`."), f = 29, o = Error("Element type is invalid: expected a string (for built-in components) or a class/function (for composite components) but got: " + (p + "." + o)), p = null;
				}
				return n = ht(f, o, n, s), n.elementType = e, n.type = p, n.lanes = u, n._debugOwner = i, n;
			}
			function Id(e, n, o) {
				return n = Td(e.type, e.key, e.props, e._owner, n, o), n._debugOwner = e._owner, n._debugStack = e._debugStack, n._debugTask = e._debugTask, n;
			}
			function zi(e, n, o, i) {
				return e = ht(7, e, i, n), e.lanes = o, e;
			}
			function Nt(e, n, o) {
				return e = ht(6, e, null, n), e.lanes = o, e;
			}
			function th(e) {
				var n = ht(18, null, null, Z);
				return n.stateNode = e, n;
			}
			function Hl(e, n, o) {
				return n = ht(4, e.children !== null ? e.children : [], e.key, n), n.lanes = o, n.stateNode = {
					containerInfo: e.containerInfo,
					pendingChildren: null,
					implementation: e.implementation
				}, n;
			}
			function yg(e, n, o, i, s, u, f, p, g) {
				for (this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = Wn, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Tf(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Tf(0), this.hiddenUpdates = Tf(null), this.identifierPrefix = i, this.onUncaughtError = s, this.onCaughtError = u, this.onRecoverableError = f, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = g, this.transitionTypes = null, this.incompleteTransitions = /* @__PURE__ */ new Map(), this.passiveEffectDuration = this.effectDuration = -0, this.memoizedUpdaters = /* @__PURE__ */ new Set(), e = this.pendingUpdatersLaneMap = [], n = 0; 31 > n; n++) e.push(/* @__PURE__ */ new Set());
				this._debugRootType = o ? "hydrateRoot()" : "createRoot()";
			}
			function rh(e, n, o, i, s, u, f, p, g, b, k, z) {
				return e = new yg(e, n, o, f, g, b, k, z, p), n = 1, u === !0 && (n |= 24), u = ht(3, null, null, n | 2), e.current = u, u.stateNode = e, n = pl(), Mo(n), e.pooledCache = n, Mo(n), u.memoizedState = {
					element: i,
					isDehydrated: o,
					cache: n
				}, Lc(u), e;
			}
			function oh(e) {
				return "" + e;
			}
			function vg(e) {
				return e ? (e = c, e) : c;
			}
			function Rd(e, n, o, i) {
				return Ld(n.current, 2, e, n, o, i), 2;
			}
			function Ld(e, n, o, i, s, u) {
				if (M && typeof M.onScheduleFiberRoot == "function") try {
					M.onScheduleFiberRoot(Ue, i, o);
				} catch (f) {
					ie || (ie = !0, console.error("React instrumentation encountered an error: %o", f));
				}
				s = vg(s), i.context === null ? i.context = s : i.pendingContext = s, Qa && Bi !== null && !u1 && (u1 = !0, console.error(`Render methods should be a pure function of props and state; triggering nested component updates from render is not allowed. If necessary, trigger nested updates in componentDidUpdate.

Check the render method of %s.`, G(Bi) || "Unknown")), i = Vo(n), i.payload = { element: o }, u = u === void 0 ? null : u, u !== null && (typeof u != "function" && console.error("Expected the last optional `callback` argument to be a function. Instead received: %s.", u), i.callback = u), o = rr(e, i, n), o !== null && (tr(n, "root.render()", null), nn(o, e, n), Sl(o, e, n));
			}
			function ah(e, n) {
				if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
					var o = e.retryLane;
					e.retryLane = o !== 0 && o < n ? o : n;
				}
			}
			function ih(e, n) {
				ah(e, n), (e = e.alternate) && ah(e, n);
			}
			function L0() {
				return Bi;
			}
			var ce = {}, F0 = import_react.default, be = import_scheduler.default, Un = Object.assign, D0 = Symbol.for("react.element"), xo = Symbol.for("react.transitional.element"), Ua = Symbol.for("react.portal"), Qr = Symbol.for("react.fragment"), Ml = Symbol.for("react.strict_mode"), Wa = Symbol.for("react.profiler"), Aa = Symbol.for("react.consumer"), sn = Symbol.for("react.context"), Fd = Symbol.for("react.forward_ref"), lh = Symbol.for("react.suspense"), Vl = Symbol.for("react.suspense_list"), Ei = Symbol.for("react.memo"), qn = Symbol.for("react.lazy");
			var $l = Symbol.for("react.activity"), sh = Symbol.for("react.legacy_hidden");
			var j0 = Symbol.for("react.memo_cache_sentinel"), uh = Symbol.for("react.view_transition"), Tt = Symbol.for("react.recoverable"), ch = Symbol.iterator, Sg = Symbol.for("react.optimistic_key"), dh = Symbol.for("react.client.reference"), Gn = Array.isArray, N = F0.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, U0 = m.rendererVersion, Lu = m.rendererPackageName, It = m.extraDevToolsConfig, Ql = m.getPublicInstance, $t = m.getRootHostContext, kg = m.getChildHostContext, W0 = m.prepareForCommit, fh = m.resetAfterCommit, wg = m.createInstance;
			m.cloneMutableInstance;
			var Fu = m.appendInitialChild, ph = m.finalizeInitialChildren, ea = m.shouldSetTextContent, _i = m.createTextInstance;
			m.cloneMutableTextInstance;
			var Dd = m.scheduleTimeout, Du = m.cancelTimeout, Wn = m.noTimeout, yn = m.isPrimaryRenderer;
			m.warnsIfNotActing;
			var _e = m.supportsMutation, _n = m.supportsPersistence, $e = m.supportsHydration, Jn = m.getInstanceFromNode;
			m.beforeActiveInstanceBlur;
			var ju = m.preparePortalMount;
			m.prepareScopeUpdate, m.getInstanceFromScope;
			var Je = m.setCurrentUpdatePriority, fr = m.getCurrentUpdatePriority, Nn = m.resolveUpdatePriority, Qe = m.trackSchedulerEvent, ne = m.resolveEventType, pr = m.resolveEventTimeStamp, hr = m.shouldAttemptEagerTransition, hh = m.detachDeletedInstance;
			m.requestPostPaintCallback;
			var jd = m.maySuspendCommit, Ni = m.maySuspendCommitOnUpdate, qr = m.maySuspendCommitInSyncRender, Pg = m.preloadInstance, A0 = m.startSuspendingCommit, xg = m.suspendInstance, tn = m.suspendOnActiveViewTransition, Uu = m.waitForCommitToBeReady, ql = m.getSuspendedCommitReason, Gr = m.NotPendingTransition, Jr = m.HostTransitionContext, Ud = m.resetFormInstance, mh = m.bindToConsole, Ti = m.supportsMicrotasks, Wu = m.scheduleMicrotask, Oa = m.supportsTestSelectors, Ii = m.findFiberRoot, Gl = m.getBoundingRect, Cg = m.getTextContent, Zr = m.isHiddenSubtree, Jl = m.matchAccessibilityRole, gh = m.setFocusIfFocusable, Wd = m.setupIntersectionObserver, Ad = m.appendChild, Ri = m.appendChildToContainer, Zl = m.commitTextUpdate, Au = m.commitMount, Li = m.commitUpdate, zg = m.insertBefore, mr = m.insertInContainerBefore, Xl = m.removeChild, bh = m.removeChildFromContainer, na = m.resetTextContent, yh = m.hideInstance, Ba = m.hideTextInstance, Od = m.unhideInstance, Zn = m.unhideTextInstance, lt = m.applyViewTransitionName, Xn = m.restoreViewTransitionName, ta = m.cancelViewTransitionName, re = m.cancelRootViewTransitionName, De = m.restoreRootViewTransitionName;
			m.cloneRootViewTransitionContainer, m.removeRootViewTransitionClone;
			var un = m.measureInstance, Bd = m.measureClonedInstance, ra = m.wasInstanceInViewport, Fi = m.hasInstanceChanged, Hd = m.hasInstanceAffectedParent, Ou = m.startViewTransition;
			m.startGestureTransition;
			var Yl = m.stopViewTransition, O0 = m.addViewTransitionFinishedListener;
			m.getCurrentGestureOffset;
			var Bu = m.createViewTransitionInstance, Eg = m.clearContainer, _g = m.createFragmentInstance, B0 = m.updateFragmentInstanceFiber, Md = m.commitNewChildToFragmentInstance, vh = m.deleteChildFromFragmentInstance, Pn = m.cloneInstance, Vd = m.createContainerChildSet, Yn = m.appendChildToContainerChildSet, $d = m.finalizeContainerChildren, Rt = m.replaceContainerChildren, Xr = m.cloneHiddenInstance, vt = m.cloneHiddenTextInstance, xn = m.isSuspenseInstancePending, Ce = m.isSuspenseInstanceFallback, Co = m.getSuspenseInstanceFallbackErrorDetails, Sh = m.registerSuspenseInstanceRetry, Ng = m.canHydrateFormStateMarker, An = m.isFormStateMarkerMatching, gr = m.getNextHydratableSibling, Hu = m.getNextHydratableSiblingAfterSingleton, Qd = m.getFirstHydratableChild, kh = m.getFirstHydratableChildWithinContainer, Cn = m.getFirstHydratableChildWithinActivityInstance, Lt = m.getFirstHydratableChildWithinSuspenseInstance, Yr = m.getFirstHydratableChildWithinSingleton, Di = m.canHydrateInstance, H0 = m.canHydrateTextInstance, qd = m.canHydrateActivityInstance, Gd = m.canHydrateSuspenseInstance, Jd = m.hydrateInstance, Zd = m.hydrateTextInstance, Xd = m.hydrateActivityInstance, Mu = m.hydrateSuspenseInstance, M0 = m.getNextHydratableInstanceAfterActivityInstance, de = m.getNextHydratableInstanceAfterSuspenseInstance, Be = m.commitHydratedInstance, he = m.commitHydratedContainer, ye = m.commitHydratedActivityInstance, Ie = m.commitHydratedSuspenseInstance, Qt = m.finalizeHydratedChildren, Ha = m.flushHydrationEvents;
			m.clearActivityBoundary;
			var Kl = m.clearSuspenseBoundary;
			m.clearActivityBoundaryFromContainer;
			var wh = m.clearSuspenseBoundaryFromContainer, oa = m.hideDehydratedBoundary, cn = m.unhideDehydratedBoundary, aa = m.shouldDeleteUnhydratedTailInstances, Ma = m.diffHydratedPropsForDevWarnings, Yd = m.diffHydratedTextForDevWarnings, Ft = m.describeHydratableInstanceForDevWarnings, es = m.validateHydratableInstance, Vu = m.validateHydratableTextInstance, Ze = m.supportsResources, Kd = m.isHostHoistableType, ji = m.getHoistableRoot, Ph = m.getResource, ns = m.acquireResource, $u = m.releaseResource, Va = m.hydrateHoistable, Xe = m.mountHoistable, qt = m.unmountHoistable, $a = m.createHoistableInstance, zo = m.prepareToCommitHoistables, xh = m.mayResourceSuspendCommit, ef = m.preloadResource, Tg = m.suspendResource, je = m.supportsSingletons, Ui = m.resolveSingletonInstance, ts = m.acquireSingletonInstance, rs = m.releaseSingletonInstance, Qu = m.isHostSingletonType, t = m.isSingletonScope, r = [], a = [], l = -1, c = {};
			Object.freeze(c);
			var d = Math.clz32 ? Math.clz32 : ga, h = Math.log, y = Math.LN2, C = 256, R = 262144, D = 4194304, U = be.unstable_scheduleCallback, A = be.unstable_cancelCallback, fe = be.unstable_shouldYield, Ne = be.unstable_requestPaint, Re = be.unstable_now, ia = be.unstable_ImmediatePriority, x = be.unstable_UserBlockingPriority, P = be.unstable_NormalPriority, E = be.unstable_IdlePriority, j = be.log, q = be.unstable_setDisableYieldValue, Ue = null, M = null, ie = !1, Le = typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u", Se = 0, la = 0;
			if (typeof performance == "object" && typeof performance.now == "function") var V0 = performance, Hb = function() {
				return V0.now();
			};
			else {
				var z1 = Date;
				Hb = function() {
					return z1.now();
				};
			}
			var Gt = typeof Object.is == "function" ? Object.is : nl, Mb = typeof reportError == "function" ? reportError : function(e) {
				if (typeof window == "object" && typeof window.ErrorEvent == "function") {
					var n = new window.ErrorEvent("error", {
						bubbles: !0,
						cancelable: !0,
						message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
						error: e
					});
					if (!window.dispatchEvent(n)) return;
				} else if (typeof process == "object" && typeof process.emit == "function") {
					process.emit("uncaughtException", e);
					return;
				}
				console.error(e);
			}, Ig = Object.prototype.hasOwnProperty, Ke = typeof console < "u" && typeof console.timeStamp == "function" && typeof performance < "u" && typeof performance.measure == "function", me = "Blocking", os = !1, Wi = {
				color: "primary",
				properties: null,
				tooltipText: "",
				track: "Components ⚛"
			}, as = {
				start: -0,
				end: -0,
				detail: { devtools: Wi }
			}, E1 = ["Changed Props", ""], _1 = ["Changed Props", "This component received deeply equal props. It might benefit from useMemo or the React Compiler in its owner."], Ch = 0, Vb, $b, Qb, qb, Gb, Jb, Zb;
			xr.__reactDisabledLog = !0;
			var $0, Xb, Q0 = !1, q0 = new (typeof WeakMap == "function" ? WeakMap : Map)(), G0 = /* @__PURE__ */ new WeakMap(), nf = [], tf = 0, Rg = null, zh = 0, Eo = [], _o = 0, qu = null, Ai = 1, Oi = "", is = Wt(null), Eh = Wt(null), ls = Wt(null), Lg = Wt(null), Yb = /["'&<>\n\t]|^\s|\s$/, Bi = null, Qa = !1, st = null, rn = null, le = !1, qa = !1, Kr = null, ss = null, No = !1, J0 = Error("Hydration Mismatch Exception: This is not a real error, and should not leak into userspace. If you're seeing this, it's likely a bug in React."), Z = 0, Fg = Wt(null), Z0 = Wt(null), X0 = Wt(null), Dg = {}, jg = null, rf = null, of = !1, N1 = typeof AbortController < "u" ? AbortController : function() {
				var e = [], n = this.signal = {
					aborted: !1,
					addEventListener: function(o, i) {
						e.push(i);
					}
				};
				this.abort = function() {
					n.aborted = !0, e.forEach(function(o) {
						return o();
					});
				};
			}, T1 = be.unstable_scheduleCallback, I1 = be.unstable_NormalPriority, vn = {
				$$typeof: sn,
				Consumer: null,
				Provider: null,
				_currentValue: null,
				_currentValue2: null,
				_threadCount: 0,
				_currentRenderer: null,
				_currentRenderer2: null
			}, _h = null, Tn = be.unstable_now, Ug = console.createTask ? console.createTask : function() {
				return null;
			}, ut = -0, Hi = -0, sa = -0, Mi = null, Jt = -1.1, Gu = -0, dn = -0, V = -1.1, J = -1.1, on = null, Sn = !1, us = -0, Ga = -1.1, Nh = null, cs = 0, Y0 = null, K0 = null, Ju = -1.1, Th = null, af = -1.1, Wg = -1.1, ua = -0, Vi = -1.1, To = -1.1, eb = 0, Ih = null, Kb = null, ey = null, ds = -1.1, Zu = null, fs = -1.1, Ag = -1.1, nb = -0, tb = -0, Xu = 0, br = null, ny = 0, Rh = -1.1, Og = !1, Bg = !1, lf = null, sf = null, rb = !1, ob = !1, Hg = !1, ab = !1, Yu = 0, ib = {}, Lh = null, lb = 0, ps = 0, uf = null, ty = N.S;
			N.S = function(e, n) {
				if (Ky = Re(), typeof n == "object" && n !== null && typeof n.then == "function") {
					if (0 > Vi && 0 > To) {
						Vi = Tn();
						var o = pr(), i = ne();
						(o !== fs || i !== Zu) && (fs = -1.1), ds = o, Zu = i;
					}
					hm(e, n);
				}
				if (_h !== null) for (o = lf; o !== null;) js(o, _h), o = o.next;
				if (o = e.types, o != null) {
					for (i = lf; i !== null;) js(i, o), i = i.next;
					if (ps !== 0) {
						i = _h, i === null && (i = _h = []);
						for (var s = 0; s < o.length; s++) {
							var u = o[s];
							i.indexOf(u) === -1 && i.push(u);
						}
					}
				}
				ty !== null && ty(e, n);
			};
			var Ku = Wt(null), ca = {
				recordUnsafeLifecycleWarnings: function() {},
				flushPendingUnsafeLifecycleWarnings: function() {},
				recordLegacyContextWarning: function() {},
				flushLegacyContextWarning: function() {},
				discardPendingWarnings: function() {}
			}, Fh = [], Dh = [], jh = [], Uh = [], Wh = [], Ah = [], ec = /* @__PURE__ */ new Set();
			ca.recordUnsafeLifecycleWarnings = function(e, n) {
				ec.has(e.type) || (typeof n.componentWillMount == "function" && n.componentWillMount.__suppressDeprecationWarning !== !0 && Fh.push(e), e.mode & 8 && typeof n.UNSAFE_componentWillMount == "function" && Dh.push(e), typeof n.componentWillReceiveProps == "function" && n.componentWillReceiveProps.__suppressDeprecationWarning !== !0 && jh.push(e), e.mode & 8 && typeof n.UNSAFE_componentWillReceiveProps == "function" && Uh.push(e), typeof n.componentWillUpdate == "function" && n.componentWillUpdate.__suppressDeprecationWarning !== !0 && Wh.push(e), e.mode & 8 && typeof n.UNSAFE_componentWillUpdate == "function" && Ah.push(e));
			}, ca.flushPendingUnsafeLifecycleWarnings = function() {
				var e = /* @__PURE__ */ new Set();
				0 < Fh.length && (Fh.forEach(function(p) {
					e.add(G(p) || "Component"), ec.add(p.type);
				}), Fh = []);
				var n = /* @__PURE__ */ new Set();
				0 < Dh.length && (Dh.forEach(function(p) {
					n.add(G(p) || "Component"), ec.add(p.type);
				}), Dh = []);
				var o = /* @__PURE__ */ new Set();
				0 < jh.length && (jh.forEach(function(p) {
					o.add(G(p) || "Component"), ec.add(p.type);
				}), jh = []);
				var i = /* @__PURE__ */ new Set();
				0 < Uh.length && (Uh.forEach(function(p) {
					i.add(G(p) || "Component"), ec.add(p.type);
				}), Uh = []);
				var s = /* @__PURE__ */ new Set();
				0 < Wh.length && (Wh.forEach(function(p) {
					s.add(G(p) || "Component"), ec.add(p.type);
				}), Wh = []);
				var u = /* @__PURE__ */ new Set();
				if (0 < Ah.length && (Ah.forEach(function(p) {
					u.add(G(p) || "Component"), ec.add(p.type);
				}), Ah = []), 0 < n.size) {
					var f = ao(n);
					console.error(`Using UNSAFE_componentWillMount in strict mode is not recommended and may indicate bugs in your code. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.

Please update the following components: %s`, f);
				}
				0 < i.size && (f = ao(i), console.error(`Using UNSAFE_componentWillReceiveProps in strict mode is not recommended and may indicate bugs in your code. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://react.dev/link/derived-state

Please update the following components: %s`, f)), 0 < u.size && (f = ao(u), console.error(`Using UNSAFE_componentWillUpdate in strict mode is not recommended and may indicate bugs in your code. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.

Please update the following components: %s`, f)), 0 < e.size && (f = ao(e), console.warn(`componentWillMount has been renamed, and is not recommended for use. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.
* Rename componentWillMount to UNSAFE_componentWillMount to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, f)), 0 < o.size && (f = ao(o), console.warn(`componentWillReceiveProps has been renamed, and is not recommended for use. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://react.dev/link/derived-state
* Rename componentWillReceiveProps to UNSAFE_componentWillReceiveProps to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, f)), 0 < s.size && (f = ao(s), console.warn(`componentWillUpdate has been renamed, and is not recommended for use. See https://react.dev/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* Rename componentWillUpdate to UNSAFE_componentWillUpdate to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, f));
			};
			var Mg = /* @__PURE__ */ new Map(), ry = /* @__PURE__ */ new Set();
			ca.recordLegacyContextWarning = function(e, n) {
				for (var o = null, i = e; i !== null;) i.mode & 8 && (o = i), i = i.return;
				o === null ? console.error("Expected to find a StrictMode component in a strict mode tree. This error is likely caused by a bug in React. Please file an issue.") : !ry.has(e.type) && (i = Mg.get(o), e.type.contextTypes != null || e.type.childContextTypes != null || n !== null && typeof n.getChildContext == "function") && (i === void 0 && (i = [], Mg.set(o, i)), i.push(e));
			}, ca.flushLegacyContextWarning = function() {
				Mg.forEach(function(e) {
					if (e.length !== 0) {
						var n = e[0], o = /* @__PURE__ */ new Set();
						e.forEach(function(s) {
							o.add(G(s) || "Component"), ry.add(s.type);
						});
						var i = ao(o);
						B(n, function() {
							console.error(`Legacy context API has been detected within a strict-mode tree.

The old API will be supported in all 16.x releases, but applications using it should migrate to the new version.

Please update the following components: %s

Learn more about this warning here: https://react.dev/link/legacy-context`, i);
						});
					}
				});
			}, ca.discardPendingWarnings = function() {
				Fh = [], Dh = [], jh = [], Uh = [], Wh = [], Ah = [], Mg = /* @__PURE__ */ new Map();
			};
			var R1 = "", oy = { react_stack_bottom_frame: function(e, n, o) {
				var i = Qa;
				Qa = !0;
				try {
					return e(n, o);
				} finally {
					Qa = i;
				}
			} }, sb = oy.react_stack_bottom_frame.bind(oy), ay = { react_stack_bottom_frame: function(e) {
				var n = Qa;
				Qa = !0;
				try {
					return e.render();
				} finally {
					Qa = n;
				}
			} }, iy = ay.react_stack_bottom_frame.bind(ay), ly = { react_stack_bottom_frame: function(e, n) {
				try {
					n.componentDidMount();
				} catch (o) {
					we(e, e.return, o);
				}
			} }, ub = ly.react_stack_bottom_frame.bind(ly), sy = { react_stack_bottom_frame: function(e, n, o, i, s) {
				try {
					n.componentDidUpdate(o, i, s);
				} catch (u) {
					we(e, e.return, u);
				}
			} }, uy = sy.react_stack_bottom_frame.bind(sy), cy = { react_stack_bottom_frame: function(e, n) {
				var o = n.stack;
				e.componentDidCatch(n.value, { componentStack: o !== null ? o : "" });
			} }, L1 = cy.react_stack_bottom_frame.bind(cy), dy = { react_stack_bottom_frame: function(e, n, o) {
				try {
					o.componentWillUnmount();
				} catch (i) {
					we(e, n, i);
				}
			} }, fy = dy.react_stack_bottom_frame.bind(dy), py = { react_stack_bottom_frame: function(e) {
				var n = e.create;
				return e = e.inst, n = n(), e.destroy = n;
			} }, F1 = py.react_stack_bottom_frame.bind(py), hy = { react_stack_bottom_frame: function(e, n, o) {
				try {
					o();
				} catch (i) {
					we(e, n, i);
				}
			} }, D1 = hy.react_stack_bottom_frame.bind(hy), my = { react_stack_bottom_frame: function(e) {
				var n = e._init;
				return n(e._payload);
			} }, j1 = my.react_stack_bottom_frame.bind(my), cf = Error("Suspense Exception: This is not a real error! It's an implementation detail of `use` to interrupt the current render. You must either rethrow it immediately, or move the `use` call outside of the `try/catch` block. Capturing without rethrowing will lead to unexpected behavior.\n\nTo handle async errors, wrap your component in an error boundary, or call the promise's `.catch` method and pass the result to `use`."), cb = Error("Suspense Exception: This is not a real error, and should not leak into userspace. If you're seeing this, it's likely a bug in React."), Vg = Error("Suspense Exception: This is not a real error! It's an implementation detail of `useActionState` to interrupt the current render. You must either rethrow it immediately, or move the `useActionState` call outside of the `try/catch` block. Capturing without rethrowing will lead to unexpected behavior.\n\nTo handle async errors, wrap your component in an error boundary."), $g = { then: function() {
				console.error("Internal React error: A listener was unexpectedly attached to a \"noop\" thenable. This is a bug in React. Please file an issue.");
			} }, nc = null, Qg = null, db = !1, tc = null, Oh = !1, df = null, Bh = 0, pe = null, fb, gy = fb = !1, by = {}, yy = {}, vy = {};
			ma = function(e, n, o) {
				if (o !== null && typeof o == "object" && o._store && (!o._store.validated && o.key == null || o._store.validated === 2)) {
					if (typeof o._store != "object") throw Error("React Component in warnForMissingKey should have a _store. This error is likely caused by a bug in React. Please file an issue.");
					o._store.validated = 1;
					var i = G(e), s = i || "null";
					if (!by[s]) {
						by[s] = !0, o = o._owner, e = e._debugOwner;
						var u = "";
						e && typeof e.tag == "number" && (s = G(e)) && (u = `

Check the render method of \`` + s + "`."), u || i && (u = `

Check the top-level render call using <` + i + ">.");
						var f = "";
						o != null && e !== o && (i = null, typeof o.tag == "number" ? i = G(o) : typeof o.name == "string" && (i = o.name), i && (f = " It was passed a child from " + i + ".")), B(n, function() {
							console.error("Each child in a list should have a unique \"key\" prop.%s%s See https://react.dev/link/warning-keys for more information.", u, f);
						});
					}
				}
			};
			var rc = $s(!0), Sy = $s(!1), Hh = 1, $i = 2, Io = [], ff = 0, pb = 0, ky = 0, wy = 1, Py = 2, hb = 3, hs = !1, xy = !1, mb = null, gb = !1, ms = Wt(null), qg = Wt(0), St = Wt(null), Zt = null, pf = 1, Mh = 2, kt = Wt(0), Vh = 0, Ro = 1, Xt = 2, eo = 4, Dt = 8, hf, Cy = /* @__PURE__ */ new Set(), zy = /* @__PURE__ */ new Set(), bb = /* @__PURE__ */ new Set(), Ey = /* @__PURE__ */ new Set(), Qi = 0, X = null, qe = null, On = null, Gg = !1, mf = !1, oc = !1, Jg = 0, $h = 0, Ja = null, U1 = 0, W1 = 25, _ = null, Lo = null, qi = -1, Qh = !1, Zg = {
				readContext: K,
				use: Or,
				useCallback: Ee,
				useContext: Ee,
				useEffect: Ee,
				useImperativeHandle: Ee,
				useLayoutEffect: Ee,
				useInsertionEffect: Ee,
				useMemo: Ee,
				useReducer: Ee,
				useRef: Ee,
				useState: Ee,
				useDebugValue: Ee,
				useDeferredValue: Ee,
				useTransition: Ee,
				useSyncExternalStore: Ee,
				useId: Ee,
				useHostTransitionStatus: Ee,
				useFormState: Ee,
				useActionState: Ee,
				useOptimistic: Ee,
				useMemoCache: Ee,
				useCacheRefresh: Ee,
				useEffectEvent: Ee
			}, yb = null, _y = null, vb = null, Ny = null, Za = null, da = null, Xg = null;
			yb = {
				readContext: function(e) {
					return K(e);
				},
				use: Or,
				useCallback: function(e, n) {
					return _ = "useCallback", ee(), Pa(n), Jc(e, n);
				},
				useContext: function(e) {
					return _ = "useContext", ee(), K(e);
				},
				useEffect: function(e, n) {
					return _ = "useEffect", ee(), Pa(n), lu(e, n);
				},
				useImperativeHandle: function(e, n, o) {
					return _ = "useImperativeHandle", ee(), Pa(o), hp(e, n, o);
				},
				useInsertionEffect: function(e, n) {
					_ = "useInsertionEffect", ee(), Pa(n), qo(4, Xt, e, n);
				},
				useLayoutEffect: function(e, n) {
					return _ = "useLayoutEffect", ee(), Pa(n), uu(e, n);
				},
				useMemo: function(e, n) {
					_ = "useMemo", ee(), Pa(n);
					var o = N.H;
					N.H = Za;
					try {
						return Zc(e, n);
					} finally {
						N.H = o;
					}
				},
				useReducer: function(e, n, o) {
					_ = "useReducer", ee();
					var i = N.H;
					N.H = Za;
					try {
						return lp(e, n, o);
					} finally {
						N.H = i;
					}
				},
				useRef: function(e) {
					return _ = "useRef", ee(), iu(e);
				},
				useState: function(e) {
					_ = "useState", ee();
					var n = N.H;
					N.H = Za;
					try {
						return di(e);
					} finally {
						N.H = n;
					}
				},
				useDebugValue: function() {
					_ = "useDebugValue", ee();
				},
				useDeferredValue: function(e, n) {
					return _ = "useDeferredValue", ee(), Xc(e, n);
				},
				useTransition: function() {
					return _ = "useTransition", ee(), nd();
				},
				useSyncExternalStore: function(e, n, o) {
					return _ = "useSyncExternalStore", ee(), So(e, n, o);
				},
				useId: function() {
					return _ = "useId", ee(), td();
				},
				useFormState: function(e, n) {
					return _ = "useFormState", ee(), Ys(), fi(e, n);
				},
				useActionState: function(e, n) {
					return _ = "useActionState", ee(), fi(e, n);
				},
				useOptimistic: function(e) {
					return _ = "useOptimistic", ee(), tu(e);
				},
				useHostTransitionStatus: or,
				useMemoCache: Br,
				useCacheRefresh: function() {
					return _ = "useCacheRefresh", ee(), ar();
				},
				useEffectEvent: function(e) {
					return _ = "useEffectEvent", ee(), zl(e);
				}
			}, _y = {
				readContext: function(e) {
					return K(e);
				},
				use: Or,
				useCallback: function(e, n) {
					return _ = "useCallback", L(), Jc(e, n);
				},
				useContext: function(e) {
					return _ = "useContext", L(), K(e);
				},
				useEffect: function(e, n) {
					return _ = "useEffect", L(), lu(e, n);
				},
				useImperativeHandle: function(e, n, o) {
					return _ = "useImperativeHandle", L(), hp(e, n, o);
				},
				useInsertionEffect: function(e, n) {
					_ = "useInsertionEffect", L(), qo(4, Xt, e, n);
				},
				useLayoutEffect: function(e, n) {
					return _ = "useLayoutEffect", L(), uu(e, n);
				},
				useMemo: function(e, n) {
					_ = "useMemo", L();
					var o = N.H;
					N.H = Za;
					try {
						return Zc(e, n);
					} finally {
						N.H = o;
					}
				},
				useReducer: function(e, n, o) {
					_ = "useReducer", L();
					var i = N.H;
					N.H = Za;
					try {
						return lp(e, n, o);
					} finally {
						N.H = i;
					}
				},
				useRef: function(e) {
					return _ = "useRef", L(), iu(e);
				},
				useState: function(e) {
					_ = "useState", L();
					var n = N.H;
					N.H = Za;
					try {
						return di(e);
					} finally {
						N.H = n;
					}
				},
				useDebugValue: function() {
					_ = "useDebugValue", L();
				},
				useDeferredValue: function(e, n) {
					return _ = "useDeferredValue", L(), Xc(e, n);
				},
				useTransition: function() {
					return _ = "useTransition", L(), nd();
				},
				useSyncExternalStore: function(e, n, o) {
					return _ = "useSyncExternalStore", L(), So(e, n, o);
				},
				useId: function() {
					return _ = "useId", L(), td();
				},
				useActionState: function(e, n) {
					return _ = "useActionState", L(), fi(e, n);
				},
				useFormState: function(e, n) {
					return _ = "useFormState", L(), Ys(), fi(e, n);
				},
				useOptimistic: function(e) {
					return _ = "useOptimistic", L(), tu(e);
				},
				useHostTransitionStatus: or,
				useMemoCache: Br,
				useCacheRefresh: function() {
					return _ = "useCacheRefresh", L(), ar();
				},
				useEffectEvent: function(e) {
					return _ = "useEffectEvent", L(), zl(e);
				}
			}, vb = {
				readContext: function(e) {
					return K(e);
				},
				use: Or,
				useCallback: function(e, n) {
					return _ = "useCallback", L(), El(e, n);
				},
				useContext: function(e) {
					return _ = "useContext", L(), K(e);
				},
				useEffect: function(e, n) {
					_ = "useEffect", L(), at(2048, Dt, e, n);
				},
				useImperativeHandle: function(e, n, o) {
					return _ = "useImperativeHandle", L(), hi(e, n, o);
				},
				useInsertionEffect: function(e, n) {
					return _ = "useInsertionEffect", L(), at(4, Xt, e, n);
				},
				useLayoutEffect: function(e, n) {
					return _ = "useLayoutEffect", L(), at(4, eo, e, n);
				},
				useMemo: function(e, n) {
					_ = "useMemo", L();
					var o = N.H;
					N.H = da;
					try {
						return _l(e, n);
					} finally {
						N.H = o;
					}
				},
				useReducer: function(e, n, o) {
					_ = "useReducer", L();
					var i = N.H;
					N.H = da;
					try {
						return xl(e, n, o);
					} finally {
						N.H = i;
					}
				},
				useRef: function() {
					return _ = "useRef", L(), xe().memoizedState;
				},
				useState: function() {
					_ = "useState", L();
					var e = N.H;
					N.H = da;
					try {
						return xl(ge);
					} finally {
						N.H = e;
					}
				},
				useDebugValue: function() {
					_ = "useDebugValue", L();
				},
				useDeferredValue: function(e, n) {
					return _ = "useDeferredValue", L(), xt(e, n);
				},
				useTransition: function() {
					return _ = "useTransition", L(), Vn();
				},
				useSyncExternalStore: function(e, n, o) {
					return _ = "useSyncExternalStore", L(), nu(e, n, o);
				},
				useId: function() {
					return _ = "useId", L(), xe().memoizedState;
				},
				useFormState: function(e) {
					return _ = "useFormState", L(), Ys(), au(e);
				},
				useActionState: function(e) {
					return _ = "useActionState", L(), au(e);
				},
				useOptimistic: function(e, n) {
					return _ = "useOptimistic", L(), Vc(e, n);
				},
				useHostTransitionStatus: or,
				useMemoCache: Br,
				useCacheRefresh: function() {
					return _ = "useCacheRefresh", L(), xe().memoizedState;
				},
				useEffectEvent: function(e) {
					return _ = "useEffectEvent", L(), su(e);
				}
			}, Ny = {
				readContext: function(e) {
					return K(e);
				},
				use: Or,
				useCallback: function(e, n) {
					return _ = "useCallback", L(), El(e, n);
				},
				useContext: function(e) {
					return _ = "useContext", L(), K(e);
				},
				useEffect: function(e, n) {
					_ = "useEffect", L(), at(2048, Dt, e, n);
				},
				useImperativeHandle: function(e, n, o) {
					return _ = "useImperativeHandle", L(), hi(e, n, o);
				},
				useInsertionEffect: function(e, n) {
					return _ = "useInsertionEffect", L(), at(4, Xt, e, n);
				},
				useLayoutEffect: function(e, n) {
					return _ = "useLayoutEffect", L(), at(4, eo, e, n);
				},
				useMemo: function(e, n) {
					_ = "useMemo", L();
					var o = N.H;
					N.H = Xg;
					try {
						return _l(e, n);
					} finally {
						N.H = o;
					}
				},
				useReducer: function(e, n, o) {
					_ = "useReducer", L();
					var i = N.H;
					N.H = Xg;
					try {
						return $o(e, n, o);
					} finally {
						N.H = i;
					}
				},
				useRef: function() {
					return _ = "useRef", L(), xe().memoizedState;
				},
				useState: function() {
					_ = "useState", L();
					var e = N.H;
					N.H = Xg;
					try {
						return $o(ge);
					} finally {
						N.H = e;
					}
				},
				useDebugValue: function() {
					_ = "useDebugValue", L();
				},
				useDeferredValue: function(e, n) {
					return _ = "useDeferredValue", L(), Yc(e, n);
				},
				useTransition: function() {
					return _ = "useTransition", L(), gp();
				},
				useSyncExternalStore: function(e, n, o) {
					return _ = "useSyncExternalStore", L(), nu(e, n, o);
				},
				useId: function() {
					return _ = "useId", L(), xe().memoizedState;
				},
				useFormState: function(e) {
					return _ = "useFormState", L(), Ys(), Mt(e);
				},
				useActionState: function(e) {
					return _ = "useActionState", L(), Mt(e);
				},
				useOptimistic: function(e, n) {
					return _ = "useOptimistic", L(), Qc(e, n);
				},
				useHostTransitionStatus: or,
				useMemoCache: Br,
				useCacheRefresh: function() {
					return _ = "useCacheRefresh", L(), xe().memoizedState;
				},
				useEffectEvent: function(e) {
					return _ = "useEffectEvent", L(), su(e);
				}
			}, Za = {
				readContext: function(e) {
					return Te(), K(e);
				},
				use: function(e) {
					return W(), Or(e);
				},
				useCallback: function(e, n) {
					return _ = "useCallback", W(), ee(), Jc(e, n);
				},
				useContext: function(e) {
					return _ = "useContext", W(), ee(), K(e);
				},
				useEffect: function(e, n) {
					return _ = "useEffect", W(), ee(), lu(e, n);
				},
				useImperativeHandle: function(e, n, o) {
					return _ = "useImperativeHandle", W(), ee(), hp(e, n, o);
				},
				useInsertionEffect: function(e, n) {
					_ = "useInsertionEffect", W(), ee(), qo(4, Xt, e, n);
				},
				useLayoutEffect: function(e, n) {
					return _ = "useLayoutEffect", W(), ee(), uu(e, n);
				},
				useMemo: function(e, n) {
					_ = "useMemo", W(), ee();
					var o = N.H;
					N.H = Za;
					try {
						return Zc(e, n);
					} finally {
						N.H = o;
					}
				},
				useReducer: function(e, n, o) {
					_ = "useReducer", W(), ee();
					var i = N.H;
					N.H = Za;
					try {
						return lp(e, n, o);
					} finally {
						N.H = i;
					}
				},
				useRef: function(e) {
					return _ = "useRef", W(), ee(), iu(e);
				},
				useState: function(e) {
					_ = "useState", W(), ee();
					var n = N.H;
					N.H = Za;
					try {
						return di(e);
					} finally {
						N.H = n;
					}
				},
				useDebugValue: function() {
					_ = "useDebugValue", W(), ee();
				},
				useDeferredValue: function(e, n) {
					return _ = "useDeferredValue", W(), ee(), Xc(e, n);
				},
				useTransition: function() {
					return _ = "useTransition", W(), ee(), nd();
				},
				useSyncExternalStore: function(e, n, o) {
					return _ = "useSyncExternalStore", W(), ee(), So(e, n, o);
				},
				useId: function() {
					return _ = "useId", W(), ee(), td();
				},
				useFormState: function(e, n) {
					return _ = "useFormState", W(), ee(), fi(e, n);
				},
				useActionState: function(e, n) {
					return _ = "useActionState", W(), ee(), fi(e, n);
				},
				useOptimistic: function(e) {
					return _ = "useOptimistic", W(), ee(), tu(e);
				},
				useMemoCache: function(e) {
					return W(), Br(e);
				},
				useHostTransitionStatus: or,
				useCacheRefresh: function() {
					return _ = "useCacheRefresh", ee(), ar();
				},
				useEffectEvent: function(e) {
					return _ = "useEffectEvent", W(), ee(), zl(e);
				}
			}, da = {
				readContext: function(e) {
					return Te(), K(e);
				},
				use: function(e) {
					return W(), Or(e);
				},
				useCallback: function(e, n) {
					return _ = "useCallback", W(), L(), El(e, n);
				},
				useContext: function(e) {
					return _ = "useContext", W(), L(), K(e);
				},
				useEffect: function(e, n) {
					_ = "useEffect", W(), L(), at(2048, Dt, e, n);
				},
				useImperativeHandle: function(e, n, o) {
					return _ = "useImperativeHandle", W(), L(), hi(e, n, o);
				},
				useInsertionEffect: function(e, n) {
					return _ = "useInsertionEffect", W(), L(), at(4, Xt, e, n);
				},
				useLayoutEffect: function(e, n) {
					return _ = "useLayoutEffect", W(), L(), at(4, eo, e, n);
				},
				useMemo: function(e, n) {
					_ = "useMemo", W(), L();
					var o = N.H;
					N.H = da;
					try {
						return _l(e, n);
					} finally {
						N.H = o;
					}
				},
				useReducer: function(e, n, o) {
					_ = "useReducer", W(), L();
					var i = N.H;
					N.H = da;
					try {
						return xl(e, n, o);
					} finally {
						N.H = i;
					}
				},
				useRef: function() {
					return _ = "useRef", W(), L(), xe().memoizedState;
				},
				useState: function() {
					_ = "useState", W(), L();
					var e = N.H;
					N.H = da;
					try {
						return xl(ge);
					} finally {
						N.H = e;
					}
				},
				useDebugValue: function() {
					_ = "useDebugValue", W(), L();
				},
				useDeferredValue: function(e, n) {
					return _ = "useDeferredValue", W(), L(), xt(e, n);
				},
				useTransition: function() {
					return _ = "useTransition", W(), L(), Vn();
				},
				useSyncExternalStore: function(e, n, o) {
					return _ = "useSyncExternalStore", W(), L(), nu(e, n, o);
				},
				useId: function() {
					return _ = "useId", W(), L(), xe().memoizedState;
				},
				useFormState: function(e) {
					return _ = "useFormState", W(), L(), au(e);
				},
				useActionState: function(e) {
					return _ = "useActionState", W(), L(), au(e);
				},
				useOptimistic: function(e, n) {
					return _ = "useOptimistic", W(), L(), Vc(e, n);
				},
				useMemoCache: function(e) {
					return W(), Br(e);
				},
				useHostTransitionStatus: or,
				useCacheRefresh: function() {
					return _ = "useCacheRefresh", L(), xe().memoizedState;
				},
				useEffectEvent: function(e) {
					return _ = "useEffectEvent", W(), L(), su(e);
				}
			}, Xg = {
				readContext: function(e) {
					return Te(), K(e);
				},
				use: function(e) {
					return W(), Or(e);
				},
				useCallback: function(e, n) {
					return _ = "useCallback", W(), L(), El(e, n);
				},
				useContext: function(e) {
					return _ = "useContext", W(), L(), K(e);
				},
				useEffect: function(e, n) {
					_ = "useEffect", W(), L(), at(2048, Dt, e, n);
				},
				useImperativeHandle: function(e, n, o) {
					return _ = "useImperativeHandle", W(), L(), hi(e, n, o);
				},
				useInsertionEffect: function(e, n) {
					return _ = "useInsertionEffect", W(), L(), at(4, Xt, e, n);
				},
				useLayoutEffect: function(e, n) {
					return _ = "useLayoutEffect", W(), L(), at(4, eo, e, n);
				},
				useMemo: function(e, n) {
					_ = "useMemo", W(), L();
					var o = N.H;
					N.H = da;
					try {
						return _l(e, n);
					} finally {
						N.H = o;
					}
				},
				useReducer: function(e, n, o) {
					_ = "useReducer", W(), L();
					var i = N.H;
					N.H = da;
					try {
						return $o(e, n, o);
					} finally {
						N.H = i;
					}
				},
				useRef: function() {
					return _ = "useRef", W(), L(), xe().memoizedState;
				},
				useState: function() {
					_ = "useState", W(), L();
					var e = N.H;
					N.H = da;
					try {
						return $o(ge);
					} finally {
						N.H = e;
					}
				},
				useDebugValue: function() {
					_ = "useDebugValue", W(), L();
				},
				useDeferredValue: function(e, n) {
					return _ = "useDeferredValue", W(), L(), Yc(e, n);
				},
				useTransition: function() {
					return _ = "useTransition", W(), L(), gp();
				},
				useSyncExternalStore: function(e, n, o) {
					return _ = "useSyncExternalStore", W(), L(), nu(e, n, o);
				},
				useId: function() {
					return _ = "useId", W(), L(), xe().memoizedState;
				},
				useFormState: function(e) {
					return _ = "useFormState", W(), L(), Mt(e);
				},
				useActionState: function(e) {
					return _ = "useActionState", W(), L(), Mt(e);
				},
				useOptimistic: function(e, n) {
					return _ = "useOptimistic", W(), L(), Qc(e, n);
				},
				useMemoCache: function(e) {
					return W(), Br(e);
				},
				useHostTransitionStatus: or,
				useCacheRefresh: function() {
					return _ = "useCacheRefresh", L(), xe().memoizedState;
				},
				useEffectEvent: function(e) {
					return _ = "useEffectEvent", W(), L(), su(e);
				}
			};
			var Ty = {}, Iy = /* @__PURE__ */ new Set(), Ry = /* @__PURE__ */ new Set(), Ly = /* @__PURE__ */ new Set(), Fy = /* @__PURE__ */ new Set(), Dy = /* @__PURE__ */ new Set(), jy = /* @__PURE__ */ new Set(), Uy = /* @__PURE__ */ new Set(), Wy = /* @__PURE__ */ new Set(), Ay = /* @__PURE__ */ new Set(), Oy = /* @__PURE__ */ new Set();
			Object.freeze(Ty);
			var Sb = {
				enqueueSetState: function(e, n, o) {
					e = e._reactInternals;
					var i = _t(e), s = Vo(i);
					s.payload = n, o != null && (ko(o), s.callback = o), n = rr(e, s, i), n !== null && (tr(i, "this.setState()", e), nn(n, e, i), Sl(n, e, i));
				},
				enqueueReplaceState: function(e, n, o) {
					e = e._reactInternals;
					var i = _t(e), s = Vo(i);
					s.tag = wy, s.payload = n, o != null && (ko(o), s.callback = o), n = rr(e, s, i), n !== null && (tr(i, "this.replaceState()", e), nn(n, e, i), Sl(n, e, i));
				},
				enqueueForceUpdate: function(e, n) {
					e = e._reactInternals;
					var o = _t(e), i = Vo(o);
					i.tag = Py, n != null && (ko(n), i.callback = n), n = rr(e, i, o), n !== null && (tr(o, "this.forceUpdate()", e), nn(n, e, o), Sl(n, e, o));
				}
			}, gf = null, kb = null, wb = Error("This is not a real error. It's an implementation detail of React's selective hydration feature. If this leaks into userspace, it's a bug in React. Please file an issue."), In = !1, By = {}, Hy = {}, My = {}, Vy = {}, bf = !1, $y = {}, Pb = {}, Qy = {}, xb = {
				dehydrated: null,
				treeContext: null,
				retryLane: 0,
				hydrationErrors: null
			}, qy = !1, Gy = null;
			Gy = /* @__PURE__ */ new Set();
			var jt = !1, Yg = !1, no = null, Xa = null, yr = 0, Kg = /* @__PURE__ */ new Map(), Jy = {}, ac = 0, Cb = 1, e0 = 2, ct = !1, We = !1, Ya = !1, zb = !1, Zy = typeof WeakSet == "function" ? WeakSet : Set, dt = null, yf = null, vf = null, Ka = !1, qh = !1, n0 = !1, Eb = !1, Bn = null, vr = !1, fa = null, Kn = !1, ic = 8192, A1 = {
				getCacheForType: function(e) {
					var n = K(vn), o = n.data.get(e);
					return o === void 0 && (o = e(), n.data.set(e, o)), o;
				},
				cacheSignal: function() {
					return K(vn).controller.signal;
				},
				getOwner: function() {
					return Bi;
				}
			}, t0 = 0, r0 = 1, o0 = 2, a0 = 3, i0 = 4;
			if (typeof Symbol == "function" && Symbol.for) {
				var Gh = Symbol.for;
				t0 = Gh("selector.component"), r0 = Gh("selector.has_pseudo_class"), o0 = Gh("selector.role"), a0 = Gh("selector.test_id"), i0 = Gh("selector.text");
			}
			var l0 = [], O1 = typeof WeakMap == "function" ? WeakMap : Map, ft = 0, pt = 2, Fo = 4, Gi = 0, Jh = 1, lc = 2, s0 = 3, gs = 4, Zh = 6, Xy = 5, ve = ft, Ge = null, se = null, te = 0, Sr = 0, u0 = 1, sc = 2, Xh = 3, Yy = 4, _b = 5, Yh = 6, c0 = 7, Nb = 8, uc = 9, Ae = Sr, to = null, Ji = !1, Sf = !1, Tb = !1, ei = 0, fn = Gi, bs = 0, ys = 0, Ib = 0, kr = 0, cc = 0, Kh = null, Yt = null, d0 = !1, f0 = 0, Ky = 0, e1 = 300, em = 1 / 0, Rb = 500, nm = null, kn = null, vs = null, p0 = 0, tm = 1, Lb = 2, n1 = 3, ni = 0, t1 = 1, r1 = 2, Fb = 3, Db = 4, h0 = 5, pn = 0, pa = null, dc = null, wr = 0, jb = 0, m0 = -0, Ub = null, o1 = null, kf = null, wf = null, Pf = null, g0 = null, ro = p0, Wb = null, B1 = 50, rm = 0, b0 = null, Ab = !1, y0 = !1, H1 = 50, fc = 0, om = null, xf = !1, a1 = !1, v0 = null, i1 = !1, l1 = /* @__PURE__ */ new Set(), M1 = {}, Zi = null, Cf = null, s1 = !1;
			try {
				Object.preventExtensions({});
			} catch {
				s1 = !0;
			}
			var u1 = !1, c1 = {}, d1 = null, f1 = null, p1 = null, h1 = null, m1 = null, g1 = null, b1 = null, y1 = null, v1 = null, S1 = null;
			return d1 = function(e, n, o, i) {
				n = et(e, n), n !== null && (o = zf(n.memoizedState, o, 0, i), n.memoizedState = o, n.baseState = o, e.memoizedProps = Un({}, e.memoizedProps), o = tt(e, 2), o !== null && nn(o, e, 2));
			}, f1 = function(e, n, o) {
				n = et(e, n), n !== null && (o = pc(n.memoizedState, o, 0), n.memoizedState = o, n.baseState = o, e.memoizedProps = Un({}, e.memoizedProps), o = tt(e, 2), o !== null && nn(o, e, 2));
			}, p1 = function(e, n, o, i) {
				n = et(e, n), n !== null && (o = F(n.memoizedState, o, i), n.memoizedState = o, n.baseState = o, e.memoizedProps = Un({}, e.memoizedProps), o = tt(e, 2), o !== null && nn(o, e, 2));
			}, h1 = function(e, n, o) {
				e.pendingProps = zf(e.memoizedProps, n, 0, o), e.alternate && (e.alternate.pendingProps = e.pendingProps), n = tt(e, 2), n !== null && nn(n, e, 2);
			}, m1 = function(e, n) {
				e.pendingProps = pc(e.memoizedProps, n, 0), e.alternate && (e.alternate.pendingProps = e.pendingProps), n = tt(e, 2), n !== null && nn(n, e, 2);
			}, g1 = function(e, n, o) {
				e.pendingProps = F(e.memoizedProps, n, o), e.alternate && (e.alternate.pendingProps = e.pendingProps), n = tt(e, 2), n !== null && nn(n, e, 2);
			}, b1 = function(e) {
				var n = tt(e, 2);
				n !== null && nn(n, e, 2);
			}, y1 = function(e) {
				var n = ws(), o = tt(e, n);
				o !== null && nn(o, e, n);
			}, v1 = function(e) {
				mc = e;
			}, S1 = function(e) {
				hc = e;
			}, ce.attemptContinuousHydration = function(e) {
				if (e.tag === 13 || e.tag === 31) {
					var n = tt(e, 67108864);
					n !== null && nn(n, e, 67108864), ih(e, 67108864);
				}
			}, ce.attemptHydrationAtCurrentPriority = function(e) {
				if (e.tag === 13 || e.tag === 31) {
					var n = _t(e);
					n = xs(n);
					var o = tt(e, n);
					o !== null && nn(o, e, n), ih(e, n);
				}
			}, ce.attemptSynchronousHydration = function(e) {
				switch (e.tag) {
					case 3:
						if (e = e.stateNode, e.current.memoizedState.isDehydrated) {
							var n = mt(e.pendingLanes);
							if (n !== 0) {
								for (e.pendingLanes |= 2, e.entangledLanes |= 2; n;) {
									var o = 1 << 31 - d(n);
									e.entanglements[1] |= o, n &= ~o;
								}
								jr(e), (ve & (pt | Fo)) === ft && (em = Re() + Rb, Ur(0, !1));
							}
						}
						break;
					case 31:
					case 13: n = tt(e, 2), n !== null && nn(n, e, 2), Cd(), ih(e, 2);
				}
			}, ce.batchedUpdates = function(e, n) {
				return e(n);
			}, ce.createComponentSelector = function(e) {
				return {
					$$typeof: t0,
					value: e
				};
			}, ce.createContainer = function(e, n, o, i, s, u, f, p, g, b) {
				return rh(e, n, !1, null, o, i, u, null, f, p, g, b);
			}, ce.createHasPseudoClassSelector = function(e) {
				return {
					$$typeof: r0,
					value: e
				};
			}, ce.createHydrationContainer = function(e, n, o, i, s, u, f, p, g, b, k, z, T, H) {
				var _n3;
				return e = rh(o, i, !0, e, s, u, p, H, g, b, k, z), e.context = vg(null), o = e.current, i = _t(o), i = xs(i), s = Vo(i), s.callback = (_n3 = n) != null ? _n3 : null, rr(o, s, i), tr(i, "hydrateRoot()", null), n = i, e.current.lanes = n, el(e, n), jr(e), e;
			}, ce.createPortal = function(e, n, o) {
				var i = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
				if (i == null) i = null;
				else if (i === Sg) i = Sg;
				else {
					try {
						oh(i);
						var s = !1;
					} catch {
						s = !0;
					}
					s && (console.error("The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", typeof Symbol == "function" && Symbol.toStringTag && i[Symbol.toStringTag] || i.constructor.name || "Object"), oh(i)), i = "" + i;
				}
				return {
					$$typeof: Ua,
					key: i,
					children: e,
					containerInfo: n,
					implementation: o
				};
			}, ce.createRoleSelector = function(e) {
				return {
					$$typeof: o0,
					value: e
				};
			}, ce.createTestNameSelector = function(e) {
				return {
					$$typeof: a0,
					value: e
				};
			}, ce.createTextSelector = function(e) {
				return {
					$$typeof: i0,
					value: e
				};
			}, ce.defaultOnCaughtError = function(e) {
				var n = gf ? "The above error occurred in the <" + gf + "> component." : "The above error occurred in one of your React components.", o = "React will try to recreate this component tree from scratch using the error boundary you provided, " + ((kb || "Anonymous") + ".");
				typeof e == "object" && e !== null && typeof e.environmentName == "string" ? mh("error", [
					`%o

%s

%s
`,
					e,
					n,
					o
				], e.environmentName)() : console.error(`%o

%s

%s
`, e, n, o);
			}, ce.defaultOnRecoverableError = function(e) {
				Mb(e);
			}, ce.defaultOnUncaughtError = function(e) {
				Mb(e), console.warn(`%s

%s
`, gf ? "An error occurred in the <" + gf + "> component." : "An error occurred in one of your React components.", `Consider adding an error boundary to your tree to customize error handling behavior.
Visit https://react.dev/link/error-boundaries to learn more about error boundaries.`);
			}, ce.deferredUpdates = function(e) {
				var n = N.T, o = fr();
				try {
					return Je(32), N.T = null, e();
				} finally {
					Je(o), N.T = n;
				}
			}, ce.discreteUpdates = function(e, n, o, i, s) {
				var u = N.T, f = fr();
				try {
					return Je(2), N.T = null, e(n, o, i, s);
				} finally {
					Je(f), N.T = u, ve === ft && (em = Re() + Rb);
				}
			}, ce.findAllNodes = xd, ce.findBoundingRects = function(e, n) {
				if (!Oa) throw Error("Test selector API is not supported by this renderer.");
				n = xd(e, n), e = [];
				for (var o = 0; o < n.length; o++) e.push(Gl(n[o]));
				for (n = e.length - 1; 0 < n; n--) {
					o = e[n];
					for (var i = o.x, s = i + o.width, u = o.y, f = u + o.height, p = n - 1; 0 <= p; p--) if (n !== p) {
						var g = e[p], b = g.x, k = b + g.width, z = g.y, T = z + g.height;
						if (i >= b && u >= z && s <= k && f <= T) {
							e.splice(n, 1);
							break;
						} else if (i !== b || o.width !== g.width || T < u || z > f) {
							if (!(u !== z || o.height !== g.height || k < i || b > s)) {
								b > i && (g.width += b - i, g.x = i), k < s && (g.width = s - b), e.splice(n, 1);
								break;
							}
						} else {
							z > u && (g.height += z - u, g.y = u), T < f && (g.height = f - z), e.splice(n, 1);
							break;
						}
					}
				}
				return e;
			}, ce.findHostInstance = function(e) {
				var n = e._reactInternals;
				if (n === void 0) throw typeof e.render == "function" ? Error("Unable to find node on an unmounted component.") : (e = Object.keys(e).join(","), Error("Argument appears to not be a ReactComponent. Keys: " + e));
				return e = Nf(n), e === null ? null : Ql(e.stateNode);
			}, ce.findHostInstanceWithNoPortals = function(e) {
				return e = am(e), e = e !== null ? Ki(e) : null, e === null ? null : Ql(e.stateNode);
			}, ce.findHostInstanceWithWarning = function(e, n) {
				var o = e._reactInternals;
				if (o === void 0) throw typeof e.render == "function" ? Error("Unable to find node on an unmounted component.") : (e = Object.keys(e).join(","), Error("Argument appears to not be a ReactComponent. Keys: " + e));
				if (e = Nf(o), e === null) return null;
				if (e.mode & 8) {
					var i = G(o) || "Component";
					c1[i] || (c1[i] = !0, B(e, function() {
						o.mode & 8 ? console.error("%s is deprecated in StrictMode. %s was passed an instance of %s which is inside StrictMode. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://react.dev/link/strict-mode-find-node", n, n, i) : console.error("%s is deprecated in StrictMode. %s was passed an instance of %s which renders StrictMode children. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://react.dev/link/strict-mode-find-node", n, n, i);
					}));
				}
				return Ql(e.stateNode);
			}, ce.flushPassiveEffects = Ol, ce.flushSyncFromReconciler = function(e) {
				var n = ve;
				ve |= 1;
				var o = N.T, i = fr();
				try {
					if (Je(2), N.T = null, e) return e();
				} finally {
					Je(i), N.T = o, ve = n, (ve & (pt | Fo)) === ft && Ur(0, !1);
				}
			}, ce.flushSyncWork = Cd, ce.focusWithin = function(e, n) {
				if (!Oa) throw Error("Test selector API is not supported by this renderer.");
				for (e = Bp(e), n = qm(e, n), n = Array.from(n), e = 0; e < n.length;) {
					var o = n[e++], i = o.tag;
					if (!Zr(o)) {
						if ((i === 5 || i === 26 || i === 27) && gh(o.stateNode)) return !0;
						for (o = o.child; o !== null;) n.push(o), o = o.sibling;
					}
				}
				return !1;
			}, ce.getFindAllNodesFailureDescription = function(e, n) {
				if (!Oa) throw Error("Test selector API is not supported by this renderer.");
				var o = 0, i = [];
				e = [Bp(e), 0];
				for (var s = 0; s < e.length;) {
					var u = e[s++], f = u.tag, p = e[s++], g = n[p];
					if ((f !== 5 && f !== 26 && f !== 27 || !Zr(u)) && (Hp(u, g) && (i.push(Mp(g)), p++, p > o && (o = p)), p < n.length)) for (u = u.child; u !== null;) e.push(u, p), u = u.sibling;
				}
				if (o < n.length) {
					for (e = []; o < n.length; o++) e.push(Mp(n[o]));
					return `findAllNodes was able to match part of the selector:
  ` + (i.join(" > ") + `

No matching component was found for:
  `) + e.join(" > ");
				}
				return null;
			}, ce.getPublicRootInstance = function(e) {
				if (e = e.current, !e.child) return null;
				switch (e.child.tag) {
					case 27:
					case 5: return Ql(e.child.stateNode);
					default: return e.child.stateNode;
				}
			}, ce.injectIntoDevTools = function() {
				var e = {
					bundleType: 1,
					version: U0,
					rendererPackageName: Lu,
					currentDispatcherRef: N,
					reconcilerVersion: "19.3.0"
				};
				return It !== null && (e.rendererConfig = It), e.overrideHookState = d1, e.overrideHookStateDeletePath = f1, e.overrideHookStateRenamePath = p1, e.overrideProps = h1, e.overridePropsDeletePath = m1, e.overridePropsRenamePath = g1, e.scheduleUpdate = b1, e.scheduleRetry = y1, e.setErrorHandler = v1, e.setSuspenseHandler = S1, e.scheduleRefresh = gc, e.scheduleRoot = Ss, e.setRefreshHandler = oo, e.getCurrentFiber = L0, Lf(e);
			}, ce.isAlreadyRendering = $p, ce.observeVisibleRects = function(e, n, o, i) {
				function s() {
					var b = xd(e, n);
					u.forEach(function(k) {
						0 > b.indexOf(k) && g(k);
					}), b.forEach(function(k) {
						0 > u.indexOf(k) && p(k);
					});
				}
				if (!Oa) throw Error("Test selector API is not supported by this renderer.");
				var u = xd(e, n);
				o = Wd(u, o, i);
				var f = o.disconnect, p = o.observe, g = o.unobserve;
				return l0.push(s), { disconnect: function() {
					var b = l0.indexOf(s);
					0 <= b && l0.splice(b, 1), f();
				} };
			}, ce.shouldError = function(e) {
				return mc(e);
			}, ce.shouldSuspend = function(e) {
				return hc(e);
			}, ce.startHostTransition = function(e, n, o, i) {
				if (e.tag !== 5) throw Error("Expected the form instance to be a HostComponent. This is a bug in React.");
				var s = Dn(e).queue;
				pm(e), cu(e, s, n, Gr, o === null ? k0 : function() {
					N.T === null && console.error("requestFormReset was called outside a transition or action. To fix, move to an action, or wrap with startTransition.");
					var u = Dn(e);
					return u.next === null && (u = e.alternate.memoizedState), mi(e, u.next.queue, {}, _t(e)), o(i);
				});
			}, ce.updateContainer = function(e, n, o, i) {
				var s = n.current, u = _t(s);
				return Ld(s, u, e, n, o, i), u;
			}, ce.updateContainerSync = Rd, ce;
		}, Ut.exports.default = Ut.exports, Object.defineProperty(Ut.exports, "__esModule", { value: !0 });
	}(Bb)), Bb.exports;
}
var C1;
function G1() {
	return C1 || (C1 = 1, S0.exports = q1()), S0.exports;
}
var Z1 = $1(G1());
/** Constructor registration and lookup for JSX elements. */
var catalogue = {};
var i = 0;
var toPascalCase = (type) => `${type[0].toUpperCase()}${type.slice(1)}`;
function hasConstructor(name) {
	return name in catalogue;
}
function resolveConstructor(name) {
	return catalogue[name];
}
function extend(objects) {
	if (typeof objects === "function") {
		const Component = `${i++}`;
		catalogue[Component] = objects;
		return Component;
	} else Object.assign(catalogue, objects);
}
function createReconciler(config) {
	const reconciler = Z1(config);
	reconciler.injectIntoDevTools();
	return reconciler;
}
var NoEventPriority = 0;
var PREFIX_REGEX = /^three(?=[A-Z])/;
function validateInstance(type, props) {
	const name = toPascalCase(type);
	const target = resolveConstructor(name);
	if (type !== "primitive" && !target) throw new Error(`R3F: ${name} is not part of the THREE namespace! Did you forget to extend? See: https://docs.pmnd.rs/react-three-fiber/api/objects#using-3rd-party-objects-declaratively`);
	if (type === "primitive" && !props.object) throw new Error(`R3F: Primitives without 'object' are invalid!`);
	if (props.args !== void 0 && !Array.isArray(props.args)) throw new Error("R3F: The args prop must be an array!");
}
function createInstance(type, props, root) {
	var _props$object;
	type = hasConstructor(toPascalCase(type)) ? type : type.replace(PREFIX_REGEX, "");
	validateInstance(type, props);
	if (type === "primitive" && (_props$object = props.object) != null && _props$object.__r3f) delete props.object.__r3f;
	return prepare(props.object, root, type, props);
}
function hideInstance(instance) {
	if (!instance.isHidden) {
		var _instance$parent;
		if (instance.props.attach && (_instance$parent = instance.parent) != null && _instance$parent.object) detach(instance.parent, instance);
		else if (isObject3D(instance.object)) {
			instance.previousVisible = instance.object.visible;
			instance.object.visible = false;
		}
		instance.isHidden = true;
		invalidateInstance(instance);
	}
}
function unhideInstance(instance) {
	if (instance.isHidden) {
		var _instance$parent2;
		if (instance.props.attach && (_instance$parent2 = instance.parent) != null && _instance$parent2.object) attach(instance.parent, instance);
		else if (isObject3D(instance.object)) {
			var _instance$previousVis;
			instance.object.visible = (_instance$previousVis = instance.previousVisible) != null ? _instance$previousVis : true;
		}
		instance.previousVisible = void 0;
		instance.isHidden = false;
		invalidateInstance(instance);
	}
}
function handleContainerEffects(parent, child, beforeChild) {
	const state = child.root.getState();
	if (!parent.parent && parent.object !== state.scene) return;
	if (!child.object) {
		var _child$props$object, _child$props$args;
		const target = resolveConstructor(toPascalCase(child.type));
		child.object = (_child$props$object = child.props.object) != null ? _child$props$object : new target(...(_child$props$args = child.props.args) != null ? _child$props$args : []);
		child.object.__r3f = child;
	}
	applyProps(child.object, child.props);
	if (child.props.attach) attach(parent, child);
	else if (isObject3D(child.object) && isObject3D(parent.object)) {
		const childIndex = parent.object.children.indexOf(beforeChild == null ? void 0 : beforeChild.object);
		if (beforeChild && childIndex !== -1) {
			const existingIndex = parent.object.children.indexOf(child.object);
			if (existingIndex !== -1) {
				parent.object.children.splice(existingIndex, 1);
				const adjustedIndex = existingIndex < childIndex ? childIndex - 1 : childIndex;
				parent.object.children.splice(adjustedIndex, 0, child.object);
			} else {
				child.object.parent = parent.object;
				parent.object.children.splice(childIndex, 0, child.object);
				child.object.dispatchEvent({ type: "added" });
				parent.object.dispatchEvent({
					type: "childadded",
					child: child.object
				});
			}
		} else parent.object.add(child.object);
	}
	for (const childInstance of child.children) handleContainerEffects(child, childInstance);
	invalidateInstance(child);
}
function appendChild(parent, child) {
	if (!child) return;
	if (child.parent === parent) {
		const childIndex = parent.children.indexOf(child);
		if (childIndex !== -1) parent.children.splice(childIndex, 1);
	}
	child.parent = parent;
	parent.children.push(child);
	handleContainerEffects(parent, child);
}
function insertBefore(parent, child, beforeChild) {
	if (!child || !beforeChild) return;
	if (child.parent === parent) {
		const childIndex = parent.children.indexOf(child);
		if (childIndex !== -1) parent.children.splice(childIndex, 1);
	}
	child.parent = parent;
	const childIndex = parent.children.indexOf(beforeChild);
	if (childIndex !== -1) parent.children.splice(childIndex, 0, child);
	else parent.children.push(child);
	handleContainerEffects(parent, child, beforeChild);
}
function disposeOnIdle(object) {
	if (typeof object.dispose === "function") {
		const handleDispose = () => {
			try {
				object.dispose();
			} catch {}
		};
		if (typeof IS_REACT_ACT_ENVIRONMENT !== "undefined") handleDispose();
		else (0, import_scheduler.unstable_scheduleCallback)(import_scheduler.unstable_IdlePriority, handleDispose);
	}
}
function removeChild(parent, child, dispose) {
	if (!child) return;
	const wasLinked = !!child.parent;
	child.parent = null;
	const childIndex = parent.children.indexOf(child);
	if (childIndex !== -1) parent.children.splice(childIndex, 1);
	if (child.props.attach) detach(parent, child);
	else if (isObject3D(child.object) && isObject3D(parent.object)) {
		parent.object.remove(child.object);
		removeInteractivity(findInitialRoot(child), child.object);
	}
	const shouldDispose = child.props.dispose !== null && dispose !== false;
	for (let i = child.children.length - 1; i >= 0; i--) {
		const node = child.children[i];
		removeChild(child, node, shouldDispose);
	}
	child.children.length = 0;
	delete child.object.__r3f;
	if (shouldDispose && child.type !== "primitive" && child.object.type !== "Scene") disposeOnIdle(child.object);
	if (dispose === void 0 && wasLinked) {
		var _child$root;
		const state = (_child$root = child.root) == null ? void 0 : _child$root.getState == null ? void 0 : _child$root.getState();
		if (state && state.internal.frames === 0) state.invalidate();
	}
}
function setFiberRef(fiber, publicInstance) {
	for (const _fiber of [fiber, fiber.alternate]) if (_fiber !== null) {
		if (typeof _fiber.ref === "function") {
			_fiber.refCleanup == null || _fiber.refCleanup();
			const cleanup = _fiber.ref(publicInstance);
			if (typeof cleanup === "function") _fiber.refCleanup = cleanup;
		} else if (_fiber.ref) _fiber.ref.current = publicInstance;
	}
}
var reconstructed = [];
function flushReconstructedInstances() {
	if (reconstructed.length === 0) return;
	try {
		swapReconstructedInstances();
	} finally {
		reconstructed.length = 0;
	}
}
function swapReconstructedInstances() {
	for (const [instance] of reconstructed) {
		const parent = instance.parent;
		if (parent) {
			if (instance.props.attach) detach(parent, instance);
			else if (isObject3D(instance.object) && isObject3D(parent.object)) parent.object.remove(instance.object);
			for (const child of instance.children) if (child.props.attach) detach(instance, child);
			else if (isObject3D(child.object) && isObject3D(instance.object)) instance.object.remove(child.object);
		}
		if (instance.isHidden) unhideInstance(instance);
		if (instance.object.__r3f) delete instance.object.__r3f;
		if (instance.type !== "primitive") disposeOnIdle(instance.object);
	}
	for (const [instance, props, fiber] of reconstructed) {
		instance.props = props;
		const parent = instance.parent;
		if (parent) {
			var _instance$props$objec, _instance$props$args;
			const target = resolveConstructor(toPascalCase(instance.type));
			const prevObject = instance.object;
			instance.object = (_instance$props$objec = instance.props.object) != null ? _instance$props$objec : new target(...(_instance$props$args = instance.props.args) != null ? _instance$props$args : []);
			instance.object.__r3f = instance;
			setFiberRef(fiber, instance.object);
			swapInteractivity(findInitialRoot(instance), prevObject, instance.object);
			applyProps(instance.object, instance.props);
			if (instance.props.attach) attach(parent, instance);
			else if (isObject3D(instance.object) && isObject3D(parent.object)) parent.object.add(instance.object);
			for (const child of instance.children) if (child.props.attach) attach(instance, child);
			else if (isObject3D(child.object) && isObject3D(instance.object)) instance.object.add(child.object);
			invalidateInstance(instance);
		}
	}
}
var handleTextInstance = () => {};
var NO_CONTEXT = {};
var currentUpdatePriority = NoEventPriority;
function getEventPriority(type) {
	switch (type) {
		case "beforetoggle":
		case "cancel":
		case "click":
		case "close":
		case "contextmenu":
		case "copy":
		case "cut":
		case "auxclick":
		case "dblclick":
		case "dragend":
		case "dragstart":
		case "drop":
		case "focusin":
		case "focusout":
		case "input":
		case "invalid":
		case "keydown":
		case "keypress":
		case "keyup":
		case "mousedown":
		case "mouseup":
		case "paste":
		case "pause":
		case "play":
		case "pointercancel":
		case "pointerdown":
		case "pointerup":
		case "ratechange":
		case "reset":
		case "resize":
		case "seeked":
		case "submit":
		case "touchcancel":
		case "touchend":
		case "touchstart":
		case "volumechange":
		case "change":
		case "selectionchange":
		case "compositionstart":
		case "compositionend":
		case "compositionupdate":
		case "beforeinput":
		case "blur":
		case "fullscreenchange":
		case "focus":
		case "hashchange":
		case "popstate":
		case "select":
		case "selectstart": return e;
		case "drag":
		case "dragenter":
		case "dragexit":
		case "dragleave":
		case "dragover":
		case "mousemove":
		case "mouseout":
		case "mouseover":
		case "pointermove":
		case "pointerout":
		case "pointerover":
		case "scroll":
		case "touchmove":
		case "wheel":
		case "mouseenter":
		case "mouseleave":
		case "pointerenter":
		case "pointerleave": return o;
		case "message": switch ((0, import_scheduler.unstable_getCurrentPriorityLevel)()) {
			case import_scheduler.unstable_ImmediatePriority: return e;
			case import_scheduler.unstable_UserBlockingPriority: return o;
			case import_scheduler.unstable_NormalPriority:
			case import_scheduler.unstable_LowPriority: return r;
			case import_scheduler.unstable_IdlePriority: return i$1;
			default: return r;
		}
		default: return r;
	}
}
function scheduleMicrotask(callback) {
	if (typeof queueMicrotask === "function") queueMicrotask(callback);
	else if (typeof Promise !== "undefined") Promise.resolve().then(callback).catch((error) => {
		setTimeout(() => {
			throw error;
		});
	});
	else setTimeout(callback);
}
var reconciler = /* @__PURE__ */ createReconciler({
	isPrimaryRenderer: false,
	warnsIfNotActing: false,
	supportsMutation: true,
	supportsPersistence: false,
	supportsHydration: false,
	createInstance,
	removeChild,
	appendChild,
	appendInitialChild: appendChild,
	insertBefore,
	appendChildToContainer(container, child) {
		const scene = container.getState().scene.__r3f;
		if (!child || !scene) return;
		appendChild(scene, child);
	},
	removeChildFromContainer(container, child) {
		const scene = container.getState().scene.__r3f;
		if (!child || !scene) return;
		removeChild(scene, child);
	},
	insertInContainerBefore(container, child, beforeChild) {
		const scene = container.getState().scene.__r3f;
		if (!child || !beforeChild || !scene) return;
		insertBefore(scene, child, beforeChild);
	},
	getRootHostContext: () => NO_CONTEXT,
	getChildHostContext: () => NO_CONTEXT,
	commitUpdate(instance, type, oldProps, newProps, fiber) {
		var _newProps$args, _oldProps$args, _newProps$args2;
		validateInstance(type, newProps);
		let reconstruct = false;
		if (instance.type === "primitive" && oldProps.object !== newProps.object) reconstruct = true;
		else if (((_newProps$args = newProps.args) == null ? void 0 : _newProps$args.length) !== ((_oldProps$args = oldProps.args) == null ? void 0 : _oldProps$args.length)) reconstruct = true;
		else if ((_newProps$args2 = newProps.args) != null && _newProps$args2.some((value, index) => {
			var _oldProps$args2;
			return value !== ((_oldProps$args2 = oldProps.args) == null ? void 0 : _oldProps$args2[index]);
		})) reconstruct = true;
		if (reconstruct) reconstructed.push([
			instance,
			getInstanceProps(newProps),
			fiber
		]);
		else {
			const changedProps = diffProps(instance, newProps);
			const attach = instance.props.attach;
			instance.props = getInstanceProps(newProps);
			if (attach !== void 0) instance.props.attach = attach;
			else delete instance.props.attach;
			if (Object.keys(changedProps).length) applyProps(instance.object, changedProps);
		}
	},
	finalizeInitialChildren: () => false,
	commitMount() {},
	getPublicInstance: (instance) => instance == null ? void 0 : instance.object,
	prepareForCommit: () => null,
	preparePortalMount: (container) => prepare(container.getState().scene, container, "", {}),
	resetAfterCommit: flushReconstructedInstances,
	shouldSetTextContent: () => false,
	clearContainer: () => false,
	hideInstance,
	unhideInstance,
	createTextInstance: handleTextInstance,
	hideTextInstance: handleTextInstance,
	unhideTextInstance: handleTextInstance,
	supportsMicrotasks: true,
	scheduleMicrotask,
	scheduleTimeout: typeof setTimeout === "function" ? setTimeout : void 0,
	cancelTimeout: typeof clearTimeout === "function" ? clearTimeout : void 0,
	noTimeout: -1,
	getInstanceFromNode: () => null,
	beforeActiveInstanceBlur() {},
	afterActiveInstanceBlur() {},
	detachDeletedInstance() {},
	prepareScopeUpdate() {},
	getInstanceFromScope: () => null,
	shouldAttemptEagerTransition: () => false,
	trackSchedulerEvent: () => {},
	resolveEventType: () => null,
	resolveEventTimeStamp: () => -1.1,
	requestPostPaintCallback() {},
	maySuspendCommit: () => false,
	preloadInstance: () => true,
	suspendInstance() {},
	waitForCommitToBeReady: () => null,
	NotPendingTransition: null,
	HostTransitionContext: /* @__PURE__ */ import_react.createContext(null),
	setCurrentUpdatePriority(newPriority) {
		currentUpdatePriority = newPriority;
	},
	getCurrentUpdatePriority() {
		return currentUpdatePriority;
	},
	resolveUpdatePriority() {
		var _window$event;
		if (currentUpdatePriority !== NoEventPriority) return currentUpdatePriority;
		const eventType = typeof window !== "undefined" ? (_window$event = window.event) == null ? void 0 : _window$event.type : void 0;
		if (eventType === void 0) return r;
		return getEventPriority(eventType);
	},
	resetFormInstance() {},
	rendererPackageName: "@react-three/fiber",
	rendererVersion: packageData.version,
	applyViewTransitionName(_instance, _name, _className) {},
	restoreViewTransitionName(_instance, _props) {},
	cancelViewTransitionName(_instance, _name, _props) {},
	cancelRootViewTransitionName(_rootContainer) {},
	restoreRootViewTransitionName(_rootContainer) {},
	InstanceMeasurement: null,
	measureInstance: (_instance) => null,
	wasInstanceInViewport: (_measurement) => true,
	hasInstanceChanged: (_oldMeasurement, _newMeasurement) => false,
	hasInstanceAffectedParent: (_oldMeasurement, _newMeasurement) => false,
	suspendOnActiveViewTransition(_state, _container) {},
	startViewTransition(_suspendedState, _rootContainer, _transitionTypes, mutationCallback, layoutCallback, _afterMutationCallback, spawnedWorkCallback, _passiveCallback, _errorCallback, _blockedCallback, finishedAnimation) {
		mutationCallback();
		layoutCallback();
		finishedAnimation?.();
		spawnedWorkCallback();
		return null;
	},
	startGestureTransition(_suspendedState, _rootContainer, _timeline, _rangeStart, _rangeEnd, _transitionTypes, mutationCallback, animateCallback, _errorCallback, finishedAnimation) {
		mutationCallback();
		animateCallback();
		finishedAnimation?.();
		return null;
	},
	stopViewTransition(_transition) {},
	addViewTransitionFinishedListener(_transition, callback) {
		callback();
	},
	createViewTransitionInstance: (_name) => null,
	getCurrentGestureOffset(_provider) {
		throw new Error("startGestureTransition is not yet supported in react-three-fiber.");
	},
	cloneMutableInstance(instance, _keepChildren) {
		return instance;
	},
	cloneMutableTextInstance(textInstance) {
		return textInstance;
	},
	cloneRootViewTransitionContainer(_rootContainer) {
		throw new Error("Not implemented.");
	},
	removeRootViewTransitionClone(_rootContainer, _clone) {
		throw new Error("Not implemented.");
	},
	createFragmentInstance: (_fiber) => null,
	updateFragmentInstanceFiber(_fiber, _instance) {},
	commitNewChildToFragmentInstance(_child, _fragmentInstance) {},
	deleteChildFromFragmentInstance(_child, _fragmentInstance) {},
	measureClonedInstance: (_instance) => null,
	maySuspendCommitOnUpdate: (_type, _oldProps, _newProps) => false,
	maySuspendCommitInSyncRender: (_type, _props) => false,
	startSuspendingCommit: () => null,
	getSuspendedCommitReason: (_state, _rootContainer) => null
});
/**
* Force React to flush any updates inside the provided callback synchronously and immediately.
* All the same caveats documented for react-dom's `flushSync` apply here (see https://react.dev/reference/react-dom/flushSync).
* Nevertheless, sometimes one needs to render synchronously, for example to keep DOM and 3D changes in lock-step without
* having to revert to a non-React solution. Note: this will only flush updates within the `Canvas` root.
*/
function flushSync(fn) {
	return reconciler.flushSyncFromReconciler(fn);
}
var _roots = /* @__PURE__ */ new Map();
/**
* open -> closing -> disposed
*          | use
*          v
*         open
*
* Only closing can be cancelled. Each unmount carries a token, so only the latest one can dispose.
*/
function transitionRoot(root, event) {
	const state = root.state;
	switch (event.type) {
		case "use":
			if (state.status === "disposed") return false;
			root.state = { status: "open" };
			return true;
		case "unmount":
			if (state.status === "disposed") return false;
			root.state = {
				status: "closing",
				token: event.token
			};
			return true;
		case "dispose":
			if (state.status !== "closing" || state.token !== event.token) return false;
			root.state = { status: "disposed" };
			return true;
	}
}
function createRoot(canvas) {
	const prevRoot = _roots.get(canvas);
	const prevFiber = prevRoot == null ? void 0 : prevRoot.fiber;
	const prevStore = prevRoot == null ? void 0 : prevRoot.store;
	if (prevRoot) console.warn("R3F.createRoot should only be called once!");
	const logRecoverableError = typeof reportError === "function" ? reportError : console.error;
	const store = prevStore || createStore(invalidate, advance);
	const fiber = prevFiber || reconciler.createContainer(store, t, null, false, null, "", logRecoverableError, logRecoverableError, logRecoverableError, null);
	const root = prevRoot || {
		fiber,
		store,
		state: { status: "open" },
		ready: fulfilled(void 0),
		configuration: {},
		ownsRenderer: false
	};
	if (!prevRoot) _roots.set(canvas, root);
	let mounted = false;
	return {
		get ready() {
			return root.ready;
		},
		configure(props = {}) {
			if (!transitionRoot(root, { type: "use" })) return rejected(/* @__PURE__ */ new Error("R3F: Cannot configure a root after disposal has started."));
			const previous = root.ready;
			const { promise, resolve, reject } = deferred();
			root.ready = promise;
			const apply = (gl) => {
				const state = store.getState();
				if (!state.gl) {
					root.ownsRenderer = !isRenderer(props.gl);
					state.set({ gl });
				}
				applyRootConfiguration(root, canvas, props);
				if (!root.unwatchDpr && (props.dpr === void 0 || Array.isArray(props.dpr))) root.unwatchDpr = followDpr(root);
				resolve(this);
			};
			const run = () => {
				try {
					var _store$getState$gl;
					const gl = (_store$getState$gl = store.getState().gl) != null ? _store$getState$gl : createRenderer(canvas, props.gl);
					if (isPromiseLike(gl)) Promise.resolve(gl).then(apply).catch(reject);
					else apply(gl);
				} catch (error) {
					reject(error);
				}
			};
			if (previous.status === "pending") previous.then(run, reject);
			else run();
			return promise;
		},
		render(children) {
			if (!transitionRoot(root, { type: "use" })) return store;
			if (!store.getState().gl && root.ready.status === "fulfilled") this.configure();
			if (root.ready.status === "rejected") throw root.ready.reason;
			const commit = () => {
				var _root$configuration$p;
				if (root.state.status !== "open" || root.ready.status === "rejected") return;
				if (root.ready.status === "pending") {
					root.ready.then(commit, logRecoverableError);
					return;
				}
				const onCreated = (_root$configuration$p = root.configuration.previous) == null ? void 0 : _root$configuration$p.onCreated;
				const element = /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Provider, {
					store,
					children,
					onCreated,
					rootElement: canvas
				});
				if (mounted) {
					reconciler.updateContainer(element, fiber, null, noop);
					return;
				}
				mounted = true;
				reconciler.updateContainerSync(element, fiber, null, noop);
				reconciler.flushSyncWork();
			};
			commit();
			return store;
		},
		unmount() {
			if (_roots.get(canvas) === root) unmountComponentAtNode(canvas);
		}
	};
}
function Provider({ store, children, onCreated, rootElement }) {
	useIsomorphicLayoutEffect(() => {
		const state = store.getState();
		state.set((state) => ({ internal: {
			...state.internal,
			active: true
		} }));
		if (onCreated) onCreated(state);
		if (!store.getState().events.connected) state.events.connect == null || state.events.connect(rootElement);
	}, []);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(context.Provider, {
		value: store,
		children
	});
}
function attempt(step) {
	try {
		return step();
	} catch (error) {
		console.warn("[R3F] Error while unmounting root; teardown may be incomplete:", error);
	}
}
function unmountComponentAtNode(canvas, callback) {
	const root = _roots.get(canvas);
	const token = Symbol("unmount");
	if (!root || !transitionRoot(root, {
		type: "unmount",
		token
	})) return;
	const teardown = () => {
		var _state$gl;
		if (root.ready.status === "pending") {
			root.ready.then(teardown, teardown);
			return;
		}
		if (!transitionRoot(root, {
			type: "dispose",
			token
		})) return;
		_roots.delete(canvas);
		const state = root.store.getState();
		state.internal.active = false;
		attempt(() => root.unwatchDpr == null ? void 0 : root.unwatchDpr());
		attempt(() => state.events.disconnect == null ? void 0 : state.events.disconnect());
		if ((_state$gl = state.gl) != null && _state$gl.xr) attempt(() => state.xr.disconnect());
		if (state.scene) attempt(() => dispose(state.scene));
		const disposal = attempt(() => releaseRenderer(state.gl, root.ownsRenderer));
		if (isPromiseLike(disposal)) disposal.then(() => callback == null ? void 0 : callback(canvas));
		else callback?.(canvas);
	};
	reconciler.updateContainer(null, root.fiber, null, () => {
		if (root.state.status !== "closing" || root.state.token !== token) return;
		reconciler.updateContainer(null, root.fiber, null, teardown);
	});
}
function createSubs(callback, subs) {
	const sub = { callback };
	subs.add(sub);
	return () => void subs.delete(sub);
}
var globalEffects = /* @__PURE__ */ new Set();
var globalAfterEffects = /* @__PURE__ */ new Set();
var globalTailEffects = /* @__PURE__ */ new Set();
/**
* Adds a global render callback which is called each frame.
* @see https://docs.pmnd.rs/react-three-fiber/api/additional-exports#addEffect
*/
var addEffect = (callback) => createSubs(callback, globalEffects);
/**
* Adds a global after-render callback which is called each frame.
* @see https://docs.pmnd.rs/react-three-fiber/api/additional-exports#addAfterEffect
*/
var addAfterEffect = (callback) => createSubs(callback, globalAfterEffects);
/**
* Adds a global callback which is called when rendering stops.
* @see https://docs.pmnd.rs/react-three-fiber/api/additional-exports#addTail
*/
var addTail = (callback) => createSubs(callback, globalTailEffects);
function run(effects, timestamp) {
	if (!effects.size) return;
	for (const { callback } of effects.values()) callback(timestamp);
}
function flushGlobalEffects(type, timestamp) {
	switch (type) {
		case "before": return run(globalEffects, timestamp);
		case "after": return run(globalAfterEffects, timestamp);
		case "tail": return run(globalTailEffects, timestamp);
	}
}
var subscribers;
var subscription;
function update(timestamp, state, frame) {
	let delta = state.clock.getDelta();
	if (state.frameloop === "never" && typeof timestamp === "number") {
		delta = timestamp - state.clock.elapsedTime;
		state.clock.oldTime = state.clock.elapsedTime;
		state.clock.elapsedTime = timestamp;
	}
	subscribers = state.internal.subscribers;
	for (let i = 0; i < subscribers.length; i++) {
		subscription = subscribers[i];
		subscription.ref.current(subscription.store.getState(), delta, frame);
	}
	if (!state.internal.priority && state.gl.render) state.gl.render(state.scene, state.camera);
	state.internal.frames = Math.max(0, state.internal.frames - 1);
	return state.frameloop === "always" ? 1 : state.internal.frames;
}
var running = false;
var useFrameInProgress = false;
var repeat;
var frame;
var state;
function loop(timestamp) {
	frame = requestAnimationFrame(loop);
	running = true;
	repeat = 0;
	flushGlobalEffects("before", timestamp);
	useFrameInProgress = true;
	for (const root of _roots.values()) {
		var _state$gl$xr;
		state = root.store.getState();
		if (state.internal.active && (state.frameloop === "always" || state.internal.frames > 0) && !((_state$gl$xr = state.gl.xr) != null && _state$gl$xr.isPresenting)) repeat += update(timestamp, state);
	}
	useFrameInProgress = false;
	flushGlobalEffects("after", timestamp);
	if (repeat === 0) {
		flushGlobalEffects("tail", timestamp);
		running = false;
		return cancelAnimationFrame(frame);
	}
}
/**
* Invalidates the view, requesting a frame to be rendered. Will globally invalidate unless passed a root's state.
* @see https://docs.pmnd.rs/react-three-fiber/api/additional-exports#invalidate
*/
function invalidate(state, frames = 1) {
	var _state$gl$xr2;
	if (!state) return _roots.forEach((root) => invalidate(root.store.getState(), frames));
	if ((_state$gl$xr2 = state.gl.xr) != null && _state$gl$xr2.isPresenting || !state.internal.active || state.frameloop === "never") return;
	if (frames > 1) state.internal.frames = Math.min(60, state.internal.frames + frames);
	else if (useFrameInProgress) state.internal.frames = 2;
	else state.internal.frames = 1;
	if (!running) {
		running = true;
		requestAnimationFrame(loop);
	}
}
/**
* Advances the frameloop and runs render effects, useful for when manually rendering via `frameloop="never"`.
* @see https://docs.pmnd.rs/react-three-fiber/api/additional-exports#advance
*/
function advance(timestamp, runGlobalEffects = true, state, frame) {
	if (runGlobalEffects) flushGlobalEffects("before", timestamp);
	if (!state) for (const root of _roots.values()) update(timestamp, root.store.getState());
	else update(timestamp, state, frame);
	if (runGlobalEffects) flushGlobalEffects("after", timestamp);
}
function createPortal(children, container, state) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Portal, {
		children,
		container,
		state
	});
}
function initializePortal(options, initialState) {
	const { parentStore, container } = options;
	const portalStore = createWithEqualityFn((set, get) => ({
		...initialState,
		set,
		get,
		setEvents: (events) => set((state) => ({
			...state,
			events: {
				...state.events,
				...events
			}
		}))
	}));
	const parentStateRef = { current: parentStore.getState() };
	portalStore.setState((portalState) => inject(parentStateRef.current, portalState, options));
	return {
		parentStore,
		container,
		portalStore,
		parentStateRef
	};
}
function Portal({ state = {}, children, container }) {
	const parentStore = useStore();
	const { events, size, ...rest } = state;
	const [raycaster] = import_react.useState(() => new Raycaster());
	const [pointer] = import_react.useState(() => new Vector2());
	const options = {
		parentStore,
		container,
		raycaster,
		pointer,
		events,
		size
	};
	const injectRef = useMutableCallback((parentState, portalState) => inject(parentState, portalState, options));
	const [portal, setPortal] = import_react.useState(() => initializePortal(options, rest));
	if (portal.parentStore !== parentStore || portal.container !== container) setPortal(initializePortal(options, rest));
	const { portalStore, parentStateRef } = portal;
	useIsomorphicLayoutEffect(() => {
		const update = (parentState) => {
			parentStateRef.current = parentState;
			portalStore.setState((portalState) => injectRef.current(parentState, portalState));
		};
		const unsubscribe = parentStore.subscribe(update);
		const parentState = parentStore.getState();
		if (parentState !== parentStateRef.current) update(parentState);
		return unsubscribe;
	}, [
		parentStore,
		portalStore,
		parentStateRef
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: reconciler.createPortal(/*#__PURE__*/ (0, import_jsx_runtime.jsx)(context.Provider, {
		value: portalStore,
		children
	}), portalStore, null) });
}
function inject(parentState, portalState, options) {
	const { parentStore, container, raycaster, pointer, events, size } = options;
	let viewport = void 0;
	if (portalState.camera && size) {
		const camera = portalState.camera;
		viewport = parentState.viewport.getCurrentViewport(camera, new Vector3(), size);
		if (camera !== parentState.camera) updateCamera(camera, size);
	}
	return {
		...parentState,
		...portalState,
		scene: container,
		raycaster,
		pointer,
		mouse: pointer,
		previousRoot: parentStore,
		events: {
			...parentState.events,
			...portalState.events,
			...events
		},
		size: {
			...parentState.size,
			...size
		},
		viewport: {
			...parentState.viewport,
			...viewport
		}
	};
}
var DOM_EVENTS = {
	onClick: ["click", false],
	onContextMenu: ["contextmenu", false],
	onDoubleClick: ["dblclick", false],
	onWheel: ["wheel", true],
	onPointerDown: ["pointerdown", true],
	onPointerUp: ["pointerup", true],
	onPointerLeave: ["pointerleave", true],
	onPointerMove: ["pointermove", true],
	onPointerCancel: ["pointercancel", true],
	onLostPointerCapture: ["lostpointercapture", true]
};
/** Default R3F event manager for web */
function createPointerEvents(store) {
	const { handlePointer } = createEvents(store);
	return {
		priority: 1,
		enabled: true,
		compute(event, state, previous) {
			state.pointer.set(event.offsetX / state.size.width * 2 - 1, -(event.offsetY / state.size.height) * 2 + 1);
			state.raycaster.setFromCamera(state.pointer, state.camera);
		},
		connected: void 0,
		handlers: Object.keys(DOM_EVENTS).reduce((acc, key) => ({
			...acc,
			[key]: handlePointer(key)
		}), {}),
		update: () => {
			var _internal$lastEvent;
			const { events, internal } = store.getState();
			if ((_internal$lastEvent = internal.lastEvent) != null && _internal$lastEvent.current && events.handlers) events.handlers.onPointerMove(internal.lastEvent.current);
		},
		connect: (target) => {
			const { set, events } = store.getState();
			events.disconnect == null || events.disconnect();
			set((state) => ({ events: {
				...state.events,
				connected: target
			} }));
			if (events.handlers) for (const name in events.handlers) {
				const event = events.handlers[name];
				const [eventName, passive] = DOM_EVENTS[name];
				target.addEventListener(eventName, event, { passive });
			}
		},
		disconnect: () => {
			const { set, events } = store.getState();
			if (events.connected) {
				if (events.handlers) for (const name in events.handlers) {
					const event = events.handlers[name];
					const [eventName] = DOM_EVENTS[name];
					events.connected.removeEventListener(eventName, event);
				}
				set((state) => ({ events: {
					...state.events,
					connected: void 0
				} }));
			}
		}
	};
}
// ../../Web Game/choo-choo-pop/node_modules/react-use-measure/dist/index.js
function g(n, t) {
	let o;
	return (...i) => {
		window.clearTimeout(o), o = window.setTimeout(() => n(...i), t);
	};
}
function j({ debounce: n, scroll: t, polyfill: o, offsetSize: i } = {
	debounce: 0,
	scroll: !1,
	offsetSize: !1
}) {
	const a = o || (typeof window == "undefined" ? class {} : window.ResizeObserver);
	if (!a) throw new Error("This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills");
	const [c, h] = (0, import_react.useState)({
		left: 0,
		top: 0,
		width: 0,
		height: 0,
		bottom: 0,
		right: 0,
		x: 0,
		y: 0
	}), e = (0, import_react.useRef)({
		element: null,
		scrollContainers: null,
		resizeObserver: null,
		lastBounds: c,
		orientationHandler: null
	}), d = n ? typeof n == "number" ? n : n.scroll : null, f = n ? typeof n == "number" ? n : n.resize : null, w = (0, import_react.useRef)(!1);
	(0, import_react.useEffect)(() => (w.current = !0, () => void (w.current = !1)));
	const [z, m, s] = (0, import_react.useMemo)(() => {
		const r = () => {
			if (!e.current.element) return;
			const { left: y, top: C, width: H, height: O, bottom: S, right: x, x: B, y: R } = e.current.element.getBoundingClientRect(), l = {
				left: y,
				top: C,
				width: H,
				height: O,
				bottom: S,
				right: x,
				x: B,
				y: R
			};
			e.current.element instanceof HTMLElement && i && (l.height = e.current.element.offsetHeight, l.width = e.current.element.offsetWidth), Object.freeze(l), w.current && !D(e.current.lastBounds, l) && h(e.current.lastBounds = l);
		};
		return [
			r,
			f ? g(r, f) : r,
			d ? g(r, d) : r
		];
	}, [
		h,
		i,
		d,
		f
	]);
	function v() {
		e.current.scrollContainers && (e.current.scrollContainers.forEach((r) => r.removeEventListener("scroll", s, !0)), e.current.scrollContainers = null), e.current.resizeObserver && (e.current.resizeObserver.disconnect(), e.current.resizeObserver = null), e.current.orientationHandler && ("orientation" in screen && "removeEventListener" in screen.orientation ? screen.orientation.removeEventListener("change", e.current.orientationHandler) : "onorientationchange" in window && window.removeEventListener("orientationchange", e.current.orientationHandler));
	}
	function b() {
		e.current.element && (e.current.resizeObserver = new a(s), e.current.resizeObserver.observe(e.current.element), t && e.current.scrollContainers && e.current.scrollContainers.forEach((r) => r.addEventListener("scroll", s, {
			capture: !0,
			passive: !0
		})), e.current.orientationHandler = () => {
			s();
		}, "orientation" in screen && "addEventListener" in screen.orientation ? screen.orientation.addEventListener("change", e.current.orientationHandler) : "onorientationchange" in window && window.addEventListener("orientationchange", e.current.orientationHandler));
	}
	const L = (r) => {
		!r || r === e.current.element || (v(), e.current.element = r, e.current.scrollContainers = E(r), b());
	};
	return X(s, !!t), W(m), (0, import_react.useEffect)(() => {
		v(), b();
	}, [
		t,
		s,
		m
	]), (0, import_react.useEffect)(() => v, []), [
		L,
		c,
		z
	];
}
function W(n) {
	(0, import_react.useEffect)(() => {
		const t = n;
		return window.addEventListener("resize", t), () => void window.removeEventListener("resize", t);
	}, [n]);
}
function X(n, t) {
	(0, import_react.useEffect)(() => {
		if (t) {
			const o = n;
			return window.addEventListener("scroll", o, {
				capture: !0,
				passive: !0
			}), () => void window.removeEventListener("scroll", o, !0);
		}
	}, [n, t]);
}
function E(n) {
	const t = [];
	if (!n || n === document.body) return t;
	const { overflow: o, overflowX: i, overflowY: a } = window.getComputedStyle(n);
	return [
		o,
		i,
		a
	].some((c) => c === "auto" || c === "scroll") && t.push(n), [...t, ...E(n.parentElement)];
}
var k = [
	"x",
	"y",
	"top",
	"bottom",
	"left",
	"right",
	"width",
	"height"
];
var D = (n, t) => k.every((o) => n[o] === t[o]);
// ../../Web Game/choo-choo-pop/node_modules/@react-three/fiber/dist/react-three-fiber.esm.js
function CanvasImpl({ ref, children, fallback, resize, style, gl, events = createPointerEvents, eventSource, eventPrefix, shadows, linear, flat, legacy, orthographic, frameloop, dpr, performance, raycaster, camera, scene, onPointerMissed, onCreated, ...props }) {
	import_react.useMemo(() => extend(three_module_exports), []);
	const Bridge = useBridge();
	const [containerRef, containerRect] = j({
		scroll: true,
		debounce: {
			scroll: 50,
			resize: 0
		},
		...resize
	});
	const canvasRef = import_react.useRef(null);
	const divRef = import_react.useRef(null);
	import_react.useImperativeHandle(ref, () => canvasRef.current);
	const handlePointerMissed = useMutableCallback(onPointerMissed);
	const pointerMissed = import_react.useCallback((event) => handlePointerMissed.current == null ? void 0 : handlePointerMissed.current(event), [handlePointerMissed]);
	const [block, setBlock] = import_react.useState(false);
	const [error, setError] = import_react.useState(false);
	if (block) throw block;
	if (error) throw error;
	const root = import_react.useRef(null);
	const [gate, waitFor] = useGate();
	const rootState = import_react.useRef(null);
	const eventTarget = () => eventSource ? isRef(eventSource) ? eventSource.current : eventSource : divRef.current;
	import_react.useInsertionEffect(() => {
		return () => {
			const current = root.current;
			root.current = null;
			current?.unmount();
		};
	}, []);
	useIsomorphicLayoutEffect(() => {
		const canvas = canvasRef.current;
		if (containerRect.width > 0 && containerRect.height > 0 && canvas) {
			if (!root.current) root.current = createRoot(canvas);
			root.current.configure({
				gl,
				scene,
				events,
				shadows,
				linear,
				flat,
				legacy,
				orthographic,
				frameloop,
				dpr,
				performance,
				raycaster,
				camera,
				size: containerRect,
				onPointerMissed: pointerMissed,
				onCreated: (state) => {
					var _eventTarget;
					rootState.current = state;
					state.events.connect == null || state.events.connect((_eventTarget = eventTarget()) != null ? _eventTarget : divRef.current);
					if (eventPrefix) state.setEvents({ compute: (event, state) => {
						const x = event[eventPrefix + "X"];
						const y = event[eventPrefix + "Y"];
						state.pointer.set(x / state.size.width * 2 - 1, -(y / state.size.height) * 2 + 1);
						state.raycaster.setFromCamera(state.pointer, state.camera);
					} });
					onCreated?.(state);
				}
			}).catch(setError);
			if (root.current.ready.status === "fulfilled") root.current.render(/*#__PURE__*/ (0, import_jsx_runtime.jsx)(Bridge, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ErrorBoundary, {
				set: setError,
				children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
					fallback: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Block, { set: setBlock }),
					children: children != null ? children : null
				})
			}) }));
			else if (root.current.ready.status === "pending") waitFor(root.current.ready);
		}
	});
	import_react.useEffect(() => {
		var _rootState$current;
		const state = (_rootState$current = rootState.current) == null ? void 0 : _rootState$current.get();
		const target = eventTarget();
		if (state && target && state.events.connected !== target) state.events.connect == null || state.events.connect(target);
	});
	import_react.useEffect(() => {
		const canvas = canvasRef.current;
		return () => {
			var _root$current;
			if (!canvas.isConnected) (_root$current = root.current) == null || _root$current.unmount();
		};
	}, []);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)("div", {
		ref: divRef,
		style: {
			position: "relative",
			width: "100%",
			height: "100%",
			overflow: "hidden",
			pointerEvents: eventSource ? "none" : "auto",
			...style
		},
		...props,
		children: [/*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
			ref: containerRef,
			style: {
				width: "100%",
				height: "100%"
			},
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				style: { display: "block" },
				children: fallback
			})
		}), gate]
	});
}
/**
* A DOM canvas which accepts threejs elements as children.
* @see https://docs.pmnd.rs/react-three-fiber/api/canvas
*/
function Canvas(props) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(h, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CanvasImpl, { ...props }) });
}
export { Canvas, threeTypes as ReactThreeFiber, _roots, act, addAfterEffect, addEffect, addTail, advance, applyProps, buildGraph, context, createEvents, createPortal, createRoot, dispose, createPointerEvents as events, extend, flushGlobalEffects, flushSync, getRootState, invalidate, reconciler, unmountComponentAtNode, useFrame, useGraph, useInstanceHandle, useLoader, useStore, useThree };
